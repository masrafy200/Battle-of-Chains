# Battle Shooter (Three.js + GitHub Actions)

থার্ড-পারসন শুটার: ব্যাটল রয়্যাল + ক্লাশ স্কোয়াড, অফলাইন / কো-অপ / মাল্টিপ্লেয়ার।

## GitHub-এ চালু করার ধাপ
1. এই পুরো ফোল্ডার (`.github` সহ) একটা GitHub রিপোজিটরিতে আপলোড করো (branch: `main`)।
2. Repo → Settings → Pages → Source = **GitHub Actions**।
3. Actions নিজে বিল্ড করে লিংক দেবে (Actions ট্যাবে দেখো)।

## মাল্টিপ্লেয়ার
- **LAN / হটস্পট (ইন্টারনেট ছাড়া):** হোস্টের পিসিতে `npm install && npm run lan` চালাও। স্ক্রিনে যে `http://IP:8080` আসবে, সবাই ওই ঠিকানা খুলবে। (GitHub Pages থেকে LAN কাজ করবে না, কারণ https থেকে ws ব্লক হয়।)
- **অনলাইন (Photon):** Photon dashboard থেকে Realtime App ID নাও। JS SDK (`Photon-Javascript_SDK.min.js`) `public/lib/`-এ রাখো। GitHub Secret `VITE_PHOTON_APPID` সেট করো। (Photon কোডটি আমি SDK ছাড়া টেস্ট করতে পারিনি, প্রথমবার চালিয়ে কনসোল এরর জানালে ঠিক করা হবে।)

## মডেল
এখন চরিত্র কোডে তৈরি (কিউট, হাত-পা অ্যানিমেশনসহ)। নিজের GLB ব্যবহার করতে `src/character.js` বদলাতে হবে। ফাইল `public/models/`-এ রাখো।

## লোকাল রান
`npm install && npm run dev`
