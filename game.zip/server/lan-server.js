// LAN server: serves the built game (dist/) AND relays multiplayer messages.
// Run on the host's PC:   npm run lan
// Everyone on the same WiFi / hotspot opens  http://<HOST-IP>:8080
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { fileURLToPath } from 'node:url';
import { WebSocketServer } from 'ws';

const PORT = process.env.PORT || 8080;
const DIST = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'dist');
const TYPES = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.glb': 'model/gltf-binary', '.png': 'image/png', '.svg': 'image/svg+xml' };

const server = http.createServer((req, res) => {
  let p = decodeURIComponent(req.url.split('?')[0]);
  if (p === '/') p = '/index.html';
  const file = path.join(DIST, path.normalize(p).replace(/^(\.\.[/\\])+/, ''));
  if (!file.startsWith(DIST)) { res.writeHead(403); res.end(); return; }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404); res.end('not found'); return; }
    res.writeHead(200, { 'Content-Type': TYPES[path.extname(file)] || 'application/octet-stream' });
    res.end(data);
  });
});

const wss = new WebSocketServer({ server });
const rooms = new Map(); // id -> { id, info, host, members:Set<client> }
let nextClient = 1, nextRoom = 1;

wss.on('connection', (ws) => {
  const me = { id: 'c' + nextClient++, ws, room: null };
  const send = (o) => ws.readyState === 1 && ws.send(JSON.stringify(o));
  send({ op: 'hello', id: me.id });

  const leave = () => {
    const r = me.room; if (!r) return;
    r.members.delete(me); me.room = null;
    if (r.host === me) { // host left: close room
      for (const m of r.members) { m.room = null; m.ws.readyState === 1 && m.ws.send(JSON.stringify({ op: 'closed' })); }
      rooms.delete(r.id);
    } else for (const m of r.members) m.ws.send(JSON.stringify({ op: 'peer-leave', id: me.id }));
  };

  ws.on('message', (raw) => {
    let m; try { m = JSON.parse(raw); } catch { return; }
    if (m.op === 'list') {
      send({ rid: m.rid, rooms: [...rooms.values()].filter((r) => !r.info.private).map((r) => ({ id: r.id, name: r.info.name, mode: r.info.mode, type: r.info.type, players: r.members.size, max: r.info.max })) });
    } else if (m.op === 'create') {
      leave();
      const wanted = m.info.id ? String(m.info.id).slice(0, 24) : null;
      if (wanted && rooms.has(wanted)) return send({ rid: m.rid, error: 'এই ID-র পার্টি আগে থেকেই খোলা আছে' });
      const r = { id: wanted || 'room' + nextRoom++, info: m.info, host: me, members: new Set([me]) };
      rooms.set(r.id, r); me.room = r; send({ rid: m.rid, roomId: r.id });
    } else if (m.op === 'join') {
      const r = rooms.get(m.roomId);
      if (!r) return send({ rid: m.rid, error: 'রুম পাওয়া যায়নি' });
      if (r.members.size >= r.info.max) return send({ rid: m.rid, error: 'রুম ভর্তি' });
      leave();
      for (const o of r.members) o.ws.send(JSON.stringify({ op: 'peer-join', id: me.id }));
      r.members.add(me); me.room = r;
      send({ rid: m.rid, ok: true });
    } else if (m.op === 'leave') leave();
    else if (m.op === 'send' && me.room) {
      const out = JSON.stringify({ op: 'msg', from: me.id, data: m.data });
      for (const o of me.room.members) if (o !== me && (!m.to || o.id === m.to) && o.ws.readyState === 1) o.ws.send(out);
    }
  });
  ws.on('close', leave);
});

server.listen(PORT, '0.0.0.0', () => {
  console.log('\n  Game server running. Players open one of:');
  for (const list of Object.values(os.networkInterfaces()))
    for (const i of list) if (i.family === 'IPv4' && !i.internal) console.log(`    http://${i.address}:${PORT}`);
  console.log(`    http://localhost:${PORT}  (this PC)\n`);
});
