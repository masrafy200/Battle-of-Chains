// Networking layer. Two interchangeable transports:
//   'lan'    -> WebSocket relay (server/lan-server.js). Works on hotspot/WiFi with NO internet.
//   'photon' -> Photon Cloud (needs internet + Photon JS SDK in public/lib + an App ID).
// Game code only talks to `Net`.

const PHOTON_APPID = import.meta.env?.VITE_PHOTON_APPID || '';
const PHOTON_VERSION = '1.0';
const EV = 1; // Photon event code we use for every game message

// ===================== LAN (WebSocket relay) =====================
class LanTransport {
  constructor() { this.ws = null; this.myId = null; this.isHost = false; this.cb = {}; this.pending = new Map(); this.rid = 0; }
  connect() {
    return new Promise((res, rej) => {
      const proto = location.protocol === 'https:' ? 'wss' : 'ws';
      let ws;
      try { ws = new WebSocket(`${proto}://${location.host}`); } catch (e) { rej(e); return; }
      this.ws = ws;
      const to = setTimeout(() => rej(new Error('LAN সার্ভার পাওয়া যায়নি')), 4000);
      ws.onopen = () => { clearTimeout(to); };
      ws.onerror = () => { clearTimeout(to); rej(new Error('LAN সার্ভার পাওয়া যায়নি (npm run lan চালু আছে?)')); };
      ws.onclose = () => this.cb.closed?.();
      ws.onmessage = (ev) => {
        const m = JSON.parse(ev.data);
        if (m.op === 'hello') { this.myId = m.id; res(); return; }
        if (m.rid && this.pending.has(m.rid)) { const p = this.pending.get(m.rid); this.pending.delete(m.rid); m.error ? p.rej(new Error(m.error)) : p.res(m); return; }
        if (m.op === 'peer-join') this.cb.join?.(m.id);
        else if (m.op === 'peer-leave') this.cb.leave?.(m.id);
        else if (m.op === 'msg') this.cb.message?.(m.from, m.data);
        else if (m.op === 'closed') this.cb.closed?.();
      };
    });
  }
  req(o) { return new Promise((res, rej) => { const rid = ++this.rid; this.pending.set(rid, { res, rej }); this.ws.send(JSON.stringify({ ...o, rid })); }); }
  async listRooms() { return (await this.req({ op: 'list' })).rooms; }
  async createRoom(info) { const r = await this.req({ op: 'create', info }); this.isHost = true; return r.roomId; }
  async joinRoom(id) { await this.req({ op: 'join', roomId: id }); this.isHost = false; }
  leave() { try { this.ws?.send(JSON.stringify({ op: 'leave' })); } catch { /* */ } this.isHost = false; }
  send(data, to) { this.ws?.send(JSON.stringify({ op: 'send', to, data })); }
  close() { try { this.ws?.close(); } catch { /* */ } }
}

// ===================== Photon Cloud =====================
function loadScript(src) {
  return new Promise((res, rej) => {
    if (window.Photon) { res(); return; }
    const s = document.createElement('script'); s.src = src; s.onload = res; s.onerror = () => rej(new Error('Photon SDK ফাইল পাওয়া যায়নি (public/lib/ ফোল্ডারে দিন)'));
    document.head.appendChild(s);
  });
}

class PhotonTransport {
  constructor() { this.c = null; this.myId = null; this.cb = {}; this.rooms = []; }
  get isHost() { return !!this.c && this.c.isJoinedToRoom() && this.c.myRoomMasterActorNr() === this.c.myActor().actorNr; }
  async connect() {
    if (!PHOTON_APPID) throw new Error('Photon App ID সেট করা নেই (VITE_PHOTON_APPID)');
    await loadScript('./lib/Photon-Javascript_SDK.min.js').catch(() => loadScript('./lib/Photon-Javascript_SDK.js'));
    if (!window.Photon) throw new Error('Photon SDK ফাইল পাওয়া যায়নি (public/lib/ ফোল্ডারে দিন)');
    const LB = window.Photon.LoadBalancing;
    const c = new LB.LoadBalancingClient(window.Photon.ConnectionProtocol.Wss, PHOTON_APPID, PHOTON_VERSION);
    this.c = c;
    await new Promise((res, rej) => {
      c.onStateChange = (st) => { if (st === LB.LoadBalancingClient.State.JoinedLobby) res(); };
      c.onError = (code, msg) => { rej(new Error('Photon: ' + msg)); };
      c.connectToRegionMaster('asia');
      setTimeout(() => rej(new Error('Photon কানেকশন টাইমআউট')), 10000);
    });
    c.onRoomList = (rooms) => { this.rooms = rooms; };
    c.onRoomListUpdate = (rooms) => { this.rooms = rooms; };
    c.onActorJoin = (a) => { if (a.actorNr !== c.myActor().actorNr) this.cb.join?.('p' + a.actorNr); };
    c.onActorLeave = (a) => this.cb.leave?.('p' + a.actorNr);
    c.onEvent = (code, content, actorNr) => { if (code === EV) { if (!content.to || content.to === this.myId) this.cb.message?.('p' + actorNr, content.d); } };
  }
  async listRooms() {
    const rooms = this.c.availableRooms();
    return rooms.map((r) => ({ id: r.name, name: r.getCustomProperty('title') || r.name, mode: r.getCustomProperty('mode'), type: r.getCustomProperty('type'), players: r.playerCount, max: r.maxPlayers }));
  }
  createRoom(info) {
    const id = info.id || 'r' + Math.random().toString(36).slice(2, 8);
    return new Promise((res, rej) => {
      const c = this.c;
      c.onJoinRoom = () => { this.myId = 'p' + c.myActor().actorNr; res(id); };
      c.onOperationResponse = (err, code, msg) => { if (err) rej(new Error(msg)); };
      c.createRoom(id, { maxPlayers: info.max, isVisible: !info.private, isOpen: true,
        customGameProperties: { title: info.name, mode: info.mode, type: info.type },
        propsListedInLobby: ['title', 'mode', 'type'] });
    });
  }
  joinRoom(id) {
    return new Promise((res, rej) => {
      const c = this.c;
      c.onJoinRoom = () => { this.myId = 'p' + c.myActor().actorNr; res(); };
      c.onOperationResponse = (err, code, msg) => { if (err) rej(new Error(msg)); };
      c.joinRoom(id);
    });
  }
  leave() { try { this.c?.leaveRoom(); } catch { /* */ } }
  send(data, to) {
    const L = window.Photon.LoadBalancing.Constants.ReceiverGroup;
    this.c.raiseEvent(EV, { d: data, to }, { receivers: L.Others });
  }
  close() { try { this.c?.disconnect(); } catch { /* */ } }
}

// ===================== Facade =====================
export const Net = {
  kind: null, t: null,
  on: { message: null, join: null, leave: null, closed: null },
  get myId() { return this.t?.myId; },
  get isHost() { return !!this.t?.isHost; },
  get photonConfigured() { return !!PHOTON_APPID; },

  async use(kind) {
    if (this.t) { this.t.close?.(); this.t = null; }
    const t = kind === 'photon' ? new PhotonTransport() : new LanTransport();
    t.cb = {
      message: (f, d) => this.on.message?.(f, d),
      join: (id) => this.on.join?.(id),
      leave: (id) => this.on.leave?.(id),
      closed: () => this.on.closed?.(),
    };
    await t.connect();
    this.t = t; this.kind = kind;
  },
  listRooms() { return this.t.listRooms(); },
  createRoom(info) { return this.t.createRoom(info); },
  joinRoom(id) { return this.t.joinRoom(id); },
  leave() { this.t?.leave(); },
  send(data, to) { this.t?.send(data, to); },
  disconnect() { this.t?.close?.(); this.t = null; },
};
