import * as THREE from 'three';
import { makeGun } from './weapons.js';

export const SKINS = [0x4aa3ff, 0xff6b6b, 0x58d68d, 0xf7c948, 0xb07cff, 0x2ee6c9, 0xff9f43, 0xe056a0];
export const SKIN_PRICE = [0, 200, 200, 300, 300, 400, 500, 600];

const M = (c, r = 0.75) => new THREE.MeshStandardMaterial({ color: c, roughness: r, flatShading: true });
const HIP = 0.62;

// Cute chibi character built from primitives (big head). Feet at y=0, faces local +Z.
// To use your own GLB model later, replace this function's visuals but keep the returned fields.
export function buildCharacter(skin = 0) {
  const col = SKINS[skin % SKINS.length];
  const root = new THREE.Group();
  const g = new THREE.Group(); root.add(g);
  const skinM = M(0xffd9b3), cloth = M(col), pants = M(0x33415c), shoe = M(0x1b1b1b), dark = M(0x111111);

  const body = new THREE.Group(); body.position.y = HIP; g.add(body);
  const torso = new THREE.Mesh(new THREE.BoxGeometry(0.52, 0.56, 0.3), cloth); torso.position.y = 0.3; body.add(torso);
  const belt = new THREE.Mesh(new THREE.BoxGeometry(0.54, 0.08, 0.32), dark); belt.position.y = 0.04; body.add(belt);

  const head = new THREE.Group(); head.position.y = 0.88; body.add(head);
  head.add(new THREE.Mesh(new THREE.SphereGeometry(0.29, 16, 12), skinM));
  for (const x of [-0.1, 0.1]) { const e = new THREE.Mesh(new THREE.SphereGeometry(0.035, 8, 6), dark); e.position.set(x, 0.02, 0.26); head.add(e); }
  const cap = new THREE.Mesh(new THREE.SphereGeometry(0.31, 16, 8, 0, Math.PI * 2, 0, Math.PI / 2), cloth); cap.position.y = 0.03; head.add(cap);
  const brim = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.03, 0.18), cloth); brim.position.set(0, 0.07, 0.3); head.add(brim);

  const mkArm = (x) => {
    const p = new THREE.Group(); p.position.set(x, 0.52, 0); body.add(p);
    const m = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.46, 0.14), cloth); m.position.y = -0.21; p.add(m);
    const h = new THREE.Mesh(new THREE.SphereGeometry(0.08, 8, 6), skinM); h.position.y = -0.46; p.add(h);
    return p;
  };
  const armL = mkArm(-0.35), armR = mkArm(0.35);
  const gunMount = new THREE.Group(); gunMount.position.set(0, -0.46, 0); gunMount.rotation.x = Math.PI / 2; armR.add(gunMount);

  const mkLeg = (x) => {
    const p = new THREE.Group(); p.position.set(x, HIP, 0); g.add(p);
    const m = new THREE.Mesh(new THREE.BoxGeometry(0.19, 0.6, 0.19), pants); m.position.y = -0.3; p.add(m);
    const s = new THREE.Mesh(new THREE.BoxGeometry(0.21, 0.1, 0.3), shoe); s.position.set(0, -0.58, 0.04); p.add(s);
    return p;
  };
  const legL = mkLeg(-0.13), legR = mkLeg(0.13);

  const chute = new THREE.Group(); chute.visible = false; g.add(chute);
  const canopy = new THREE.Mesh(new THREE.SphereGeometry(2.2, 16, 8, 0, Math.PI * 2, 0, Math.PI / 2),
    new THREE.MeshStandardMaterial({ color: col, side: THREE.DoubleSide, flatShading: true }));
  canopy.position.y = 3.2; chute.add(canopy);
  for (const [x, z] of [[1.4, 0], [-1.4, 0], [0, 1.4], [0, -1.4]]) {
    const l = new THREE.Mesh(new THREE.CylinderGeometry(0.01, 0.01, 2.6, 4), dark);
    l.position.set(x / 2, 1.9, z / 2); l.rotation.z = Math.atan2(x, 2.6) * -1; l.rotation.x = Math.atan2(z, 2.6); chute.add(l);
  }

  g.traverse((o) => { if (o.isMesh) o.castShadow = true; });
  return { group: root, g, body, head, armL, armR, legL, legR, gunMount, chute, phase: 0, recoil: 0, punch: 0, dead: 0, gunId: null };
}

export function setGun(ch, id) {
  if (ch.gunId === id) return;
  ch.gunMount.clear(); ch.gunId = id || null;
  if (id) ch.gunMount.add(makeGun(id));
}

// s: { speed 0..1.5, armed, aim, crouch, air, chute, dead, pitch }
export function animateCharacter(ch, s, dt) {
  ch.dead = THREE.MathUtils.clamp(ch.dead + (s.dead ? dt * 3 : -dt * 6), 0, 1);
  ch.g.rotation.x = -ch.dead * Math.PI / 2;
  ch.g.position.y = ch.dead * 0.25;

  const sp = Math.min(1.5, s.speed);
  if (sp > 0.05 && !s.air) ch.phase += dt * (4 + sp * 5);
  const sw = Math.sin(ch.phase) * Math.min(1, sp) * 0.95;
  const c = s.crouch ? 1 : 0;
  ch.recoil = Math.max(0, ch.recoil - dt * 9); ch.punch = Math.max(0, ch.punch - dt * 4.5);

  ch.body.position.y = HIP - 0.26 * c + Math.abs(Math.sin(ch.phase)) * 0.04 * Math.min(1, sp);
  ch.legL.position.y = ch.legR.position.y = HIP - 0.26 * c;
  ch.legL.scale.y = ch.legR.scale.y = 1 - 0.2 * c;

  if (s.air) {
    ch.legL.rotation.x = 0.35; ch.legR.rotation.x = -0.25;
    ch.armL.rotation.x = ch.armR.rotation.x = s.chute ? -2.7 : -0.9;
    ch.armL.rotation.z = -0.5; ch.armR.rotation.z = 0.5;
  } else {
    ch.legL.rotation.x = sw; ch.legR.rotation.x = -sw;
    if (s.armed) {
      const up = (s.pitch || 0) * 0.9; // the gun follows where the camera looks, so bullets go straight
      ch.armR.rotation.x = -Math.PI / 2 - up + ch.recoil * 0.25;
      ch.armL.rotation.x = -Math.PI / 2 + 0.15 - up; ch.armL.rotation.z = 0.38; ch.armR.rotation.z = -0.12;
    } else {
      ch.armL.rotation.x = -sw * 0.9; ch.armR.rotation.x = sw * 0.9 * (1 - ch.punch) - 1.7 * ch.punch;
      ch.armL.rotation.z = -0.08; ch.armR.rotation.z = 0.08;
    }
  }
  ch.head.rotation.x = -(s.pitch || 0) * 0.6;
  ch.chute.visible = !!s.chute;
}
