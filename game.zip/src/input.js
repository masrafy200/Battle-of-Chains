// Keyboard + mouse (pointer lock) + touch controls.
export const Input = {
  keys: new Set(),
  hit: new Set(),     // one-shot key presses
  fire: false,
  aim: false,
  dx: 0, dy: 0,
  mx: 0, my: 0,       // joystick
  touch: false,
  locked: false,
  enabled: false,     // only true while in a match
  sens: 0.0045,
  adsMul: 0.7,
  canvas: null,

  init(canvas) {
    this.canvas = canvas;
    this.touch = matchMedia('(pointer: coarse)').matches || 'ontouchstart' in window;
    const typing = (e) => /INPUT|TEXTAREA|SELECT/.test(e.target.tagName);

    addEventListener('keydown', (e) => {
      if (typing(e) || !this.enabled) return;
      if (['Space', 'Tab', 'ArrowUp', 'ArrowDown'].includes(e.code)) e.preventDefault();
      if (!e.repeat) this.hit.add(e.code);
      this.keys.add(e.code);
    });
    addEventListener('keyup', (e) => this.keys.delete(e.code));
    addEventListener('blur', () => { this.keys.clear(); this.fire = false; this.aim = false; });

    canvas.addEventListener('mousedown', (e) => {
      if (!this.enabled || this.touch || document.body.classList.contains('adjusting')) return;
      if (!this.locked) { this.lock(); return; }
      if (e.button === 0) this.fire = true;
      if (e.button === 2) this.aim = true;
    });
    addEventListener('mouseup', (e) => {
      if (e.button === 0) this.fire = false;
      if (e.button === 2) this.aim = false;
    });
    canvas.addEventListener('contextmenu', (e) => e.preventDefault());
    addEventListener('mousemove', (e) => {
      if (!this.locked) return;
      this.dx += e.movementX; this.dy += e.movementY;
    });
    addEventListener('wheel', (e) => {
      if (this.enabled) this.hit.add(e.deltaY > 0 ? 'WheelDown' : 'WheelUp');
    }, { passive: true });
    document.addEventListener('pointerlockchange', () => {
      this.locked = document.pointerLockElement === canvas;
      if (!this.locked) { this.fire = false; this.aim = false; }
      document.body.classList.toggle('unlocked', this.enabled && !this.locked && !this.touch);
    });

    this.initTouch();
  },

  lock() { if (!this.touch) this.canvas.requestPointerLock?.(); },
  unlock() { if (document.pointerLockElement) document.exitPointerLock(); },
  take(code) { return this.hit.delete(code); },
  endFrame() { this.dx = 0; this.dy = 0; this.hit.clear(); },
  reset() { this.keys.clear(); this.hit.clear(); this.fire = false; this.aim = false; this.mx = 0; this.my = 0; this.dx = 0; this.dy = 0; },

  initTouch() {
    const stick = document.getElementById('stick');
    const knob = document.getElementById('knob');
    const look = document.getElementById('touchLook');
    if (!stick || !look) return;
    let sid = null, cx = 0, cy = 0, lid = null, lx = 0, ly = 0;

    stick.addEventListener('pointerdown', (e) => {
      sid = e.pointerId; stick.setPointerCapture(sid);
      const r = stick.getBoundingClientRect(); cx = r.left + r.width / 2; cy = r.top + r.height / 2;
    });
    stick.addEventListener('pointermove', (e) => {
      if (e.pointerId !== sid) return;
      let x = (e.clientX - cx) / 50, y = (e.clientY - cy) / 50;
      const l = Math.hypot(x, y); if (l > 1) { x /= l; y /= l; }
      this.mx = x; this.my = y;
      knob.style.transform = `translate(${x * 40}px,${y * 40}px)`;
    });
    const endStick = (e) => { if (e.pointerId !== sid) return; sid = null; this.mx = 0; this.my = 0; knob.style.transform = ''; };
    stick.addEventListener('pointerup', endStick);
    stick.addEventListener('pointercancel', endStick);

    look.addEventListener('pointerdown', (e) => { lid = e.pointerId; look.setPointerCapture(lid); lx = e.clientX; ly = e.clientY; });
    look.addEventListener('pointermove', (e) => {
      if (e.pointerId !== lid) return;
      this.dx += (e.clientX - lx) * 2.2; this.dy += (e.clientY - ly) * 2.2; lx = e.clientX; ly = e.clientY;
    });
    const endLook = (e) => { if (e.pointerId === lid) lid = null; };
    look.addEventListener('pointerup', endLook);
    look.addEventListener('pointercancel', endLook);

    document.querySelectorAll('#touch [data-k]').forEach((el) => {
      const k = el.dataset.k;
      el.addEventListener('pointerdown', (e) => {
        e.preventDefault();
        if (k === 'Fire') this.fire = true;
        else if (k === 'Aim') this.aim = !this.aim;
        else { this.keys.add(k); this.hit.add(k); }
      });
      const up = () => { if (k === 'Fire') this.fire = false; else this.keys.delete(k); };
      el.addEventListener('pointerup', up);
      el.addEventListener('pointercancel', up);
    });
  },
};
