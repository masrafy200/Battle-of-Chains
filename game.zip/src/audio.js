// Tiny WebAudio synth: no audio files needed.
let ctx = null;
let master = null;
let muted = false;

function ac() {
  if (!ctx) {
    const C = window.AudioContext || window.webkitAudioContext;
    ctx = new C();
    master = ctx.createGain();
    master.gain.value = 0.5;
    master.connect(ctx.destination);
  }
  if (ctx.state === 'suspended') ctx.resume();
  return ctx;
}

function noise(dur, vol, freq, q = 1, type = 'lowpass') {
  if (muted || vol <= 0.002) return;
  const c = ac();
  const len = Math.floor(c.sampleRate * dur);
  const buf = c.createBuffer(1, len, c.sampleRate);
  const d = buf.getChannelData(0);
  for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 2);
  const src = c.createBufferSource(); src.buffer = buf;
  const f = c.createBiquadFilter(); f.type = type; f.frequency.value = freq; f.Q.value = q;
  const g = c.createGain(); g.gain.value = vol;
  src.connect(f); f.connect(g); g.connect(master); src.start();
}

function tone(f0, f1, dur, vol, type = 'sine') {
  if (muted || vol <= 0.002) return;
  const c = ac();
  const o = c.createOscillator(); o.type = type;
  o.frequency.setValueAtTime(f0, c.currentTime);
  o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), c.currentTime + dur);
  const g = c.createGain();
  g.gain.setValueAtTime(vol, c.currentTime);
  g.gain.exponentialRampToValueAtTime(0.001, c.currentTime + dur);
  o.connect(g); g.connect(master); o.start(); o.stop(c.currentTime + dur + 0.02);
}

const SHOT = {
  pistol: [0.12, 2500, 0.35], smg: [0.09, 3200, 0.3], ar: [0.14, 1800, 0.45],
  sg: [0.28, 900, 0.7], sn: [0.4, 700, 0.8],
};

export const Sfx = {
  unlock() { ac(); },
  setMuted(m) { muted = m; },
  get muted() { return muted; },
  shoot(kind = 'ar', vol = 1) {
    const [d, fr, v] = SHOT[kind] || SHOT.ar;
    noise(d, v * vol, fr);
    tone(160, 50, d, v * 0.5 * vol, 'square');
  },
  hit() { tone(900, 500, 0.06, 0.25, 'triangle'); },
  headshot() { tone(1400, 800, 0.09, 0.3, 'triangle'); },
  hurt() { tone(220, 90, 0.15, 0.35, 'sawtooth'); },
  reload() { noise(0.05, 0.3, 4000, 1, 'highpass'); setTimeout(() => noise(0.06, 0.3, 3000, 1, 'highpass'), 380); },
  empty() { tone(600, 500, 0.04, 0.2, 'square'); },
  pickup() { tone(500, 900, 0.1, 0.25, 'sine'); },
  heal() { tone(400, 800, 0.25, 0.25, 'sine'); },
  click() { tone(700, 600, 0.04, 0.15, 'square'); },
  win() { [0, 120, 240, 420].forEach((t, i) => setTimeout(() => tone(440 * [1, 1.25, 1.5, 2][i], 440 * [1, 1.25, 1.5, 2][i], 0.2, 0.3, 'triangle'), t)); },
  lose() { tone(300, 80, 0.6, 0.35, 'sawtooth'); },
  step() { noise(0.05, 0.06, 500); },
  buy() { tone(700, 1100, 0.12, 0.25, 'square'); },
  zone() { tone(300, 300, 0.4, 0.3, 'square'); },
};
