import * as THREE from 'three';
import { buildWorld, moveCircle, groundAt, rayHit, mulberry, HALF } from './world.js';
import { buildCharacter, setGun, animateCharacter } from './character.js';
import { WEAPONS, AMMO, ITEMS, makeGun } from './weapons.js';
import { Input } from './input.js';
import { Sfx } from './audio.js';
import { Save } from './save.js';
import { Nav } from './nav.js';

const $ = (id) => document.getElementById(id);
const V = (x = 0, y = 0, z = 0) => new THREE.Vector3(x, y, z);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const lerp = (a, b, t) => a + (b - a) * t;
const angDiff = (a, b) => { let d = (b - a) % (Math.PI * 2); if (d > Math.PI) d -= Math.PI * 2; if (d < -Math.PI) d += Math.PI * 2; return d; };
const angLerp = (a, b, t) => a + angDiff(a, b) * t;

const PLANE_ALT = 220, PLANE_SPEED = 40;
const STAGES = [ // 800 x 800 map: the safe circle shrinks in 5 steps
  { wait: 60, dur: 50, r: 330, dmg: 1 }, { wait: 45, dur: 45, r: 200, dmg: 2 },
  { wait: 35, dur: 35, r: 110, dmg: 3 }, { wait: 30, dur: 30, r: 50, dmg: 5 }, { wait: 20, dur: 25, r: 12, dmg: 8 },
];
const DIFF = [ // 0 easy, 1 normal, 2 hard
  { err: 1.6, react: 1.1, dmg: 0.5, vision: 50, rate: 0.6 },
  { err: 1.0, react: 0.6, dmg: 0.75, vision: 60, rate: 0.8 },
  { err: 0.6, react: 0.3, dmg: 1.0, vision: 75, rate: 1.0 },
];
const CS = { buy: 12, fight: 110, brk: 5, win: 4, bound: 88 };

const tracerGeo = new THREE.CylinderGeometry(0.018, 0.018, 1, 5);
const tracerMat = new THREE.MeshBasicMaterial({ color: 0xffe9a0 });
const sparkGeo = new THREE.SphereGeometry(0.12, 6, 4);
const sparkMats = {};

export class Game {
  constructor(renderer, net, hooks) {
    this.r = renderer; this.net = net; this.hooks = hooks;
    this.camera = new THREE.PerspectiveCamera(70, innerWidth / innerHeight, 0.1, 700);
    this.running = false;
    addEventListener('resize', () => { this.camera.aspect = innerWidth / innerHeight; this.camera.updateProjectionMatrix(); });
    $('wslots').addEventListener('pointerdown', (e) => { const el = e.target.closest('[data-slot]'); if (el) { Input.hit.add('Digit' + (+el.dataset.slot + 1)); e.preventDefault(); } });
    const shop = $('shop');
    shop?.addEventListener('click', (e) => {
      const b = e.target.closest('[data-buy]'); if (b) { this.buy(b.dataset.buy); return; }
      if (e.target.closest('[data-close]')) this.closeShop();
    });
  }

  // ------------------------------------------------------------------ setup
  start(cfg) {
    this.stop();
    this.cfg = cfg; this.mode = cfg.mode;
    this.offline = !!cfg.offline; this.isHost = this.offline || !!cfg.isHost; this.myId = cfg.myId;
    const scene = this.scene = new THREE.Scene();
    scene.background = new THREE.Color(0x9fd3f0); scene.fog = new THREE.Fog(0x9fd3f0, 120, 330);
    scene.add(new THREE.HemisphereLight(0xdff1ff, 0x5a7a4a, 0.9));
    const sun = this.sun = new THREE.DirectionalLight(0xfff2d6, 1.15);
    const q = Save.data.quality ?? 1;
    this.r.shadowMap.enabled = q > 0; sun.castShadow = q > 0; sun.shadow.mapSize.set(q >= 2 ? 2048 : 1024, q >= 2 ? 2048 : 1024);
    Object.assign(sun.shadow.camera, { left: -45, right: 45, top: 45, bottom: -45, near: 1, far: 300 });
    sun.shadow.bias = -0.0005; scene.add(sun, sun.target);

    this.world = buildWorld(scene, cfg.seed, {});
    this.grid = this.world.grid;
    this.nav = new Nav(this.grid, HALF);
    this.R = mulberry(cfg.seed ^ 0x5bd1e995);
    this.bound = this.mode === 'cs' ? CS.bound : HALF - 1.5;
    this.t = 0; this.fx = []; this.ents = new Map(); this.list = []; this.loot = [];
    this.sendT = 0; this.hudT = 0; this.zoneTick = 0; this.aimK = 0; this.ended = false; this.frozen = false;
    this.flashV = 0; this.bannerT = 0; this.myPlace = 0; this.shopOpen = false;

    for (const r of cfg.roster) this.mkEnt(r);
    this.me = this.ents.get(this.myId);
    this.me.yaw = 0; this.me.pitch = 0;
    if (this.mode === 'br') this.initBR(); else this.initCS();

    $('hud').classList.remove('hidden');
    $('hud').classList.toggle('cs', this.mode === 'cs');
    $('touch').classList.toggle('hidden', !Input.touch);
    $('feed').innerHTML = ''; this.mm = $('minimap');
    Input.reset(); Input.enabled = true; Input.lock();
    this.running = true;
    this.banner(this.mode === 'br' ? 'প্লেন থেকে লাফ দিতে F / Space চাপো' : 'রাউন্ড ১ – কেনাকাটা করো', 4);
  }

  stop() {
    this.running = false; Input.enabled = false; Input.reset(); Input.unlock(); delete document.body.dataset.ps;
    this.closeShop(true);
    $('hud')?.classList.add('hidden');
    this.scene = null; this.ents = new Map(); this.list = [];
  }

  mkEnt(r) {
    const e = {
      id: r.id, name: r.name, team: r.team, bot: !!r.bot, isLocal: r.id === this.myId, slot: r.slot || 0, skin: r.skin || 0,
      pos: V(), vel: V(), tpos: V(), yaw: 0, tyaw: 0, face: 0, pitch: 0, hp: 100, armor: 0, alive: true, state: 'ground',
      weapons: [null, null], cur: 0, ammo: { light: 0, rifle: 0, shell: 0 }, heals: { bandage: 0, medkit: 0 },
      vx: 0, vz: 0, kick: 0, cd: 0, reload: null, using: null, kills: 0, cash: 0, speed: 0, aiming: false, crouch: false, grounded: true, fireLatch: false, gun: null, seen: false,
    };
    e.ch = buildCharacter(e.skin);
    this.scene.add(e.ch.group);
    if (e.bot) e.ai = { think: Math.random() * 0.3, tgt: null, wish: V(), mode: 'idle', path: null, pi: 0, goal: null, repath: 0, stuck: 0, burst: 0, pause: 0, shots: 0, react: 0, hunt: null, huntT: 0, lootGoal: null, bad: new Set(), strafe: 0, land: null, jumpAt: 0 };
    this.ents.set(e.id, e); this.list.push(e);
    return e;
  }

  nameTag(e) {
    const c = document.createElement('canvas'); c.width = 256; c.height = 64;
    const x = c.getContext('2d'); x.font = 'bold 34px sans-serif'; x.textAlign = 'center'; x.lineWidth = 6; x.strokeStyle = '#000'; x.fillStyle = '#7dffa0';
    x.strokeText(e.name, 128, 44); x.fillText(e.name, 128, 44);
    const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(c), depthTest: false, transparent: true }));
    s.scale.set(2.4, 0.6, 1); s.position.y = 2.3; s.renderOrder = 10; e.ch.group.add(s);
  }

  // ------------------------------------------------------------------ battle royale
  initBR() {
    const R = this.R;
    const a = R() * Math.PI * 2, dx = Math.cos(a), dz = Math.sin(a), off = (R() - 0.5) * 120, L = HALF + 60;
    this.plane = { sx: -dx * L - dz * off, sz: -dz * L + dx * off, ex: dx * L - dz * off, ez: dz * L + dx * off, dur: (2 * L) / PLANE_SPEED, ang: Math.atan2(dx, dz) };
    const pm = new THREE.Group();
    const gm = new THREE.MeshStandardMaterial({ color: 0xdfe3e8, flatShading: true });
    const fus = new THREE.Mesh(new THREE.BoxGeometry(3, 3, 16), gm); const wing = new THREE.Mesh(new THREE.BoxGeometry(18, 0.4, 3.5), gm);
    const tail = new THREE.Mesh(new THREE.BoxGeometry(6, 0.4, 2.5), gm); tail.position.z = -7; const fin = new THREE.Mesh(new THREE.BoxGeometry(0.4, 3, 2.5), gm); fin.position.set(0, 2, -7);
    pm.add(fus, wing, tail, fin); pm.rotation.y = this.plane.ang; this.scene.add(pm); this.planeMesh = pm;

    // zone
    let cx = 0, cz = 0, r = 620, at = this.plane.dur + 15; this.zoneStages = [];
    for (const s of STAGES) {
      const maxOff = Math.max(0, r - s.r) * 0.8, ang = R() * 6.283, dist = Math.sqrt(R()) * maxOff;
      const nx = cx + Math.cos(ang) * dist, nz = cz + Math.sin(ang) * dist;
      at += s.wait; this.zoneStages.push({ t0: at, t1: at + s.dur, from: { cx, cz, r }, to: { cx: nx, cz: nz, r: s.r }, dmg: s.dmg });
      cx = nx; cz = nz; r = s.r; at += s.dur;
    }
    this.zoneMesh = new THREE.Mesh(new THREE.CylinderGeometry(1, 1, 140, 72, 1, true),
      new THREE.MeshBasicMaterial({ color: 0xff3b3b, transparent: true, opacity: 0.22, side: THREE.DoubleSide, depthWrite: false }));
    this.zoneMesh.position.y = 60; this.scene.add(this.zoneMesh);

    // loot (deterministic from seed on every machine)
    const LR = mulberry(this.cfg.seed + 777);
    this.world.lootSpots.forEach((sp, i) => {
      const it = this.rollLoot(LR, sp.tier, sp.tag);
      const mesh = this.lootMesh(it); mesh.position.set(sp.x, 0.6, sp.z); this.scene.add(mesh);
      this.loot.push({ i, ...it, x: sp.x, z: sp.z, mesh, gone: false });
    });

    for (const e of this.list) {
      e.state = 'plane';
      if (e.bot) {
        e.ai.jumpAt = 3 + Math.random() * (this.plane.dur - 6); e.ai.land = { x: 0, z: 0 };
        const inside = this.world.lootSpots.filter((q) => q.tier >= 1), pool = Math.random() < 0.75 && inside.length ? inside : this.world.lootSpots;
        const sp = pool[Math.floor(Math.random() * pool.length)];
        e.ai.land = { x: sp.x, z: sp.z };
      }
      if (!e.bot && !e.isLocal && e.team === this.me.team) this.nameTag(e);
    }
  }

  rollLoot(r, tier, tag) {
    const x = r(), g = Math.min(0.999, r() + 0.08 * tier * r()), c = r();
    const gunP = 0.24 + 0.05 * tier + (tag === 'gun' ? 0.3 : 0), medP = tag === 'med' ? 0.55 : 0;
    if (x < medP) return c < 0.5 ? { kind: 'heal', id: 'medkit' } : c < 0.85 ? { kind: 'heal', id: 'bandage' } : { kind: 'armor' };
    if (x < medP + gunP) { const ids = ['pistol', 'smg', 'ar', 'shotgun', 'sniper', 'lmg'], cut = [0.22, 0.42, 0.6, 0.76, 0.88, 1]; return { kind: 'gun', id: ids[cut.findIndex((q) => g < q)] }; }
    if (x < medP + gunP + 0.34) return { kind: 'ammo', type: c < 0.4 ? 'light' : c < 0.8 ? 'rifle' : 'shell' };
    if (x < 0.82 + medP * 0.1) return { kind: 'heal', id: 'bandage' };
    if (x < 0.92) return { kind: 'heal', id: 'medkit' };
    return { kind: 'armor' };
  }

  lootMesh(it) {
    let m;
    if (it.kind === 'gun') { m = makeGun(it.id); m.scale.setScalar(1.4); const w = new THREE.Group(); m.position.z = -WEAPONS[it.id].len * 0.7; w.add(m); m = w; }
    else {
      const col = it.kind === 'ammo' ? AMMO[it.type].col : it.kind === 'heal' ? ITEMS[it.id].col : ITEMS.armor.col;
      m = new THREE.Mesh(it.kind === 'armor' ? new THREE.CylinderGeometry(0.25, 0.2, 0.4, 8) : new THREE.BoxGeometry(0.4, 0.3, 0.4), new THREE.MeshStandardMaterial({ color: col, emissive: col, emissiveIntensity: 0.35, flatShading: true }));
    }
    const ring = new THREE.Mesh(new THREE.RingGeometry(0.5, 0.65, 20), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.5, side: THREE.DoubleSide }));
    ring.rotation.x = -Math.PI / 2; ring.position.y = -0.55;
    const g = new THREE.Group(); g.add(m, ring); return g;
  }

  planePos() { const p = this.plane, f = clamp(this.t / p.dur, 0, 1); return { x: lerp(p.sx, p.ex, f), z: lerp(p.sz, p.ez, f) }; }

  zoneAt(t) {
    const S = this.zoneStages;
    for (const s of S) {
      if (t < s.t0) return { ...s.from, dmg: s.dmg, shrinking: false, tl: s.t0 - t, next: s.to };
      if (t < s.t1) { const k = (t - s.t0) / (s.t1 - s.t0); return { cx: lerp(s.from.cx, s.to.cx, k), cz: lerp(s.from.cz, s.to.cz, k), r: lerp(s.from.r, s.to.r, k), dmg: s.dmg, shrinking: true, tl: s.t1 - t, next: s.to }; }
    }
    const l = S[S.length - 1]; return { ...l.to, dmg: l.dmg, shrinking: false, tl: 0, next: l.to };
  }

  // ------------------------------------------------------------------ clash squad
  initCS() {
    this.cs = { phase: 'buy', round: 1, t: 0, score: [0, 0], paid: false };
    this.csReset(1);
    for (const e of this.list) if (!e.bot && !e.isLocal && e.team === this.me.team) this.nameTag(e);
    this.openShop();
  }

  csReset(round) {
    for (const e of this.list) {
      e.alive = true; e.hp = 100; e.state = 'ground'; e.vel.set(0, 0, 0); e.using = null; e.reload = null; e.ch.dead = 0;
      if (round === 1) { e.armor = 0; e.heals = { bandage: 0, medkit: 0 }; e.weapons = [null, { id: 'pistol', mag: 12 }]; e.ammo = { light: 36, rifle: 0, shell: 0 }; e.kills = 0; if (e.isLocal) e.cash = 800; }
      const sp = this.world.csSpawns[e.team][e.slot % 2], dir = e.team === 0 ? 1 : -1;
      e.pos.set(sp[0] + dir * Math.floor(e.slot / 2) * 2.5, 0, sp[1]); e.tpos.copy(e.pos);
      e.yaw = e.tyaw = e.face = e.team === 0 ? -Math.PI / 2 : Math.PI / 2; e.pitch = 0;
      if (e.bot) { // bots "buy" something
        const opts = round < 2 ? ['smg'] : round < 4 ? ['smg', 'ar', 'shotgun'] : ['ar', 'shotgun', 'sniper', 'ar'];
        const id = opts[Math.floor(Math.random() * opts.length)], d = WEAPONS[id];
        e.weapons = [{ id, mag: d.mag }, { id: 'pistol', mag: 12 }]; e.ammo = { light: 90, rifle: 90, shell: 24 }; e.armor = round > 1 ? 50 : 0;
      }
      for (const w of e.weapons) if (w) w.mag = WEAPONS[w.id].mag;
      e.cur = e.weapons[0] ? 0 : 1;
    }
    this.frozen = true;
  }

  applyCsPhase(phase, round, score, winner) {
    const cs = this.cs; cs.phase = phase; cs.t = 0; cs.round = round; cs.score = score;
    if (phase === 'buy') { this.csReset(round); this.banner(`রাউন্ড ${round} – কেনাকাটা করো (B)`, 4); this.openShop(); }
    else if (phase === 'fight') { this.frozen = false; this.closeShop(); this.banner('লড়াই শুরু!', 2); }
    else if (phase === 'break') {
      this.frozen = true; this.closeShop();
      const won = winner === this.me.team;
      this.banner(winner < 0 ? 'ড্র' : won ? 'রাউন্ড জিতেছ!' : 'রাউন্ড হেরেছ', 4);
      this.me.cash += (won ? 1200 : 900) + this.me.kills * 0;
      if (winner >= 0) (won ? Sfx.win : Sfx.lose)();
    }
  }

  teamAlive(t) { let n = 0; for (const e of this.list) if (e.alive && e.team === t) n++; return n; }
  teamHp(t) { let n = 0; for (const e of this.list) if (e.alive && e.team === t) n += e.hp; return n; }

  csUpdate(dt) {
    const cs = this.cs; cs.t += dt;
    if (!this.isHost || this.ended) return;
    const go = (phase, round, winner = -1) => { this.applyCsPhase(phase, round, cs.score, winner); this.net?.send({ t: 'R', phase, round, score: cs.score, w: winner }); };
    if (cs.phase === 'buy' && cs.t >= CS.buy) go('fight', cs.round);
    else if (cs.phase === 'fight') {
      const a = this.teamAlive(0), b = this.teamAlive(1);
      if (!a || !b || cs.t >= CS.fight) {
        let w = !a && !b ? -1 : !a ? 1 : !b ? 0 : this.teamHp(0) > this.teamHp(1) ? 0 : this.teamHp(1) > this.teamHp(0) ? 1 : -1;
        if (w >= 0) cs.score[w]++;
        if (w >= 0 && cs.score[w] >= CS.win) { this.net?.send({ t: 'E', win: w }); this.finish(w); return; }
        go('break', cs.round, w);
      }
    } else if (cs.phase === 'break' && cs.t >= CS.brk) go('buy', cs.round + 1);
  }

  // ---- shop
  openShop() {
    if (this.mode !== 'cs' || !this.cs || this.cs.phase !== 'buy') return;
    this.shopOpen = true; $('shop').classList.remove('hidden'); this.renderShop(); Input.unlock();
  }
  closeShop(silent) {
    const s = $('shop'); if (!s) return;
    if (this.shopOpen && !silent) Input.lock();
    this.shopOpen = false; s.classList.add('hidden');
  }
  renderShop() {
    const me = this.me; this._shopCash = me.cash; let h = `<div class="shopbox"><h2>🛒 অস্ত্র বাজার <span class="cash">$${me.cash}</span></h2><div class="grid">`;
    for (const [id, d] of Object.entries(WEAPONS)) if (d.price) h += `<button data-buy="g:${id}" ${me.cash < d.price ? 'disabled' : ''}><b>${d.name}</b><small>ড্যামেজ ${d.dmg} · ম্যাগ ${d.mag}</small><em>$${d.price}</em></button>`;
    for (const [id, d] of Object.entries(ITEMS)) h += `<button data-buy="i:${id}" ${me.cash < d.price ? 'disabled' : ''}><b>${d.name}</b><small>${id === 'armor' ? '+৫০ আর্মার' : '+' + d.heal + ' HP'}</small><em>$${d.price}</em></button>`;
    h += `</div><button class="ok" data-close>ঠিক আছে (B)</button></div>`;
    $('shop').innerHTML = h;
  }
  buy(code) {
    const me = this.me; if (this.cs.phase !== 'buy') return;
    const [k, id] = code.split(':');
    if (k === 'g') { const d = WEAPONS[id]; if (me.cash < d.price) return; me.cash -= d.price; me.weapons[0] = { id, mag: d.mag }; me.ammo[d.ammo] = Math.min(AMMO[d.ammo].max, me.ammo[d.ammo] + d.mag * 3); me.cur = 0; }
    else { const d = ITEMS[id]; if (me.cash < d.price) return; if (id === 'armor') { if (me.armor >= 100) return; me.armor = 100; } else { if (me.heals[id] >= 5) return; me.heals[id]++; } me.cash -= d.price; }
    Sfx.buy(); this.renderShop();
  }

  // ------------------------------------------------------------------ main frame
  frame(dt) {
    if (!this.running || !this.scene) return;
    dt = Math.min(dt, 0.05); this.t += dt;
    if (this.mode === 'cs') this.csUpdate(dt);
    this.pathBudget = 2;
    this.updateLocal(dt);
    if (this.isHost) for (const b of this.list) if (b.bot) this.updateBot(b, dt);
    this.updateRemotes(dt);
    this.updateModels(dt);
    if (this.mode === 'br') { this.updateBR(dt); }
    this.updateLoot(dt);
    this.updateFx(dt);
    this.updateCamera(dt);
    this.netSend(dt);
    this.updateHud(dt);
    Input.endFrame();
    this.r.render(this.scene, this.camera);
  }

  updateBR(dt) {
    const pp = this.planePos();
    this.planeMesh.position.set(pp.x, PLANE_ALT, pp.z); this.planeMesh.visible = this.t < this.plane.dur + 2;
    const z = this.zone = this.zoneAt(this.t);
    this.zoneMesh.scale.set(z.r, 1, z.r); this.zoneMesh.position.x = z.cx; this.zoneMesh.position.z = z.cz;
    this.zoneTick += dt;
    if (this.zoneTick >= 1) {
      this.zoneTick = 0;
      for (const e of this.list) if (e.alive && e.state === 'ground' && (e.isLocal || (e.bot && this.isHost)) && Math.hypot(e.pos.x - z.cx, e.pos.z - z.cz) > z.r) this.applyDamage(e, z.dmg, null, false);
    }
  }

  owns(e) { return e.isLocal || (e.bot && this.isHost); }

  // ------------------------------------------------------------------ movement helpers
  stepGround(e, dt, wx, wz, speed, jump) {
    const p = e.pos;
    // smooth acceleration / braking instead of snapping to full speed
    const k = Math.min(1, dt * (e.grounded ? (wx || wz ? 13 : 16) : 2.5));
    e.vx += (wx * speed - e.vx) * k; e.vz += (wz * speed - e.vz) * k;
    p.x += e.vx * dt; p.z += e.vz * dt;
    moveCircle(this.grid, p, 0.4, e.crouch ? 1.1 : 1.75);
    p.x = clamp(p.x, -this.bound, this.bound); p.z = clamp(p.z, -this.bound, this.bound);
    const g = groundAt(this.grid, p.x, p.z, p.y);
    if (p.y <= g + 0.03 && e.vel.y <= 0) { p.y = g; e.vel.y = 0; e.grounded = true; if (jump && !e.crouch) { e.vel.y = 6.6; e.grounded = false; } }
    else e.grounded = false;
    if (!e.grounded) {
      e.vel.y -= 18 * dt; p.y += e.vel.y * dt;
      const g2 = groundAt(this.grid, p.x, p.z, p.y);
      if (p.y < g2 && e.vel.y <= 0) { p.y = g2; e.vel.y = 0; e.grounded = true; }
    }
    e.speed = Math.hypot(e.vx, e.vz) / 5;
  }

  airMove(e, dt, wx, wz, open) {
    const p = e.pos;
    if (e.state === 'fall') { e.vel.y = Math.max(e.vel.y - 30 * dt, -50); if (open || p.y < 55) { e.state = 'chute'; if (e.isLocal) this.banner('প্যারাস্যুট খুলেছে', 1.5); } }
    else e.vel.y = lerp(e.vel.y, -7, dt * 3);
    const h = e.state === 'fall' ? 26 : 12;
    p.x = clamp(p.x + wx * h * dt, -this.bound, this.bound); p.z = clamp(p.z + wz * h * dt, -this.bound, this.bound);
    p.y += e.vel.y * dt;
    if (p.y < 40) moveCircle(this.grid, p, 0.4, 1.75);
    const g = groundAt(this.grid, p.x, p.z, p.y);
    if (p.y <= g) { p.y = g; e.vel.y = 0; e.state = 'ground'; e.grounded = true; }
    e.speed = 0; e.vx = e.vz = 0;
  }

  // ------------------------------------------------------------------ local player
  updateLocal(dt) {
    const p = this.me; if (!p) return;
    const locked = Input.locked || Input.touch;
    if (locked && !this.shopOpen) { const k = Input.sens * (Input.aim && p.state === 'ground' ? Input.adsMul : 1); p.yaw -= Input.dx * k; p.pitch = clamp(p.pitch - Input.dy * k, -1.25, 1.2); }
    p.kick *= Math.exp(-dt * (Input.fire ? 1.6 : 7)); // recoil settles back by itself
    if (!p.alive) { this.spectateKeys(); return; }

    let mx = (Input.keys.has('KeyD') ? 1 : 0) - (Input.keys.has('KeyA') ? 1 : 0) + Input.mx;
    let mz = (Input.keys.has('KeyW') ? 1 : 0) - (Input.keys.has('KeyS') ? 1 : 0) - Input.my;
    const l = Math.hypot(mx, mz); if (l > 1) { mx /= l; mz /= l; }
    const sy = Math.sin(p.yaw), cy = Math.cos(p.yaw);
    const wx = -sy * mz + cy * mx, wz = -cy * mz - sy * mx;
    const space = Input.take('Space'), fkey = Input.take('KeyF');

    if (p.state === 'plane') {
      const pp = this.planePos(); p.pos.set(pp.x, PLANE_ALT, pp.z);
      if (((space || fkey) && this.t > 1.5) || this.t >= this.plane.dur) { p.state = 'fall'; p.vel.set(0, 0, 0); this.banner('ফ্রি-ফল! Space = প্যারাস্যুট', 2.5); }
      return;
    }
    if (p.state === 'fall' || p.state === 'chute') { this.airMove(p, dt, wx, wz, space || fkey); p.face = angLerp(p.face, p.yaw, dt * 8); return; }

    const sprint = Input.keys.has('ShiftLeft') || Input.keys.has('ShiftRight') || (Input.touch && Math.hypot(Input.mx, Input.my) > 0.92);
    p.crouch = Input.keys.has('KeyC') || Input.keys.has('ControlLeft');
    p.aiming = Input.aim && !sprint;
    const unarmed = !p.weapons[p.cur];
    let speed = (p.crouch ? 2.6 : sprint && !Input.fire ? 7.6 : 5.0) * (unarmed && !p.crouch ? 1.22 : 1); // empty hands = faster
    if (p.aiming) speed *= 0.7; if (p.using) speed *= 0.6;
    if (this.frozen) speed = 0;
    this.stepGround(p, dt, wx, wz, speed, space && !this.frozen);

    // facing
    const moving = Math.hypot(wx, wz) > 0.1 && speed > 0;
    if (p.aiming || Input.fire || !moving) p.face = angLerp(p.face, p.yaw, Math.min(1, dt * (p.aiming || Input.fire ? 14 : 6)));
    else p.face = angLerp(p.face, Math.atan2(-wx, -wz), Math.min(1, dt * 10));

    // inventory keys
    if (Input.take('Digit1')) this.slotKey(p, 0);
    if (Input.take('Digit2')) this.slotKey(p, 1);
    if (Input.take('WheelUp') || Input.take('WheelDown') || Input.take('KeyQ')) this.slotKey(p, p.cur === 0 ? 1 : 0);
    if (Input.take('Digit3')) this.startUse(p, 'bandage');
    if (Input.take('Digit4')) this.startUse(p, 'medkit');
    if (Input.take('KeyR')) this.startReload(p);
    if (Input.take('KeyB')) { if (this.shopOpen) this.closeShop(); else this.openShop(); }
    this.localPickup(p, Input.take('KeyE'));

    this.tickWeapon(p, dt);
    if (!this.frozen && !this.shopOpen) this.localFire(p, dt);
  }

  spectateKeys() { /* spectating needs no keys; camera follows automatically */ }

  equip(e, i) { if (!e.weapons[i] || e.cur === i) return; e.cur = i; e.reload = null; e.cd = Math.max(e.cd, 0.25); }
  // slot tap: select that gun; tap the selected slot again = put it away (empty hands)
  slotKey(e, i) {
    if (e.cur === i) { e.cur = -1; e.reload = null; return; }
    if (e.weapons[i]) this.equip(e, i);
  }

  startReload(e) {
    const w = e.weapons[e.cur]; if (!w || e.reload) return;
    const d = WEAPONS[w.id]; if (w.mag >= d.mag || e.ammo[d.ammo] <= 0) return;
    e.reload = { t: d.reload }; if (e.isLocal) Sfx.reload();
  }

  startUse(e, k) {
    if (e.using || e.heals[k] <= 0 || e.hp >= 100) return;
    e.using = { k, t: ITEMS[k].time, dur: ITEMS[k].time }; e.reload = null;
  }

  tickWeapon(e, dt) {
    if (e.cd > 0) e.cd -= dt;
    if (e.reload) {
      e.reload.t -= dt;
      if (e.reload.t <= 0) {
        const w = e.weapons[e.cur]; e.reload = null;
        if (w) { const d = WEAPONS[w.id], take = Math.min(d.mag - w.mag, e.ammo[d.ammo]); w.mag += take; e.ammo[d.ammo] -= take; }
      }
    }
    if (e.using) {
      e.using.t -= dt;
      if (e.using.t <= 0) { const it = ITEMS[e.using.k]; e.hp = Math.min(100, e.hp + it.heal); e.heals[e.using.k]--; if (e.isLocal) Sfx.heal(); e.using = null; }
    }
  }

  camAim() {
    const p = this.me, pt = p.pitch + p.kick, cp = Math.cos(pt);
    const d = V(-Math.sin(p.yaw) * cp, Math.sin(pt), -Math.cos(p.yaw) * cp);
    const cam = this.camera.position;
    const pivot = V(p.pos.x, p.pos.y + (p.crouch ? 1.15 : 1.6), p.pos.z);
    const o = cam.clone().addScaledVector(d, pivot.clone().sub(cam).dot(d));
    return { o, d };
  }

  localFire(p, dt) {
    const w = p.weapons[p.cur];
    if (!Input.fire) p.fireLatch = false;
    if (!w) { this.punch(p); return; }
    if (!Input.fire || p.cd > 0 || p.reload || p.using || p.state !== 'ground') return;
    const d = WEAPONS[w.id];
    if (!d.auto && p.fireLatch) return;
    p.fireLatch = true;
    if (w.mag <= 0) { Sfx.empty(); this.startReload(p); return; }
    w.mag--; p.cd = 1 / d.rate;
    const { o, d: dir } = this.camAim();
    const mul = (Math.hypot(p.speed, 0) > 0.2 ? 1.7 : 1) * (p.aiming ? 0.45 : 1) * (p.crouch ? 0.7 : 1);
    this.fireWeapon(p, w.id, o, dir, mul);
    p.kick = Math.min(0.28, p.kick + d.recoil * (0.7 + Math.random() * 0.6));
    if (w.mag <= 0) this.startReload(p);
  }

  punch(p) {
    if (!Input.fire || p.cd > 0 || p.using || p.state !== 'ground') return;
    p.cd = 0.5; p.ch.punch = 1; Sfx.step();
    const f = V(-Math.sin(p.yaw), 0, -Math.cos(p.yaw));
    for (const t of this.list) {
      if (t === p || !t.alive || t.team === p.team || t.state !== 'ground') continue;
      const dx = t.pos.x - p.pos.x, dz = t.pos.z - p.pos.z, d = Math.hypot(dx, dz);
      if (d < 2.3 && (dx * f.x + dz * f.z) / (d || 1) > 0.35 && Math.abs(t.pos.y - p.pos.y) < 1.6) this.hit(t, 14, p, false); // weaker than any gun
    }
    this.net?.send({ t: 'M', id: p.id });
  }

  // ------------------------------------------------------------------ shooting / damage
  muzzle(e) {
    e.ch.group.updateMatrixWorld(true);
    const g = e.ch.gunMount.children[0];
    return g ? g.localToWorld(V(0, 0.06, g.userData.muzzle)) : V(e.pos.x, e.pos.y + 1.3, e.pos.z);
  }

  entHit(e, o, d, maxD, sc = 1) {
    let best = null;
    for (const [hy, r, head] of [[1.55, 0.3 * sc, true], [1.0, 0.46 * sc, false], [0.4, 0.4 * sc, false]]) {
      const ox = o.x - e.pos.x, oy = o.y - (e.pos.y + hy * (e.crouch ? 0.78 : 1)), oz = o.z - e.pos.z;
      const b = ox * d.x + oy * d.y + oz * d.z, c = ox * ox + oy * oy + oz * oz - r * r, disc = b * b - c;
      if (disc < 0) continue;
      const t = -b - Math.sqrt(disc);
      if (t > 0 && t < maxD && (!best || t < best.t)) best = { t, head };
    }
    return best;
  }

  // fires weapon `wid` from shooter e; applies damage (client-side authority for shooter)
  fireWeapon(e, wid, o, dir, spreadMul = 1, dmgMul = 1) {
    const def = WEAPONS[wid], hits = new Map(), ends = [], sc = e.isLocal ? 1.35 : 1; // small aim assist for the human player
    for (let i = 0; i < def.pellets; i++) {
      const d = dir.clone(), sp = def.spread * spreadMul;
      d.x += (Math.random() - 0.5) * 2 * sp; d.y += (Math.random() - 0.5) * 2 * sp; d.z += (Math.random() - 0.5) * 2 * sp; d.normalize();
      const wall = rayHit(this.grid, o, d, def.range), maxD = Math.min(def.range, wall);
      let best = null, be = null;
      for (const t of this.list) {
        if (t === e || !t.alive || t.team === e.team || t.state === 'plane') continue;
        if (Math.abs(t.pos.x - o.x) > maxD + 2 || Math.abs(t.pos.z - o.z) > maxD + 2) continue;
        const h = this.entHit(t, o, d, maxD, sc); if (h && (!best || h.t < best.t)) { best = h; be = t; }
      }
      const dist = best ? best.t : maxD, end = o.clone().addScaledVector(d, dist); ends.push(end);
      if (best) { const rec = hits.get(be) || { dmg: 0, head: false }; rec.dmg += def.dmg * dmgMul * (1 - 0.35 * best.t / def.range) * (best.head ? 2 : 1); rec.head = rec.head || best.head; hits.set(be, rec); this.spark(end, 0xff4040); }
      else if (wall < def.range) this.spark(end, 0xd0d0d0);
    }
    this.tracer(e, ends[0], def, true);
    for (const [t, rec] of hits) this.hit(t, rec.dmg, e, rec.head);
    if (this.isHost) this.alertBots(e);
    this.net?.send({ t: 'F', id: e.id, w: wid, e: [+ends[0].x.toFixed(1), +ends[0].y.toFixed(1), +ends[0].z.toFixed(1)] });
  }

  tracer(e, end, def, own) {
    const m = this.muzzle(e), dir = end.clone().sub(m), len = dir.length(); if (len < 0.1) return;
    const mesh = new THREE.Mesh(tracerGeo, tracerMat);
    mesh.position.copy(m).addScaledVector(dir, 0.5); mesh.scale.set(1, len, 1);
    mesh.quaternion.setFromUnitVectors(V(0, 1, 0), dir.normalize());
    this.scene.add(mesh); this.fx.push({ mesh, life: 0.06 });
    const fl = new THREE.Mesh(sparkGeo, tracerMat); fl.position.copy(m); fl.scale.setScalar(1.6); this.scene.add(fl); this.fx.push({ mesh: fl, life: 0.04 });
    e.ch.recoil = 1;
    const dist = e.pos.distanceTo(this.camera.position);
    Sfx.shoot(def.snd, own && e.isLocal ? 1 : clamp(1 - dist / 140, 0, 1));
  }

  spark(p, col) {
    const m = new THREE.Mesh(sparkGeo, sparkMats[col] ||= new THREE.MeshBasicMaterial({ color: col }));
    m.position.copy(p); this.scene.add(m); this.fx.push({ mesh: m, life: 0.25, grow: true });
  }

  hit(t, dmg, by, head) {
    if (this.frozen) return;
    if (by.isLocal) { this.hitMarker(head); head ? Sfx.headshot() : Sfx.hit(); }
    if (this.owns(t)) this.applyDamage(t, dmg, by.id, head);
    else this.net?.send({ t: 'H', to: t.id, d: Math.round(dmg * 10) / 10, by: by.id, h: head ? 1 : 0 });
  }

  applyDamage(t, dmg, byId, head) {
    if (!t.alive || this.ended) return;
    if (t.armor > 0) { const ab = Math.min(t.armor, dmg * 0.5); t.armor -= ab; dmg -= ab; }
    t.hp -= dmg;
    if (t.bot && byId) { const a = this.ents.get(byId); if (a && a.team !== t.team) { t.ai.hunt = a; t.ai.huntT = 8; } }
    if (t.isLocal) { this.flashV = 1; Sfx.hurt(); t.using = null; }
    if (t.hp <= 0) { t.hp = 0; this.killEnt(t, byId, true); }
  }

  killEnt(t, byId, broadcast) {
    if (!t.alive) return;
    t.alive = false; t.hp = 0; t.state = 'dead'; t.using = null; t.reload = null;
    const k = byId ? this.ents.get(byId) : null;
    if (k && k !== t) k.kills++;
    this.feed(`${k ? k.name : '☠ জোন'} ➜ ${t.name}`, t.isLocal || (k && k.isLocal));
    if (broadcast) this.net?.send({ t: 'D', id: t.id, by: byId });
    if (this.mode === 'br') {
      const alive = this.list.filter((e) => e.alive);
      if (t.isLocal) { this.myPlace = alive.length + 1; setTimeout(() => !this.ended && this.hooks.onDeath?.({ place: this.myPlace, kills: this.me.kills, by: k?.name }), 1500); }
      const teams = new Set(alive.map((e) => e.team));
      if (teams.size <= 1 && !this.ended) this.finish(alive[0]?.team ?? null);
    } else if (t.isLocal) this.banner('তুমি মারা গেছ – দর্শক মোড', 3);
  }

  finish(winTeam, leaving = false) {
    if (this.ended) return; this.ended = true;
    const me = this.me, win = winTeam != null && me.team === winTeam;
    const place = win ? 1 : (this.myPlace || this.list.filter((e) => e.alive).length + 1);
    let coins;
    if (this.mode === 'br') coins = me.kills * 15 + (win ? 200 : place <= 3 ? 100 : place <= 10 ? 40 : 15);
    else coins = (win ? 150 : 40) + me.kills * 10;
    if (leaving && !win && this.mode === 'cs') coins = 10;
    if (!this.cfg.noReward) Save.addCoins(coins);
    Save.record(win, me.kills);
    (win ? Sfx.win : Sfx.lose)();
    this.hooks.onEnd?.({ win, place, kills: me.kills, coins, mode: this.mode, leaving });
  }
  leave() { this.finish(null, true); }

  // ------------------------------------------------------------------ loot
  localPickup(p, ePressed) {
    if (this.mode !== 'br' || p.state !== 'ground') { this.setPrompt(''); return; }
    let best = null, bd = 2.2;
    for (const it of this.loot) { if (it.gone) continue; const d = Math.hypot(it.x - p.pos.x, it.z - p.pos.z); if (d < bd) { bd = d; best = it; } }
    if (!best) { this.setPrompt(''); return; }
    const swap = best.kind === 'gun' && ePressed;
    if (this.takeLoot(p, best, swap)) { Sfx.pickup(); this.setPrompt(''); }
    else this.setPrompt(best.kind === 'gun' ? `E চাপো: ${WEAPONS[best.id].name} নাও (বর্তমান অস্ত্র বদলাবে)` : '');
  }

  takeLoot(e, it, swap) {
    let ok = false;
    if (it.kind === 'gun') {
      const d = WEAPONS[it.id], have = e.weapons.findIndex((w) => w && w.id === it.id);
      if (have >= 0) { e.ammo[d.ammo] = Math.min(AMMO[d.ammo].max, e.ammo[d.ammo] + d.mag); ok = true; }
      else {
        let slot = e.weapons.findIndex((w) => !w);
        if (slot < 0 && swap) slot = e.cur;
        if (slot >= 0) { e.weapons[slot] = { id: it.id, mag: d.mag }; e.ammo[d.ammo] = Math.min(AMMO[d.ammo].max, e.ammo[d.ammo] + d.mag); if (!e.weapons[e.cur] || slot === e.cur || swap) e.cur = slot; e.reload = null; ok = true; }
      }
    } else if (it.kind === 'ammo') { const a = AMMO[it.type]; if (e.ammo[it.type] < a.max) { e.ammo[it.type] = Math.min(a.max, e.ammo[it.type] + a.pack); ok = true; } }
    else if (it.kind === 'heal') { if (e.heals[it.id] < 5) { e.heals[it.id]++; ok = true; } }
    else if (it.kind === 'armor') { if (e.armor < 100) { e.armor = Math.min(100, e.armor + 50); ok = true; } }
    if (ok) this.removeLoot(it, true);
    return ok;
  }

  removeLoot(it, broadcast) {
    if (it.gone) return; it.gone = true; this.scene.remove(it.mesh);
    if (broadcast) this.net?.send({ t: 'P', i: it.i });
  }

  updateLoot(dt) {
    for (const it of this.loot) if (!it.gone) { it.mesh.rotation.y += dt * 1.5; it.mesh.position.y = 0.75 + Math.sin(this.t * 2 + it.i) * 0.08; }
  }

  // ------------------------------------------------------------------ bots (run on host)
  alertBots(shooter) {
    for (const b of this.list) {
      if (!b.bot || !b.alive || b === shooter || b.team === shooter.team || b.state !== 'ground') continue;
      if (b.pos.distanceTo(shooter.pos) < 55 && (!b.ai.hunt || b.ai.huntT <= 0)) { b.ai.hunt = shooter; b.ai.huntT = 8; }
    }
  }

  setGoal(b, x, z, force) {
    const ai = b.ai;
    if (!force && ai.goal && ai.path && ai.repath > 0 && Math.hypot(ai.goal.x - x, ai.goal.z - z) < 3) return true;
    if (this.pathBudget <= 0) return !!ai.path || ai.mode === 'strafe'; // too many A* searches this frame: keep the old path
    this.pathBudget--;
    const p = this.nav.path(b.pos.x, b.pos.z, x, z);
    ai.goal = { x, z }; ai.repath = 1.5; ai.mode = 'path';
    if (!p) { ai.path = null; ai.mode = 'idle'; return false; }
    ai.path = p; ai.pi = 0; return true;
  }

  wants(b, it) {
    if (it.kind === 'gun') {
      const d = WEAPONS[it.id];
      if (b.weapons.some((w) => !w)) return true;
      if (b.weapons.some((w) => w.id === it.id)) return b.ammo[d.ammo] < AMMO[d.ammo].max * 0.6;
      return d.price > Math.min(...b.weapons.map((w) => WEAPONS[w.id].price));
    }
    if (it.kind === 'ammo') return b.weapons.some((w) => w && WEAPONS[w.id].ammo === it.type) && b.ammo[it.type] < AMMO[it.type].max * 0.6;
    if (it.kind === 'heal') return b.heals[it.id] < 3;
    return b.armor < 100;
  }

  updateBot(b, dt) {
    if (!b.alive) return;
    const ai = b.ai;
    if (b.state === 'plane') {
      if (this.mode === 'br' && this.t >= ai.jumpAt) {
        b.state = 'fall'; b.vel.set(0, 0, 0);
        let pool = this.world.lootSpots.filter((q) => q.tier >= 1 && Math.hypot(q.x - b.pos.x, q.z - b.pos.z) < 150);
        if (!pool.length) pool = this.world.lootSpots.filter((q) => Math.hypot(q.x - b.pos.x, q.z - b.pos.z) < 220);
        const sp = pool.length ? pool[Math.floor(Math.random() * pool.length)] : this.world.lootSpots[0];
        ai.land = { x: sp.x, z: sp.z };
      }
      else { if (this.plane) { const pp = this.planePos(); b.pos.set(pp.x, PLANE_ALT, pp.z); } return; }
    }
    if (b.state === 'fall' || b.state === 'chute') {
      const tx = ai.land.x - b.pos.x, tz = ai.land.z - b.pos.z, l = Math.hypot(tx, tz) || 1, k = Math.min(1, l / 12);
      this.airMove(b, dt, (tx / l) * k, (tz / l) * k, b.pos.y < 75); b.face = b.yaw = Math.atan2(-tx, -tz); return;
    }
    if (this.frozen) { b.speed = 0; return; }
    this.tickWeapon(b, dt);
    ai.repath -= dt; ai.huntT -= dt;
    ai.think -= dt;
    if (ai.think <= 0) { ai.think = 0.2 + Math.random() * 0.15; this.botThink(b); }

    const tg = ai.tgt && ai.tgt.alive ? ai.tgt : null;
    let speed = 4.8;
    if (tg) {
      const dx = tg.pos.x - b.pos.x, dz = tg.pos.z - b.pos.z, dist = Math.hypot(dx, dz);
      b.yaw = angLerp(b.yaw, Math.atan2(-dx, -dz), Math.min(1, dt * 7)); b.face = b.yaw;
      b.pitch = Math.atan2(tg.pos.y + 1.2 - (b.pos.y + 1.5), dist);
      this.botCombat(b, tg, dist, dt);
      if (ai.mode === 'strafe') speed = 3.4;
    }
    let wx = 0, wz = 0;
    if (ai.mode === 'path' && ai.path) {
      while (ai.pi < ai.path.length) {
        const w = ai.path[ai.pi], dx = w.x - b.pos.x, dz = w.z - b.pos.z, d = Math.hypot(dx, dz);
        if (d < 0.8) { ai.pi++; continue; }
        wx = dx / d; wz = dz / d; break;
      }
      if (ai.pi >= ai.path.length) ai.mode = 'idle';
    } else if (ai.mode === 'strafe') { wx = ai.wish.x; wz = ai.wish.z; }
    if (!tg && (wx || wz)) { b.yaw = angLerp(b.yaw, Math.atan2(-wx, -wz), Math.min(1, dt * 8)); b.face = b.yaw; b.pitch = 0; }
    const bx = b.pos.x, bz = b.pos.z;
    this.stepGround(b, dt, wx, wz, speed, false);
    if ((wx || wz) && Math.hypot(b.pos.x - bx, b.pos.z - bz) < speed * dt * 0.25) ai.stuck += dt; else ai.stuck = 0;
    if (ai.stuck > 0.7) { ai.stuck = 0; ai.repath = 0; ai.goal = null; if (ai.mode === 'strafe') ai.wish.multiplyScalar(-1); else if (ai.mode === 'path') ai.mode = 'idle'; }
  }

  botThink(b) {
    const ai = b.ai, D = DIFF[Save.data.diff | 0] || DIFF[0], armed = b.weapons.some((w) => w);
    const br = this.mode === 'br';

    if (br) { // pick up what we stand next to, heal, reload
      for (const it of this.loot) {
        if (it.gone || Math.hypot(it.x - b.pos.x, it.z - b.pos.z) > 2) continue;
        if (!this.wants(b, it)) continue;
        if (it.kind === 'gun' && b.weapons.every((w) => w)) { b.cur = WEAPONS[b.weapons[0].id].price <= WEAPONS[b.weapons[1].id].price ? 0 : 1; }
        if (this.takeLoot(b, it, true)) break;
      }
      if (!b.weapons[b.cur]) b.cur = b.weapons[0] ? 0 : 1;
      const w = b.weapons[b.cur]; if (w && w.mag <= 0 && !ai.tgt) this.startReload(b);
      if (b.hp < 65 && !ai.tgt) { if (b.heals.medkit > 0) this.startUse(b, 'medkit'); else if (b.heals.bandage > 0) this.startUse(b, 'bandage'); }
    }

    // find a visible enemy
    let best = null, bd = D.vision * D.vision;
    for (const t of this.list) {
      if (t === b || !t.alive || t.team === b.team || t.state === 'plane' || t.state === 'dead') continue;
      const dx = t.pos.x - b.pos.x, dz = t.pos.z - b.pos.z, d2 = dx * dx + dz * dz; if (d2 >= bd) continue;
      const o = V(b.pos.x, b.pos.y + 1.5, b.pos.z), tp = V(t.pos.x, t.pos.y + 1.2, t.pos.z), dir = tp.sub(o), L = dir.length(); dir.divideScalar(L);
      if (rayHit(this.grid, o, dir, L) >= L - 0.5) { best = t; bd = d2; }
    }
    if (best && armed) {
      if (ai.tgt !== best) { ai.tgt = best; ai.react = D.react * (0.7 + Math.random() * 0.6); ai.burst = 0; ai.pause = 0.2; }
      ai.hunt = best; ai.huntT = 8;
      const dist = Math.sqrt(bd);
      if (dist < 16) { // close: strafe and shoot
        const dx = best.pos.x - b.pos.x, dz = best.pos.z - b.pos.z, l = dist || 1, sg = ai.strafe ||= (Math.random() < 0.5 ? 1 : -1);
        if (Math.random() < 0.15) ai.strafe = -sg;
        const fwd = dist < 6 ? -0.5 : 0.1;
        ai.wish.set((dx / l) * fwd + (-dz / l) * 0.8 * sg, 0, (dz / l) * fwd + (dx / l) * 0.8 * sg).normalize(); ai.mode = 'strafe';
      } else this.setGoal(b, best.pos.x, best.pos.z); // far: walk closer through the path
      return;
    }
    ai.tgt = null;

    // BR: safe zone first
    if (br && this.zone) {
      const z = this.zone, near = Math.hypot(b.pos.x - z.cx, b.pos.z - z.cz), nxt = Math.hypot(b.pos.x - z.next.cx, b.pos.z - z.next.cz);
      if (near > z.r * 0.92 || ((z.shrinking || z.tl < 25) && nxt > z.next.r * 0.85)) { this.setGoal(b, z.next.cx + (Math.random() - 0.5) * 6, z.next.cz + (Math.random() - 0.5) * 6); return; }
    }
    // someone shot at us / near us: go and find them
    if (ai.hunt && ai.hunt.alive && ai.huntT > 0 && armed && ai.hunt.state === 'ground') { this.setGoal(b, ai.hunt.pos.x, ai.hunt.pos.z); return; }

    if (br) { // loot
      let g = ai.lootGoal;
      if (g && (g.gone || ai.bad.has(g.i) || !this.wants(b, g))) g = ai.lootGoal = null;
      if (!g) {
        let bs = 120;
        for (const it of this.loot) {
          if (it.gone || ai.bad.has(it.i) || !this.wants(b, it)) continue;
          let d = Math.hypot(it.x - b.pos.x, it.z - b.pos.z);
          if (!armed && it.kind === 'gun') d *= 0.3; else if (it.kind === 'gun') d *= 0.7;
          if (this.world.lootSpots[it.i].tier >= 1) d *= 0.8;
          if (d < bs) { bs = d; g = it; }
        }
        ai.lootGoal = g;
      }
      if (g) { if (!this.setGoal(b, g.x, g.z)) { ai.bad.add(g.i); ai.lootGoal = null; } return; }
    }
    // fully equipped: hunt the closest enemy (Clash Squad: always)
    let en = null, ed = 1e9;
    for (const t of this.list) { if (!t.alive || t.team === b.team || t.state !== 'ground') continue; const d = b.pos.distanceTo(t.pos); if (d < ed) { ed = d; en = t; } }
    if (en && armed && (!br || this.t > this.plane.dur + 25)) { this.setGoal(b, en.pos.x, en.pos.z); return; }
    // roam between buildings
    if (ai.mode !== 'path' || !ai.path || ai.pi >= ai.path.length) {
      const bl = this.world.buildings[Math.floor(Math.random() * this.world.buildings.length)];
      if (bl) this.setGoal(b, bl.x, bl.z, true);
    }
  }

  botCombat(b, tg, dist, dt) {
    const ai = b.ai, D = DIFF[Save.data.diff | 0] || DIFF[0], w = b.weapons[b.cur]; if (!w || b.reload) return;
    const d = WEAPONS[w.id];
    if (w.mag <= 0) { this.startReload(b); if (!b.reload) { const o = b.weapons.findIndex((x, i) => x && i !== b.cur && x.mag > 0); if (o >= 0) b.cur = o; } return; }
    ai.react -= dt; if (ai.react > 0) return;
    if (b.cd > 0) return;
    if (ai.burst <= 0) { ai.pause -= dt; if (ai.pause > 0) return; ai.burst = d.auto ? 2 + Math.floor(Math.random() * 3) : 1; ai.shots = 0; ai.pause = (0.5 + Math.random() * 0.8) / (D.rate + 0.4); }
    if (dist > d.range * 0.8) return;
    ai.burst--; ai.shots++; w.mag--; b.cd = 1 / (d.rate * D.rate) * (d.auto ? 1 : 1.4);
    const o = V(b.pos.x, b.pos.y + 1.5, b.pos.z), tp = V(tg.pos.x, tg.pos.y + 1.0, tg.pos.z);
    // recoil: every shot in a burst drifts further off target; moving makes it worse
    const err = (dist * (0.035 + 0.016 * ai.shots) + 0.3) * D.err * (b.speed > 0.3 ? 1.4 : 1);
    tp.x += (Math.random() - 0.5) * err; tp.y += (Math.random() - 0.5) * err * 0.7; tp.z += (Math.random() - 0.5) * err;
    this.fireWeapon(b, w.id, o, tp.sub(o).normalize(), 1.6, D.dmg);
  }

  // ------------------------------------------------------------------ remote entities / visuals
  updateRemotes(dt) {
    for (const e of this.list) {
      if (e.isLocal || (e.bot && this.isHost)) continue;
      if (e.pos.distanceTo(e.tpos) > 12) e.pos.copy(e.tpos); else e.pos.lerp(e.tpos, Math.min(1, dt * 12));
      e.yaw = angLerp(e.yaw, e.tyaw, Math.min(1, dt * 12)); e.face = e.yaw;
    }
  }

  updateModels(dt) {
    const lod = [100, 150, 220][Save.data.quality ?? 1] || 150, cp = this.camera.position;
    for (const e of this.list) {
      const ch = e.ch;
      const near = e.isLocal || e.pos.distanceToSquared(cp) < lod * lod;
      ch.group.visible = e.state !== 'plane' && near;
      if (!ch.group.visible) continue; // far away characters are not drawn / animated (saves a lot on phones)
      ch.group.position.copy(e.pos);
      ch.group.rotation.y = e.face + Math.PI;
      const gid = e.isLocal || this.owns(e) ? e.weapons[e.cur]?.id : e.gun;
      setGun(ch, e.state === 'ground' || e.state === 'dead' ? gid : null);
      animateCharacter(ch, { speed: e.speed, armed: !!gid && e.state === 'ground', aim: e.aiming, crouch: e.crouch, air: e.state === 'fall' || e.state === 'chute', chute: e.state === 'chute', dead: !e.alive, pitch: e.pitch + e.kick }, dt);
    }
    this.world.update({ x: this.me.pos.x, z: this.me.pos.z, y: this.me.pos.y });
  }

  camTarget() {
    const me = this.me; if (me.alive) return me;
    let t = this.list.find((e) => e.alive && e.team === me.team);
    return t || this.list.find((e) => e.alive) || me;
  }

  updateCamera(dt) {
    const cam = this.camera, me = this.me, tgt = this.camTarget();
    const wDef = me.alive && me.weapons[me.cur] ? WEAPONS[me.weapons[me.cur].id] : null;
    const aimK = me.alive && Input.aim && me.state === 'ground' ? 1 : 0;
    this.aimK = lerp(this.aimK, aimK, Math.min(1, dt * 10));
    const yaw = me.yaw, pitch = clamp(me.pitch + me.kick, -1.35, 1.3), cp = Math.cos(pitch);
    const dir = V(-Math.sin(yaw) * cp, Math.sin(pitch), -Math.cos(yaw) * cp);
    let pivot, dist, sh = 0;
    const air = tgt.state === 'fall' || tgt.state === 'chute';
    if (me.state === 'plane' && me.alive) { const pp = this.planePos(); pivot = V(pp.x, PLANE_ALT, pp.z); dist = 26; }
    else { pivot = V(tgt.pos.x, tgt.pos.y + (tgt.crouch ? 1.15 : 1.6), tgt.pos.z); dist = air ? 7 : lerp(3.8, 2.0, this.aimK); sh = air ? 0 : lerp(0.65, 0.5, this.aimK); }
    const right = V(Math.cos(yaw), 0, -Math.sin(yaw));
    let want = pivot.clone().addScaledVector(right, sh).addScaledVector(dir, -dist);
    const to = want.clone().sub(pivot), L = to.length(); to.divideScalar(L);
    const hd = rayHit(this.grid, pivot, to, L); if (hd < L) want = pivot.clone().addScaledVector(to, Math.max(0.3, hd - 0.25));
    want.y = Math.max(0.3, want.y);
    cam.position.copy(want); cam.rotation.set(pitch, yaw, 0, 'YXZ');
    const scoped = wDef && wDef.zoom && this.aimK > 0.8;
    const fov = lerp(70 + Math.min(1, me.speed - 1) * (me.state === 'ground' && me.speed > 1.2 ? 4 : 0), wDef && wDef.zoom ? 70 / wDef.zoom : 55, this.aimK); if (Math.abs(cam.fov - fov) > 0.05) { cam.fov = fov; cam.updateProjectionMatrix(); }
    $('scope').classList.toggle('hidden', !scoped);
    this.sun.position.set(tgt.pos.x + 60, 100, tgt.pos.z + 40); this.sun.target.position.copy(tgt.pos);
    this.sun.target.updateMatrixWorld();
  }

  updateFx(dt) {
    for (let i = this.fx.length - 1; i >= 0; i--) {
      const f = this.fx[i]; f.life -= dt;
      if (f.grow) f.mesh.scale.multiplyScalar(1 + dt * 4);
      if (f.life <= 0) { this.scene.remove(f.mesh); this.fx.splice(i, 1); }
    }
  }

  // ------------------------------------------------------------------ networking
  netSend(dt) {
    if (!this.net || this.offline) return;
    this.sendT += dt; if (this.sendT < 0.066) return; this.sendT = 0;
    const m = this.me, r1 = (v) => Math.round(v * 10) / 10;
    this.net.send({ t: 'S', id: m.id, p: [r1(m.pos.x), r1(m.pos.y), r1(m.pos.z)], y: +m.face.toFixed(2), pt: +(m.pitch + m.kick).toFixed(2), s: +m.speed.toFixed(2), st: m.state, c: m.crouch ? 1 : 0, a: m.aiming ? 1 : 0, w: m.weapons[m.cur]?.id || null, hp: Math.round(m.hp) });
    this.botT = (this.botT || 0) + 0.066;
    if (this.isHost && this.botT >= 0.1) {
      this.botT = 0;
      const bots = this.list.filter((b) => b.bot && b.alive).map((b) => [b.id, r1(b.pos.x), r1(b.pos.y), r1(b.pos.z), +b.face.toFixed(2), +b.speed.toFixed(2), b.state, b.weapons[b.cur]?.id || null, Math.round(b.hp), +b.pitch.toFixed(2)]);
      if (bots.length) this.net.send({ t: 'B', b: bots });
    }
  }

  applyRemote(e, x, y, z, yaw, speed, st, gun, hp, pitch) {
    e.tpos.set(x, y, z); e.tyaw = yaw; e.speed = speed; e.gun = gun; e.hp = hp; e.pitch = pitch || 0;
    if (e.alive && st !== 'dead') e.state = st;
    if (!e.seen) { e.seen = true; e.pos.copy(e.tpos); e.face = e.yaw = yaw; }
  }

  netMsg(from, m) {
    if (!this.running || !this.scene) return;
    switch (m.t) {
      case 'S': { const e = this.ents.get(m.id); if (!e || e.isLocal || (e.bot && this.isHost)) return; this.applyRemote(e, m.p[0], m.p[1], m.p[2], m.y, m.s, m.st, m.w, m.hp, m.pt); e.crouch = !!m.c; e.aiming = !!m.a; break; }
      case 'B': { if (this.isHost) return; for (const b of m.b) { const e = this.ents.get(b[0]); if (e) this.applyRemote(e, b[1], b[2], b[3], b[4], b[5], b[6], b[7], b[8], b[9]); } break; }
      case 'M': { const e = this.ents.get(m.id); if (e && !e.isLocal) e.ch.punch = 1; break; }
      case 'F': { const e = this.ents.get(m.id); if (!e || e.isLocal) return; this.tracer(e, V(...m.e), WEAPONS[m.w], false); if (this.isHost) this.alertBots(e); break; }
      case 'H': { const t = this.ents.get(m.to); if (t && this.owns(t) && !this.frozen) this.applyDamage(t, m.d, m.by, !!m.h); break; }
      case 'D': { const t = this.ents.get(m.id); if (t) this.killEnt(t, m.by, false); break; }
      case 'P': { const it = this.loot[m.i]; if (it) this.removeLoot(it, false); break; }
      case 'R': if (!this.isHost) this.applyCsPhase(m.phase, m.round, m.score, m.w); break;
      case 'E': this.finish(m.win); break;
      default: break;
    }
  }

  netLeave(id) {
    const e = this.ents.get(id); if (e && e.alive) this.killEnt(e, null, false);
  }

  // ------------------------------------------------------------------ HUD
  banner(text, sec = 3) { const b = $('banner'); b.textContent = text; b.classList.add('on'); this.bannerT = sec; }
  feed(text, mine) { const f = $('feed'), d = document.createElement('div'); d.textContent = text; if (mine) d.className = 'mine'; f.prepend(d); setTimeout(() => d.remove(), 5000); while (f.children.length > 5) f.lastChild.remove(); }
  setPrompt(t) { const p = $('prompt'); if (p.textContent !== t) p.textContent = t; }
  hitMarker(head) { const h = $('hitm'); h.className = 'on' + (head ? ' head' : ''); clearTimeout(this._hm); this._hm = setTimeout(() => (h.className = ''), 130); }

  updateHud(dt) {
    const ps = this.me.alive ? this.me.state : 'dead';
    if (document.body.dataset.ps !== ps) document.body.dataset.ps = ps;
    if (this.bannerT > 0) { this.bannerT -= dt; if (this.bannerT <= 0) $('banner').classList.remove('on'); }
    this.flashV = Math.max(0, this.flashV - dt * 2.5); $('vig').style.opacity = this.flashV;
    this.hudT += dt; if (this.hudT < 0.1) return; this.hudT = 0;
    const m = this.me;
    $('hpbar').style.width = m.hp + '%'; $('hpTxt').textContent = Math.ceil(m.hp); $('arbar').style.width = m.armor + '%';
    $('healsEl').textContent = `🩹 ${m.heals.bandage}   ➕ ${m.heals.medkit}` + (m.using ? `   ⏳ ${m.using.t.toFixed(1)}s` : '');
    $('killsEl').textContent = '☠ ' + m.kills;
    let slots = '';
    m.weapons.forEach((w, i) => {
      if (!w) { slots += `<div class="slot empty" data-slot="${i}">${i + 1} · খালি</div>`; return; }
      const d = WEAPONS[w.id];
      slots += `<div class="slot ${i === m.cur ? 'cur' : ''}" data-slot="${i}">${i + 1} · ${d.name}<b>${m.reload && i === m.cur ? '↻' : w.mag} / ${m.ammo[d.ammo]}</b></div>`;
    });
    $('wslots').innerHTML = slots + (m.cur < 0 || !m.weapons[m.cur] ? '<div class="fist">✊ খালি হাত</div>' : '');
    $('cross').classList.toggle('hidden', !m.alive || m.state !== 'ground');
    { const p = this.world.pois.find((q) => Math.hypot(q.x - m.pos.x, q.z - m.pos.z) < q.r); const t = p ? '📍 ' + p.name : ''; if ($('poiEl').textContent !== t) $('poiEl').textContent = t; }
    if (this.mode === 'br') {
      $('aliveEl').textContent = '👥 ' + this.list.filter((e) => e.alive).length;
      const z = this.zone;
      if (this.t < this.plane.dur + 10) $('zoneEl').textContent = m.state === 'plane' ? 'প্লেনে — F/Space চাপো' : 'নামছো…';
      else if (z) $('zoneEl').textContent = (z.shrinking ? '⚠ জোন ছোট হচ্ছে ' : '⏱ পরের জোন ') + Math.ceil(z.tl) + 's';
    } else {
      const cs = this.cs;
      $('aliveEl').textContent = `👥 ${this.teamAlive(this.me.team)} vs ${this.teamAlive(1 - this.me.team)}`;
      const left = Math.max(0, Math.ceil((cs.phase === 'buy' ? CS.buy : cs.phase === 'fight' ? CS.fight : CS.brk) - cs.t));
      $('zoneEl').textContent = `রাউন্ড ${cs.round} · ${cs.phase === 'buy' ? 'কেনাকাটা' : cs.phase === 'fight' ? 'লড়াই' : 'বিরতি'} ${left}s`;
      $('csbar').innerHTML = `<b>${cs.score[this.me.team]}</b> : <b>${cs.score[1 - this.me.team]}</b> &nbsp; $${m.cash}`;
      if (this.shopOpen && this._shopCash !== m.cash) this.renderShop();
    }
    this.drawMap();
  }

  drawMap() {
    const c = this.mm, x = c.getContext('2d'), S = c.width, k = S / (HALF * 2), m = this.me;
    const X = (v) => (v + HALF) * k;
    x.clearRect(0, 0, S, S); x.fillStyle = 'rgba(40,70,45,.85)'; x.fillRect(0, 0, S, S);
    x.fillStyle = 'rgba(190,190,200,.8)'; for (const b of this.world.buildings) x.fillRect(X(b.x - b.w / 2), X(b.z - b.d / 2), b.w * k, b.d * k);
    x.fillStyle = '#ffe9a0'; x.font = 'bold 9px sans-serif'; x.textAlign = 'center'; for (const p of this.world.pois) x.fillText(p.name, X(p.x), X(p.z));
    if (this.mode === 'br' && this.zone) {
      const z = this.zone; x.lineWidth = 2; x.strokeStyle = '#fff'; x.beginPath(); x.arc(X(z.cx), X(z.cz), z.r * k, 0, 7); x.stroke();
      x.strokeStyle = '#4aa3ff'; x.beginPath(); x.arc(X(z.next.cx), X(z.next.cz), z.next.r * k, 0, 7); x.stroke();
      if (this.t < this.plane.dur + 2) { x.strokeStyle = '#ffe14a'; x.beginPath(); x.moveTo(X(this.plane.sx), X(this.plane.sz)); x.lineTo(X(this.plane.ex), X(this.plane.ez)); x.stroke(); const pp = this.planePos(); x.fillStyle = '#ffe14a'; x.fillRect(X(pp.x) - 3, X(pp.z) - 3, 6, 6); }
    } else if (this.mode === 'cs') { x.strokeStyle = '#fff'; x.strokeRect(X(-CS.bound), X(-CS.bound), CS.bound * 2 * k, CS.bound * 2 * k); }
    for (const e of this.list) if (e.alive && e !== m && e.team === m.team) { x.fillStyle = '#7dffa0'; x.beginPath(); x.arc(X(e.pos.x), X(e.pos.z), 3, 0, 7); x.fill(); }
    const t = this.camTarget(); x.save(); x.translate(X(t.pos.x), X(t.pos.z)); x.rotate(Math.atan2(-Math.sin(m.yaw), Math.cos(m.yaw)));
    x.fillStyle = '#ff5a3c'; x.beginPath(); x.moveTo(0, -7); x.lineTo(5, 5); x.lineTo(-5, 5); x.fill(); x.restore();
  }
}
