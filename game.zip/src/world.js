import * as THREE from 'three';

export const MAP = 400;
export const HALF = MAP / 2;

export function mulberry(seed) {
  let a = seed | 0;
  return function () {
    a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// ---------- spatial grid of AABB colliders ----------
export class Grid {
  constructor(cell = 20) { this.c = cell; this.m = new Map(); this.all = []; }
  add(b) {
    this.all.push(b);
    const c = this.c;
    for (let i = Math.floor(b.x0 / c); i <= Math.floor(b.x1 / c); i++)
      for (let j = Math.floor(b.z0 / c); j <= Math.floor(b.z1 / c); j++) {
        const k = i + ',' + j;
        let a = this.m.get(k); if (!a) { a = []; this.m.set(k, a); }
        a.push(b);
      }
  }
  near(x, z, r, out = new Set()) {
    const c = this.c;
    for (let i = Math.floor((x - r) / c); i <= Math.floor((x + r) / c); i++)
      for (let j = Math.floor((z - r) / c); j <= Math.floor((z + r) / c); j++) {
        const a = this.m.get(i + ',' + j); if (a) for (const b of a) out.add(b);
      }
    return out;
  }
}

// push a circle (pos.x,pos.z,radius r) out of solid boxes. returns true if it hit something
export function moveCircle(grid, pos, r, h) {
  let hit = false;
  for (const b of grid.near(pos.x, pos.z, r + 1)) {
    if (pos.y >= b.y1 - 0.4 || pos.y + h <= b.y0) continue; // stand on top / above / below
    const cx = Math.max(b.x0, Math.min(pos.x, b.x1));
    const cz = Math.max(b.z0, Math.min(pos.z, b.z1));
    let dx = pos.x - cx, dz = pos.z - cz;
    const d2 = dx * dx + dz * dz;
    if (d2 >= r * r) continue;
    hit = true;
    if (d2 > 1e-8) { const d = Math.sqrt(d2); pos.x += (dx / d) * (r - d); pos.z += (dz / d) * (r - d); }
    else { // centre inside the box: push out along the shortest axis
      const l = pos.x - b.x0, rr = b.x1 - pos.x, t = pos.z - b.z0, bt = b.z1 - pos.z;
      const m = Math.min(l, rr, t, bt);
      if (m === l) pos.x = b.x0 - r; else if (m === rr) pos.x = b.x1 + r;
      else if (m === t) pos.z = b.z0 - r; else pos.z = b.z1 + r;
    }
  }
  return hit;
}

// highest surface (0 = ground) the point can stand on
export function groundAt(grid, x, z, y) {
  let g = 0;
  for (const b of grid.near(x, z, 0.3)) {
    if (x > b.x0 - 0.2 && x < b.x1 + 0.2 && z > b.z0 - 0.2 && z < b.z1 + 0.2 && b.y1 <= y + 0.5 && b.y1 > g && !b.noStand) g = b.y1;
  }
  return g;
}

// ray vs AABB colliders; returns nearest distance or Infinity
export function rayHit(grid, o, d, maxD) {
  const seen = new Set(); let best = Infinity;
  const step = grid.c * 0.5;
  for (let t = 0; t <= maxD + step; t += step) {
    const px = o.x + d.x * Math.min(t, maxD), pz = o.z + d.z * Math.min(t, maxD);
    for (const b of grid.near(px, pz, 1)) {
      if (seen.has(b)) continue; seen.add(b);
      let t0 = 0, t1 = best < maxD ? best : maxD;
      for (const [oo, dd, lo, hi] of [[o.x, d.x, b.x0, b.x1], [o.y, d.y, b.y0, b.y1], [o.z, d.z, b.z0, b.z1]]) {
        if (Math.abs(dd) < 1e-9) { if (oo < lo || oo > hi) { t0 = Infinity; break; } continue; }
        let a = (lo - oo) / dd, c = (hi - oo) / dd; if (a > c) { const s = a; a = c; c = s; }
        t0 = Math.max(t0, a); t1 = Math.min(t1, c); if (t0 > t1) { t0 = Infinity; break; }
      }
      if (t0 !== Infinity && t0 < best) best = t0;
    }
  }
  return best;
}

const PALETTE = [0xd9c7a3, 0xc98f7a, 0x9fb7c9, 0xb9c98f, 0xe0d2b4, 0xcfa7b8, 0xa7c7b0];

export function buildWorld(scene, seed, opts = {}) {
  const R = mulberry(seed);
  const grid = new Grid(20);
  const lootSpots = [];
  const buildings = [];
  const roofs = [];
  const csBound = 90;
  const world = { grid, lootSpots, buildings, roofs, csBound, csSpawns: [[], []] };

  const mats = {};
  const M = (c, extra = {}) => mats[c + JSON.stringify(extra)] ||= new THREE.MeshStandardMaterial({ color: c, roughness: 0.9, flatShading: true, ...extra });

  const box = (x0, y0, z0, x1, y1, z1, mat, solid = true) => {
    const m = new THREE.Mesh(new THREE.BoxGeometry(x1 - x0, y1 - y0, z1 - z0), mat);
    m.position.set((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2);
    m.castShadow = solid; m.receiveShadow = true; scene.add(m);
    if (solid) grid.add({ x0, x1, y0, y1, z0, z1 });
    return m;
  };

  // ---------- ground ----------
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(MAP * 3, MAP * 3, 1, 1), M(0x6fae5a));
  ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; scene.add(ground);
  const play = new THREE.Mesh(new THREE.PlaneGeometry(MAP, MAP), M(0x7cc266));
  play.rotation.x = -Math.PI / 2; play.position.y = 0.01; play.receiveShadow = true; scene.add(play);
  // patches of lighter/darker grass
  for (let i = 0; i < 60; i++) {
    const p = new THREE.Mesh(new THREE.CircleGeometry(8 + R() * 18, 14), M(R() < 0.5 ? 0x6bb85a : 0x8ccf72));
    p.rotation.x = -Math.PI / 2; p.position.set((R() - 0.5) * MAP, 0.02, (R() - 0.5) * MAP); scene.add(p);
  }
  // roads
  for (const [w, d, x, z] of [[MAP, 6, 0, 0], [6, MAP, 0, 0], [MAP, 5, 0, 120], [5, MAP, -120, 0]]) {
    const r = new THREE.Mesh(new THREE.BoxGeometry(w, 0.04, d), M(0x55585e)); r.position.set(x, 0.03, z); r.receiveShadow = true; scene.add(r);
  }
  // lake (cosmetic)
  const lake = new THREE.Mesh(new THREE.CircleGeometry(26, 28), new THREE.MeshStandardMaterial({ color: 0x3b8fd4, roughness: 0.2, metalness: 0.3 }));
  lake.rotation.x = -Math.PI / 2; lake.position.set(120, 0.05, -110); scene.add(lake);
  const lakeRect = { x: 120, z: -110, r: 30 };
  // map border walls (invisible-ish low fence)
  for (const [x0, z0, x1, z1] of [[-HALF - 2, -HALF - 2, HALF + 2, -HALF], [-HALF - 2, HALF, HALF + 2, HALF + 2], [-HALF - 2, -HALF, -HALF, HALF], [HALF, -HALF, HALF + 2, HALF]])
    grid.add({ x0, x1, z0, z1, y0: 0, y1: 50, noStand: true });

  // ---------- walls with openings ----------
  function wall(axis, a, b, v, t, h, ops, mat) {
    const seg = (u0, u1, y0, y1) => {
      if (u1 - u0 < 0.01 || y1 - y0 < 0.01) return;
      if (axis === 'x') box(u0, y0, v - t / 2, u1, y1, v + t / 2, mat);
      else box(v - t / 2, y0, u0, v + t / 2, y1, u1, mat);
    };
    let cur = a;
    for (const o of ops.sort((p, q) => p.a - q.a)) {
      seg(cur, o.a, 0, h);
      if (o.y0 > 0) seg(o.a, o.b, 0, o.y0);
      seg(o.a, o.b, o.y1, h);
      cur = o.b;
    }
    seg(cur, b, 0, h);
  }

  const taken = []; // rects of buildings for placement tests
  function building(cx, cz, w, d, tier) {
    const h = 3.3, t = 0.3;
    const wallM = M(PALETTE[Math.floor(R() * PALETTE.length)]);
    const x0 = cx - w / 2, x1 = cx + w / 2, z0 = cz - d / 2, z1 = cz + d / 2;
    const doorSide = Math.floor(R() * 4);
    let doorPt = null;
    const door = (len, off) => ({ a: off - 1, b: off + 1, y0: 0, y1: 2.5 });
    const win = (off) => ({ a: off - 0.9, b: off + 0.9, y0: 0.9, y1: 2.1 });
    const opsFor = (side, mid, len) => {
      const o = [];
      if (side === doorSide) {
        const dc = mid + (R() - 0.5) * (len - 5); o.push(door(len, dc));
        doorPt = side < 2 ? { x: dc, z: side === 0 ? z0 : z1 } : { x: side === 2 ? x0 : x1, z: dc };
      }
      const wo = mid + (side === doorSide ? (R() < 0.5 ? -1 : 1) * (len / 2 - 2.2) : (R() - 0.5) * (len - 4));
      const ok = o.every((q) => Math.abs((q.a + q.b) / 2 - wo) > 2.6);
      if (ok) o.push(win(wo));
      return o;
    };
    wall('x', x0, x1, z0, t, h, opsFor(0, cx, w), wallM);
    wall('x', x0, x1, z1, t, h, opsFor(1, cx, w), wallM);
    wall('z', z0, z1, x0, t, h, opsFor(2, cz, d), wallM);
    wall('z', z0, z1, x1, t, h, opsFor(3, cz, d), wallM);
    // floor + roof
    const fl = new THREE.Mesh(new THREE.BoxGeometry(w, 0.1, d), M(0x8d6e4c)); fl.position.set(cx, 0.05, cz); fl.receiveShadow = true; scene.add(fl);
    const roof = box(x0 - 0.25, h, z0 - 0.25, x1 + 0.25, h + 0.3, z1 + 0.25, M(R() < 0.5 ? 0x9b4a3c : 0x5d6470));
    grid.all[grid.all.length - 1].noStand = true; // parachutists slide off roofs instead of standing on them
    roofs.push({ mesh: roof, x0, x1, z0, z1 });
    // interior divider with a doorway
    if (w > 11 && d > 9) {
      const dx = cx + (R() - 0.5) * 2;
      const dOff = (R() - 0.5) * 3;
      wall('z', z0 + t / 2, z1 - t / 2, dx, 0.25, h, [{ a: cz - 1.2 + dOff, b: cz + 1.2 + dOff, y0: 0, y1: 2.5 }], wallM);
    }
    // furniture = cover inside
    const wood = M(0x7a5230), crate = M(0xb58a50);
    const nCover = 2 + Math.floor(R() * 3);
    for (let i = 0; i < nCover; i++) {
      let fx, fz, tr = 0;
      do { fx = x0 + 1.6 + R() * (w - 3.2); fz = z0 + 1.6 + R() * (d - 3.2); } while (tr++ < 10 && doorPt && Math.hypot(fx - doorPt.x, fz - doorPt.z) < 3.8);
      if (doorPt && Math.hypot(fx - doorPt.x, fz - doorPt.z) < 3.8) continue; // never block the door
      if (R() < 0.5) box(fx - 0.5, 0.1, fz - 0.5, fx + 0.5, 1.1, fz + 0.5, crate);
      else box(fx - 0.8, 0.1, fz - 0.4, fx + 0.8, 0.85, fz + 0.4, wood);
    }
    // loot spots inside
    const nLoot = 2 + Math.floor(w * d / 60);
    for (let i = 0; i < nLoot; i++)
      lootSpots.push({ x: x0 + 1.2 + R() * (w - 2.4), z: z0 + 1.2 + R() * (d - 2.4), tier: tier + 1 });
    buildings.push({ x: cx, z: cz, w, d });
    taken.push({ x0: x0 - 5, x1: x1 + 5, z0: z0 - 5, z1: z1 + 5 });
  }

  // clear zones: clash-squad spawns
  const spawnA = [[-csBound + 12, -14], [-csBound + 12, 14]];
  const spawnB = [[csBound - 12, -14], [csBound - 12, 14]];
  world.csSpawns = [spawnA, spawnB];
  const clearPts = [...spawnA, ...spawnB];
  const nearClear = (x, z, r) => clearPts.some(([a, b]) => Math.hypot(a - x, b - z) < r);
  const overlaps = (x0, x1, z0, z1) => taken.some((q) => x0 < q.x1 && x1 > q.x0 && z0 < q.z1 && z1 > q.z0);
  const onRoad = (x, z, m) => Math.abs(z) < 3 + m || Math.abs(x) < 3 + m || Math.abs(z - 120) < 2.5 + m || Math.abs(x + 120) < 2.5 + m;

  // buildings: 8 in the middle (also used by Clash Squad), rest spread over the map
  let placed = 0, tries = 0;
  const target = opts.buildings || 26;
  while (placed < target && tries++ < 3000) {
    const mid = placed < 9;
    const range = mid ? 70 : HALF - 22;
    const w = 8 + Math.floor(R() * 9), d = 8 + Math.floor(R() * 7);
    const cx = Math.round((R() - 0.5) * 2 * range), cz = Math.round((R() - 0.5) * 2 * range);
    if (onRoad(cx, cz, Math.max(w, d) / 2) || nearClear(cx, cz, 20)) continue;
    if (Math.hypot(cx - lakeRect.x, cz - lakeRect.z) < lakeRect.r + Math.max(w, d)) continue;
    if (overlaps(cx - w / 2, cx + w / 2, cz - d / 2, cz + d / 2)) continue;
    building(cx, cz, w, d, mid ? 1 : 0);
    placed++;
  }

  // ---------- trees & rocks (instanced) ----------
  const free = (x, z, r) => !overlaps(x - r, x + r, z - r, z + r) && !onRoad(x, z, 1.5) && !nearClear(x, z, 9) && Math.hypot(x - lakeRect.x, z - lakeRect.z) > lakeRect.r + 2;
  const trees = [], rocks = [];
  for (let i = 0; i < 700 && trees.length < 300; i++) {
    const x = (R() - 0.5) * (MAP - 8), z = (R() - 0.5) * (MAP - 8);
    if (free(x, z, 1.2)) trees.push({ x, z, s: 0.8 + R() * 0.7 });
  }
  for (let i = 0; i < 400 && rocks.length < 110; i++) {
    const x = (R() - 0.5) * (MAP - 8), z = (R() - 0.5) * (MAP - 8);
    if (free(x, z, 2)) rocks.push({ x, z, s: 0.9 + R() * 2.2, ry: R() * 6 });
  }
  const dummy = new THREE.Object3D();
  const inst = (geo, mat, list, place) => {
    const im = new THREE.InstancedMesh(geo, mat, list.length);
    list.forEach((o, i) => { place(o, dummy); dummy.updateMatrix(); im.setMatrixAt(i, dummy.matrix); });
    im.castShadow = true; im.receiveShadow = true; scene.add(im); return im;
  };
  inst(new THREE.CylinderGeometry(0.22, 0.3, 2.4, 6), M(0x6b4a2b), trees, (o, d) => { d.position.set(o.x, 1.2 * o.s, o.z); d.scale.setScalar(o.s); d.rotation.set(0, 0, 0); });
  inst(new THREE.ConeGeometry(1.7, 3.2, 7), M(0x2f8f4a), trees, (o, d) => { d.position.set(o.x, 3.4 * o.s, o.z); d.scale.setScalar(o.s); d.rotation.set(0, 0, 0); });
  inst(new THREE.ConeGeometry(1.2, 2.6, 7), M(0x3aa65a), trees, (o, d) => { d.position.set(o.x, 5 * o.s, o.z); d.scale.setScalar(o.s); d.rotation.set(0, 0, 0); });
  inst(new THREE.DodecahedronGeometry(1, 0), M(0x8b8f96), rocks, (o, d) => { d.position.set(o.x, 0.55 * o.s, o.z); d.scale.set(o.s, o.s * 0.75, o.s); d.rotation.set(0, o.ry, 0); });
  for (const o of trees) grid.add({ x0: o.x - 0.3, x1: o.x + 0.3, z0: o.z - 0.3, z1: o.z + 0.3, y0: 0, y1: 5, noStand: true });
  for (const o of rocks) { const r = o.s * 0.8; grid.add({ x0: o.x - r, x1: o.x + r, z0: o.z - r, z1: o.z + r, y0: 0, y1: o.s * 0.9 }); }

  // loose loot outside
  for (let i = 0; i < 70; i++) {
    const x = (R() - 0.5) * (MAP - 20), z = (R() - 0.5) * (MAP - 20);
    if (!overlaps(x, x, z, z) && !nearClear(x, z, 0)) lootSpots.push({ x, z, tier: 0 });
  }

  // fade roofs when the player is inside
  world.update = (p) => {
    for (const r of roofs) r.mesh.visible = !(p.y < 3 && p.x > r.x0 && p.x < r.x1 && p.z > r.z0 && p.z < r.z1);
  };
  return world;
}
