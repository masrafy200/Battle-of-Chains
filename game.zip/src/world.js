import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';

export const MAP = 800;
export const HALF = MAP / 2;

export function mulberry(seed) {
  let a = seed | 0;
  return function () {
    a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// ---------- spatial grid of AABB colliders ----------
export class Grid {
  constructor(cell = 20) { this.c = cell; this.m = new Map(); this.all = []; }
  add(b) {
    this.all.push(b);
    const c = this.c;
    for (let i = Math.floor(b.x0 / c); i <= Math.floor(b.x1 / c); i++)
      for (let j = Math.floor(b.z0 / c); j <= Math.floor(b.z1 / c); j++) {
        const k = i + ',' + j;
        let a = this.m.get(k); if (!a) { a = []; this.m.set(k, a); }
        a.push(b);
      }
  }
  near(x, z, r, out = new Set()) {
    const c = this.c;
    for (let i = Math.floor((x - r) / c); i <= Math.floor((x + r) / c); i++)
      for (let j = Math.floor((z - r) / c); j <= Math.floor((z + r) / c); j++) {
        const a = this.m.get(i + ',' + j); if (a) for (const b of a) out.add(b);
      }
    return out;
  }
}

// push a circle (pos.x,pos.z,radius r) out of solid boxes. returns true if it hit something
export function moveCircle(grid, pos, r, h) {
  let hit = false;
  for (const b of grid.near(pos.x, pos.z, r + 1)) {
    if (pos.y >= b.y1 - 0.4 || pos.y + h <= b.y0) continue; // stand on top / above / below
    const cx = Math.max(b.x0, Math.min(pos.x, b.x1));
    const cz = Math.max(b.z0, Math.min(pos.z, b.z1));
    let dx = pos.x - cx, dz = pos.z - cz;
    const d2 = dx * dx + dz * dz;
    if (d2 >= r * r) continue;
    hit = true;
    if (d2 > 1e-8) { const d = Math.sqrt(d2); pos.x += (dx / d) * (r - d); pos.z += (dz / d) * (r - d); }
    else { // centre inside the box: push out along the shortest axis
      const l = pos.x - b.x0, rr = b.x1 - pos.x, t = pos.z - b.z0, bt = b.z1 - pos.z;
      const m = Math.min(l, rr, t, bt);
      if (m === l) pos.x = b.x0 - r; else if (m === rr) pos.x = b.x1 + r;
      else if (m === t) pos.z = b.z0 - r; else pos.z = b.z1 + r;
    }
  }
  return hit;
}

// highest surface (0 = ground) the point can stand on
export function groundAt(grid, x, z, y) {
  let g = 0;
  for (const b of grid.near(x, z, 0.3)) {
    if (x > b.x0 - 0.2 && x < b.x1 + 0.2 && z > b.z0 - 0.2 && z < b.z1 + 0.2 && b.y1 <= y + 0.5 && b.y1 > g && !b.noStand) g = b.y1;
  }
  return g;
}

// ray vs AABB colliders; returns nearest distance or Infinity
export function rayHit(grid, o, d, maxD) {
  const seen = new Set(); let best = Infinity;
  const step = grid.c * 0.5;
  for (let t = 0; t <= maxD + step; t += step) {
    const px = o.x + d.x * Math.min(t, maxD), pz = o.z + d.z * Math.min(t, maxD);
    for (const b of grid.near(px, pz, 1)) {
      if (seen.has(b)) continue; seen.add(b);
      let t0 = 0, t1 = best < maxD ? best : maxD;
      for (const [oo, dd, lo, hi] of [[o.x, d.x, b.x0, b.x1], [o.y, d.y, b.y0, b.y1], [o.z, d.z, b.z0, b.z1]]) {
        if (Math.abs(dd) < 1e-9) { if (oo < lo || oo > hi) { t0 = Infinity; break; } continue; }
        let a = (lo - oo) / dd, c = (hi - oo) / dd; if (a > c) { const s = a; a = c; c = s; }
        t0 = Math.max(t0, a); t1 = Math.min(t1, c); if (t0 > t1) { t0 = Infinity; break; }
      }
      if (t0 !== Infinity && t0 < best) best = t0;
    }
  }
  return best;
}

const PALETTE = [0xd9c7a3, 0xc98f7a, 0x9fb7c9, 0xb9c98f, 0xe0d2b4, 0xcfa7b8, 0xa7c7b0];
const CONTAINER_COLORS = [0xc0392b, 0x2e86c1, 0xd4ac0d, 0x229954, 0x7d3c98, 0xe67e22];

export function buildWorld(scene, seed, opts = {}) {
  const R = mulberry(seed);
  const grid = new Grid(20);
  const lootSpots = [], buildings = [], roofs = [], pois = [];
  const csBound = 90;
  const world = { grid, lootSpots, buildings, roofs, pois, csBound, csSpawns: [[], []] };

  // ---------- materials + merged static geometry (few draw calls) ----------
  let matId = 0; const mats = {};
  const M = (c, extra = {}) => {
    const k = c + JSON.stringify(extra);
    if (!mats[k]) { mats[k] = new THREE.MeshStandardMaterial({ color: c, roughness: 0.9, flatShading: true, ...extra }); mats[k].userData.id = ++matId; }
    return mats[k];
  };
  const parts = new Map(), CH = 200;
  const addPart = (mat, x0, y0, z0, x1, y1, z1) => {
    const g = new THREE.BoxGeometry(x1 - x0, y1 - y0, z1 - z0);
    g.translate((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2);
    const key = mat.userData.id + '|' + Math.floor((x0 + x1) / 2 / CH) + '|' + Math.floor((z0 + z1) / 2 / CH);
    let p = parts.get(key); if (!p) { p = { mat, geos: [] }; parts.set(key, p); }
    p.geos.push(g);
  };
  const box = (x0, y0, z0, x1, y1, z1, mat, solid = true, sep = false) => {
    if (solid) grid.add({ x0, x1, y0, y1, z0, z1 });
    if (sep) {
      const m = new THREE.Mesh(new THREE.BoxGeometry(x1 - x0, y1 - y0, z1 - z0), mat);
      m.position.set((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2); m.castShadow = true; m.receiveShadow = true; scene.add(m); return m;
    }
    addPart(mat, x0, y0, z0, x1, y1, z1); return null;
  };
  const flush = () => {
    for (const p of parts.values()) {
      const g = mergeGeometries(p.geos, false); p.geos.forEach((q) => q.dispose());
      const m = new THREE.Mesh(g, p.mat); m.castShadow = true; m.receiveShadow = true; scene.add(m);
    }
    parts.clear();
  };

  // ---------- ground ----------
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(MAP * 3, MAP * 3), M(0x6fae5a));
  ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; scene.add(ground);
  const play = new THREE.Mesh(new THREE.PlaneGeometry(MAP, MAP), M(0x7cc266));
  play.rotation.x = -Math.PI / 2; play.position.y = 0.01; play.receiveShadow = true; scene.add(play);
  for (let i = 0; i < 90; i++) {
    const p = new THREE.Mesh(new THREE.CircleGeometry(10 + R() * 26, 14), M(R() < 0.5 ? 0x6bb85a : 0x8ccf72));
    p.rotation.x = -Math.PI / 2; p.position.set((R() - 0.5) * MAP, 0.02, (R() - 0.5) * MAP); scene.add(p);
  }
  const roadM = M(0x55585e);
  const road = (w, d, x, z) => { const r = new THREE.Mesh(new THREE.BoxGeometry(w, 0.04, d), roadM); r.position.set(x, 0.03, z); r.receiveShadow = true; scene.add(r); };
  road(MAP, 7, 0, 0); road(7, MAP, 0, 0); road(MAP, 6, 0, 200); road(6, MAP, -200, 0); road(6, MAP, 200, 0); road(MAP, 6, 0, -200);
  const roadAt = (x, z, m) => Math.abs(z) < 3.5 + m || Math.abs(x) < 3.5 + m || Math.abs(z - 200) < 3 + m || Math.abs(x + 200) < 3 + m || Math.abs(x - 200) < 3 + m || Math.abs(z + 200) < 3 + m;
  const lake = new THREE.Mesh(new THREE.CircleGeometry(34, 28), new THREE.MeshStandardMaterial({ color: 0x3b8fd4, roughness: 0.2, metalness: 0.3 }));
  lake.rotation.x = -Math.PI / 2; lake.position.set(120, 0.05, -110); scene.add(lake);
  const lakeRect = { x: 120, z: -110, r: 38 };
  const sea = new THREE.Mesh(new THREE.PlaneGeometry(80, 220), new THREE.MeshStandardMaterial({ color: 0x2a78c2, roughness: 0.2, metalness: 0.3 }));
  sea.rotation.x = -Math.PI / 2; sea.position.set(HALF - 40, 0.05, 240); scene.add(sea);
  for (const [x0, z0, x1, z1] of [[-HALF - 2, -HALF - 2, HALF + 2, -HALF], [-HALF - 2, HALF, HALF + 2, HALF + 2], [-HALF - 2, -HALF, -HALF, HALF], [HALF, -HALF, HALF + 2, HALF]])
    grid.add({ x0, x1, z0, z1, y0: 0, y1: 50, noStand: true });

  // ---------- walls with openings ----------
  function wall(axis, a, b, v, t, h, ops, mat) {
    const seg = (u0, u1, y0, y1) => {
      if (u1 - u0 < 0.01 || y1 - y0 < 0.01) return;
      if (axis === 'x') box(u0, y0, v - t / 2, u1, y1, v + t / 2, mat);
      else box(v - t / 2, y0, u0, v + t / 2, y1, u1, mat);
    };
    let cur = a;
    for (const o of [...ops].sort((p, q) => p.a - q.a)) { seg(cur, o.a, 0, h); if (o.y0 > 0) seg(o.a, o.b, 0, o.y0); seg(o.a, o.b, o.y1, h); cur = o.b; }
    seg(cur, b, 0, h);
  }

  const taken = [];
  const take = (x0, x1, z0, z1, m = 5) => taken.push({ x0: x0 - m, x1: x1 + m, z0: z0 - m, z1: z1 + m });
  const wood = M(0x7a5230), crateM = M(0xb58a50), steel = M(0x7b8794), whiteM = M(0xf2f4f6), redM = M(0xd63031), olive = M(0x56633a), darkM = M(0x2d3436);

  // building with real interior. o: {h,color,roof,doors:[sides],doorW,rooms,furn,cover,loot,tag,windows}
  function building(cx, cz, w, d, tier, o = {}) {
    const h = o.h || 3.3, t = 0.3, dw = o.doorW || 1;
    const wallM = M(o.color || PALETTE[Math.floor(R() * PALETTE.length)]);
    const x0 = cx - w / 2, x1 = cx + w / 2, z0 = cz - d / 2, z1 = cz + d / 2;
    const doorSides = o.doors || [Math.floor(R() * 4)];
    const doorPts = [];
    const opsFor = (side, mid, len) => {
      const ops = [];
      if (doorSides.includes(side)) {
        const dc = mid + (R() - 0.5) * Math.max(0, len - 5 - 2 * dw);
        ops.push({ a: dc - dw, b: dc + dw, y0: 0, y1: Math.min(2.6 + (dw > 1 ? 1 : 0), h - 0.4) });
        doorPts.push(side < 2 ? { x: dc, z: side === 0 ? z0 : z1 } : { x: side === 2 ? x0 : x1, z: dc });
      }
      const nWin = o.windows ?? 1;
      for (let k = 0; k < nWin; k++) {
        const wo = mid + (R() - 0.5) * (len - 4);
        if (ops.every((q) => Math.abs((q.a + q.b) / 2 - wo) > 2.6 + dw)) ops.push({ a: wo - 0.9, b: wo + 0.9, y0: 0.9, y1: Math.min(2.1, h - 0.4) });
      }
      return ops;
    };
    wall('x', x0, x1, z0, t, h, opsFor(0, cx, w), wallM);
    wall('x', x0, x1, z1, t, h, opsFor(1, cx, w), wallM);
    wall('z', z0, z1, x0, t, h, opsFor(2, cz, d), wallM);
    wall('z', z0, z1, x1, t, h, opsFor(3, cz, d), wallM);
    box(x0, 0, z0, x1, 0.1, z1, M(o.floor || 0x8d6e4c), false);
    const roof = box(x0 - 0.25, h, z0 - 0.25, x1 + 0.25, h + 0.3, z1 + 0.25, M(o.roof || (R() < 0.5 ? 0x9b4a3c : 0x5d6470)), true, true);
    grid.all[grid.all.length - 1].noStand = true;
    roofs.push({ mesh: roof, x0, x1, z0, z1 });

    const k = o.rooms ?? (w > 11 && d > 9 ? 1 : 0), divX = [];
    for (let i = 0; i < k; i++) {
      const dx = x0 + ((i + 1) * w) / (k + 1) + (R() - 0.5) * 1.5, dOff = (R() - 0.5) * (d - 6);
      wall('z', z0 + t / 2, z1 - t / 2, dx, 0.25, h, [{ a: cz - 1.2 + dOff, b: cz + 1.2 + dOff, y0: 0, y1: Math.min(2.6, h - 0.4) }], wallM);
      divX.push(dx);
    }
    const nCover = o.cover ?? 2 + Math.floor(R() * 3);
    for (let i = 0; i < nCover; i++) {
      let fx, fz, tr = 0, bad;
      do {
        fx = x0 + 1.6 + R() * (w - 3.2); fz = z0 + 1.6 + R() * (d - 3.2);
        bad = doorPts.some((p) => Math.hypot(fx - p.x, fz - p.z) < 3.8) || divX.some((q) => Math.abs(fx - q) < 2.4);
      } while (bad && tr++ < 10);
      if (bad) continue;
      const kind = o.furn || 'crate';
      if (kind === 'bed') { box(fx - 0.5, 0.1, fz - 1.0, fx + 0.5, 0.6, fz + 1.0, whiteM); box(fx - 0.5, 0.6, fz, fx + 0.5, 0.7, fz + 1.0, M(0x74b9ff), false); }
      else if (kind === 'machine') box(fx - 1.2, 0.1, fz - 1.2, fx + 1.2, 2.4, fz + 1.2, R() < 0.5 ? steel : M(0xe1b12c));
      else if (R() < 0.5) box(fx - 0.5, 0.1, fz - 0.5, fx + 0.5, 1.1, fz + 0.5, crateM);
      else box(fx - 0.8, 0.1, fz - 0.4, fx + 0.8, 0.85, fz + 0.4, wood);
    }
    const nLoot = o.loot ?? 2 + Math.floor((w * d) / 60);
    for (let i = 0; i < nLoot; i++) lootSpots.push({ x: x0 + 1.2 + R() * (w - 2.4), z: z0 + 1.2 + R() * (d - 2.4), tier: tier + 1, tag: o.tag });
    buildings.push({ x: cx, z: cz, w, d });
    take(x0, x1, z0, z1);
  }

  const car = (x, z, alongX, col) => {
    const L = 4.2, W = 1.9;
    if (alongX) { box(x - L / 2, 0.25, z - W / 2, x + L / 2, 1.25, z + W / 2, M(col)); box(x - 1, 1.25, z - 0.8, x + 1, 1.95, z + 0.8, M(0x95c8e8)); }
    else { box(x - W / 2, 0.25, z - L / 2, x + W / 2, 1.25, z + L / 2, M(col)); box(x - 0.8, 1.25, z - 1, x + 0.8, 1.95, z + 1, M(0x95c8e8)); }
  };
  const truck = (x, z, alongX, col) => {
    if (alongX) { box(x - 3.5, 0.4, z - 1.3, x + 2, 3.0, z + 1.3, M(col)); box(x + 2, 0.4, z - 1.3, x + 3.8, 2.2, z + 1.3, darkM); }
    else { box(x - 1.3, 0.4, z - 3.5, x + 1.3, 3.0, z + 2, M(col)); box(x - 1.3, 0.4, z + 2, x + 1.3, 2.2, z + 3.8, darkM); }
  };
  const pad = (cx, cz, w, d, col) => { box(cx - w / 2, 0, cz - d / 2, cx + w / 2, 0.06, cz + d / 2, M(col), false); take(cx - w / 2, cx + w / 2, cz - d / 2, cz + d / 2, 4); };
  const poi = (name, x, z, r) => pois.push({ name, x, z, r });
  const loot = (x, z, tier, tag, n = 1) => { for (let i = 0; i < n; i++) lootSpots.push({ x: x + (R() - 0.5) * 6, z: z + (R() - 0.5) * 6, tier, tag }); };

  // ====================== POIs ======================
  // 1) Market town (centre, also the Clash Squad arena)
  (function market() {
    const cx = 0, cz = 0; poi('বাজার', cx, cz, 55);
    pad(cx, cz, 110, 100, 0xa8a08a);
    const shop = (x, z, w, d, side) => building(x, z, w, d, 2, { h: 3.6, doors: [side], color: PALETTE[Math.floor(R() * PALETTE.length)], cover: 2, furn: 'crate', tag: 'gun' });
    for (const sx of [-1, 1]) for (let i = 0; i < 4; i++) shop(sx * 17, -32 + i * 22 + (R() - 0.5) * 3, 9 + Math.floor(R() * 3), 9, sx < 0 ? 3 : 2);
    // stalls
    for (let i = 0; i < 6; i++) {
      const sx = (R() < 0.5 ? -1 : 1) * (5 + R() * 3), sz = -38 + i * 15 + R() * 4, col = [0xe74c3c, 0x3498db, 0xf1c40f, 0x27ae60][i % 4];
      for (const [a, b] of [[-1.2, -0.8], [1.2, -0.8], [-1.2, 0.8], [1.2, 0.8]]) box(sx + a - 0.08, 0, sz + b - 0.08, sx + a + 0.08, 2.3, sz + b + 0.08, wood, false);
      box(sx - 1.6, 2.3, sz - 1.2, sx + 1.6, 2.45, sz + 1.2, M(col), false);
      box(sx - 1.1, 0.1, sz - 0.5, sx + 1.1, 1.0, sz + 0.5, wood);
    }
    box(-2.5, 0, -2.5, 2.5, 0.9, 2.5, M(0x95a5a6)); box(-0.8, 0.9, -0.8, 0.8, 2.2, 0.8, M(0x95a5a6)); // fountain/monument
    car(-8, 12, false, 0xc0392b); car(9, -14, false, 0x2980b9); car(-8, -30, false, 0xf39c12);
  })();

  // 2) Hospital
  (function hospital() {
    const cx = -260, cz = -220; poi('হাসপাতাল', cx, cz, 50);
    pad(cx, cz, 78, 62, 0xb8c0c8);
    building(cx, cz, 36, 20, 2, { h: 4.6, color: 0xeef2f5, roof: 0xb0c4d6, rooms: 3, furn: 'bed', cover: 5, windows: 3, doors: [1, 0], loot: 8, tag: 'med' });
    building(cx + 30, cz + 2, 16, 12, 2, { h: 4, color: 0xe6ecf0, roof: 0xb0c4d6, rooms: 1, furn: 'bed', cover: 3, doors: [2], loot: 4, tag: 'med' });
    building(cx - 26, cz + 22, 12, 9, 1, { h: 3.4, color: 0xd9e2e8, doors: [0], cover: 2, tag: 'med' });
    box(cx - 3, 4.7, cz + 9.6, cx + 3, 5.3, cz + 10.4, redM, false); box(cx - 0.8, 4.0, cz + 9.6, cx + 0.8, 6.0, cz + 10.4, redM, false); // cross
    truck(cx - 14, cz + 26, true, 0xffffff); truck(cx + 6, cz + 28, true, 0xffffff); car(cx + 24, cz + 24, true, 0xbdc3c7); car(cx - 34, cz - 22, false, 0x34495e);
  })();

  // 3) Army camp
  (function army() {
    const cx = 250, cz = -250; poi('আর্মি ক্যাম্প', cx, cz, 55);
    pad(cx, cz, 96, 84, 0x8a8f6a);
    const fw = 90, fd = 76, h = 2.4, g = { y0: 0, y1: h };
    wall('x', cx - fw / 2, cx + fw / 2, cz - fd / 2, 0.5, h, [{ a: cx - 4, b: cx + 4, ...g }], M(0x8d8f77));
    wall('x', cx - fw / 2, cx + fw / 2, cz + fd / 2, 0.5, h, [], M(0x8d8f77));
    wall('z', cz - fd / 2, cz + fd / 2, cx - fw / 2, 0.5, h, [{ a: cz - 4, b: cz + 4, ...g }], M(0x8d8f77));
    wall('z', cz - fd / 2, cz + fd / 2, cx + fw / 2, 0.5, h, [{ a: cz + 10, b: cz + 18, ...g }], M(0x8d8f77));
    building(cx - 22, cz - 12, 16, 9, 2, { h: 3.4, color: 0x6f7a52, roof: 0x4b5338, doors: [1], cover: 4, loot: 5, tag: 'gun' });
    building(cx - 22, cz + 12, 16, 9, 2, { h: 3.4, color: 0x6f7a52, roof: 0x4b5338, doors: [0], cover: 4, loot: 5, tag: 'gun' });
    building(cx + 22, cz, 14, 11, 3, { h: 3.6, color: 0x5d6746, roof: 0x3d4430, doors: [2], rooms: 1, cover: 4, loot: 7, tag: 'gun' });
    for (let i = 0; i < 3; i++) { const tx = cx - 4 + i * 11, tz = cz + 24; box(tx - 2.5, 0, tz - 1.8, tx + 2.5, 2.4, tz + 1.8, olive); box(tx - 2.7, 2.4, tz - 2.0, tx + 2.7, 2.65, tz + 2.0, M(0x445030)); loot(tx, tz + 4, 2, 'gun'); }
    for (const [tx, tz] of [[cx - fw / 2 + 4, cz - fd / 2 + 4], [cx + fw / 2 - 4, cz - fd / 2 + 4], [cx + fw / 2 - 4, cz + fd / 2 - 4], [cx - fw / 2 + 4, cz + fd / 2 - 4]]) {
      for (const [a, b] of [[-1.2, -1.2], [1.2, -1.2], [-1.2, 1.2], [1.2, 1.2]]) box(tx + a - 0.2, 0, tz + b - 0.2, tx + a + 0.2, 6, tz + b + 0.2, wood);
      box(tx - 1.8, 6, tz - 1.8, tx + 1.8, 6.3, tz + 1.8, wood, true); box(tx - 2, 7.8, tz - 2, tx + 2, 8.0, tz + 2, darkM, false);
    }
    for (let i = 0; i < 9; i++) { const sx = cx - 20 + i * 5, sz = cz - 2 + (i % 2) * 1.5; box(sx - 1.4, 0, sz - 0.4, sx + 1.4, 0.9, sz + 0.4, M(0xc2b280)); }
    truck(cx + 10, cz + 28, true, 0x4b5338); truck(cx + 30, cz - 24, false, 0x4b5338); car(cx + 36, cz + 14, false, 0x556b2f);
  })();

  // 4) Factory
  (function factory() {
    const cx = -250, cz = 230; poi('ফ্যাক্টরি', cx, cz, 60);
    pad(cx, cz, 100, 74, 0x9a9a98);
    building(cx, cz, 44, 26, 2, { h: 9, color: 0x9aa2a8, roof: 0x4d545a, doors: [0, 1], doorW: 2.2, rooms: 2, furn: 'machine', cover: 8, windows: 3, loot: 12 });
    for (let i = 0; i < 3; i++) box(cx - 12 + i * 12 - 0.5, 0.1, cz - 4, cx - 12 + i * 12 + 0.5, 4, cz - 3, steel, false);
    box(cx + 22, 0, cz - 38, cx + 25, 28, cz - 35, M(0x8a5a44)); // chimney
    for (let i = 0; i < 3; i++) box(cx + 28 - i * 0.0, 0, cz + 20 + i * 8 - 3, cx + 34, 6, cz + 20 + i * 8 + 3, steel); // tanks
    building(cx - 40, cz - 26, 14, 10, 1, { h: 3.6, color: 0xc9b99a, doors: [1], cover: 3 });
    for (let r = 0; r < 3; r++) for (let c = 0; c < 4; c++) { const x = cx - 36 + c * 4, z = cz + 30 + r * 4; box(x - 1.1, 0, z - 1.1, x + 1.1, 1.3, z + 1.1, crateM); if ((r + c) % 2) box(x - 1.1, 1.3, z - 1.1, x + 1.1, 2.6, z + 1.1, wood); }
    loot(cx - 30, cz + 34, 2, null, 3); truck(cx + 36, cz + 4, false, 0xd35400);
  })();

  // 5) Railway station
  (function station() {
    const cx = -20, cz = -330; poi('রেল স্টেশন', cx, cz, 70);
    pad(cx, cz + 10, 150, 40, 0xa9a9a9);
    for (const tz of [cz - 6, cz + 6]) {
      for (const rz of [-0.72, 0.72]) box(cx - 140, 0.1, tz + rz - 0.07, cx + 140, 0.25, tz + rz + 0.07, M(0x555d66), false);
      for (let x = cx - 140; x < cx + 140; x += 1.5) box(x, 0, tz - 1.4, x + 0.4, 0.1, tz + 1.4, wood, false);
    }
    box(cx - 55, 0, cz - 2.5, cx + 55, 0.95, cz + 2.5, M(0xb2b2ae)); // platform (jump on it)
    for (let i = 0; i < 4; i++) building(cx - 50 + i * 16.5, cz - 6, 15, 3.6, 2, { h: 3.4, color: [0x2e86c1, 0xc0392b, 0x229954, 0xd4ac0d][i], roof: 0x333a40, doors: [0, 1], doorW: 1, windows: 2, cover: 1, loot: 2 });
    building(cx + 30, cz + 20, 22, 10, 2, { h: 4, color: 0xd8c9a7, roof: 0x7b3f30, doors: [0], rooms: 1, cover: 3, loot: 5 });
    building(cx - 30, cz + 20, 9, 7, 1, { h: 3.4, color: 0xc7b898, doors: [0], cover: 2 });
    for (let i = 0; i < 6; i++) { const px = cx - 45 + i * 18; box(px - 0.25, 0, cz - 1.5, px + 0.25, 4, cz - 1.0, steel); }
    box(cx - 55, 4.0, cz - 3, cx + 55, 4.25, cz + 3, M(0x5d6d7e), true, true); grid.all[grid.all.length - 1].noStand = true;
    loot(cx, cz, 2, null, 4);
  })();

  // 6) Port / container yard
  (function port() {
    const cx = 280, cz = 270; poi('বন্দর', cx, cz, 60);
    pad(cx, cz, 110, 120, 0x8f959b);
    building(cx - 30, cz - 40, 30, 16, 2, { h: 6, color: 0xaab7b8, roof: 0x566573, doors: [1, 3], doorW: 2, rooms: 1, cover: 5, loot: 7 });
    for (let r = 0; r < 5; r++) for (let c = 0; c < 4; c++) {
      if (R() < 0.18) continue; const x = cx - 30 + c * 8.5, z = cz - 12 + r * 6.5, col = CONTAINER_COLORS[Math.floor(R() * 6)];
      box(x - 3, 0, z - 1.2, x + 3, 2.6, z + 1.2, M(col)); if (R() < 0.45) box(x - 3, 2.6, z - 1.2, x + 3, 5.2, z + 1.2, M(CONTAINER_COLORS[Math.floor(R() * 6)]));
    }
    for (const sx of [-12, 12]) { box(cx + 30 + sx - 0.5, 0, cz + 30 - 0.5, cx + 30 + sx + 0.5, 20, cz + 30 + 0.5, M(0xe67e22)); }
    box(cx + 16, 20, cz + 29, cx + 54, 21.2, cz + 31, M(0xe67e22), false);
    building(cx + 30, cz - 40, 12, 9, 1, { h: 3.4, color: 0xd5dbdb, doors: [2], cover: 2 });
    loot(cx, cz + 40, 2, null, 4); truck(cx - 38, cz + 22, true, 0x2e86c1);
  })();

  // ---------- generic buildings ----------
  const spawnA = [[-csBound + 12, -14], [-csBound + 12, 14]], spawnB = [[csBound - 12, -14], [csBound - 12, 14]];
  world.csSpawns = [spawnA, spawnB];
  const clearPts = [...spawnA, ...spawnB];
  const nearClear = (x, z, r) => clearPts.some(([a, b]) => Math.hypot(a - x, b - z) < r);
  const overlaps = (x0, x1, z0, z1) => taken.some((q) => x0 < q.x1 && x1 > q.x0 && z0 < q.z1 && z1 > q.z0);
  let placed = 0, tries = 0; const target = opts.buildings || 40;
  while (placed < target && tries++ < 6000) {
    const range = placed < 3 ? 80 : HALF - 25, w = 8 + Math.floor(R() * 9), d = 8 + Math.floor(R() * 7);
    const cx = Math.round((R() - 0.5) * 2 * range), cz = Math.round((R() - 0.5) * 2 * range);
    if (roadAt(cx, cz, Math.max(w, d) / 2) || nearClear(cx, cz, 20)) continue;
    if (Math.hypot(cx - lakeRect.x, cz - lakeRect.z) < lakeRect.r + Math.max(w, d)) continue;
    if (cx > HALF - 90 && cz > 120) continue; // sea side
    if (overlaps(cx - w / 2, cx + w / 2, cz - d / 2, cz + d / 2)) continue;
    building(cx, cz, w, d, 0); placed++;
  }

  // ---------- trees & rocks (instanced) ----------
  const free = (x, z, r) => !overlaps(x - r, x + r, z - r, z + r) && !roadAt(x, z, 1.5) && !nearClear(x, z, 9) && Math.hypot(x - lakeRect.x, z - lakeRect.z) > lakeRect.r + 2 && !(x > HALF - 90 && z > 120);
  const trees = [], rocks = [];
  for (let i = 0; i < 2400 && trees.length < 650; i++) { const x = (R() - 0.5) * (MAP - 8), z = (R() - 0.5) * (MAP - 8); if (free(x, z, 1.2)) trees.push({ x, z, s: 0.8 + R() * 0.7 }); }
  for (let i = 0; i < 900 && rocks.length < 220; i++) { const x = (R() - 0.5) * (MAP - 8), z = (R() - 0.5) * (MAP - 8); if (free(x, z, 2)) rocks.push({ x, z, s: 0.9 + R() * 2.2, ry: R() * 6 }); }
  const dummy = new THREE.Object3D();
  const inst = (geo, mat, list, place) => {
    const im = new THREE.InstancedMesh(geo, mat, list.length);
    list.forEach((o, i) => { place(o, dummy); dummy.updateMatrix(); im.setMatrixAt(i, dummy.matrix); });
    im.castShadow = true; im.receiveShadow = true; scene.add(im); return im;
  };
  inst(new THREE.CylinderGeometry(0.22, 0.3, 2.4, 6), M(0x6b4a2b), trees, (o, d) => { d.position.set(o.x, 1.2 * o.s, o.z); d.scale.setScalar(o.s); d.rotation.set(0, 0, 0); });
  inst(new THREE.ConeGeometry(1.7, 3.2, 7), M(0x2f8f4a), trees, (o, d) => { d.position.set(o.x, 3.4 * o.s, o.z); d.scale.setScalar(o.s); d.rotation.set(0, 0, 0); });
  inst(new THREE.ConeGeometry(1.2, 2.6, 7), M(0x3aa65a), trees, (o, d) => { d.position.set(o.x, 5 * o.s, o.z); d.scale.setScalar(o.s); d.rotation.set(0, 0, 0); });
  inst(new THREE.DodecahedronGeometry(1, 0), M(0x8b8f96), rocks, (o, d) => { d.position.set(o.x, 0.55 * o.s, o.z); d.scale.set(o.s, o.s * 0.75, o.s); d.rotation.set(0, o.ry, 0); });
  for (const o of trees) grid.add({ x0: o.x - 0.3, x1: o.x + 0.3, z0: o.z - 0.3, z1: o.z + 0.3, y0: 0, y1: 5, noStand: true });
  for (const o of rocks) { const r = o.s * 0.8; grid.add({ x0: o.x - r, x1: o.x + r, z0: o.z - r, z1: o.z + r, y0: 0, y1: o.s * 0.9 }); }

  for (let i = 0; i < 160; i++) {
    const x = (R() - 0.5) * (MAP - 20), z = (R() - 0.5) * (MAP - 20);
    if (!overlaps(x, x, z, z) && !nearClear(x, z, 0)) lootSpots.push({ x, z, tier: 0 });
  }

  flush();
  world.update = (p) => { for (const r of roofs) r.mesh.visible = !(p.y < 3 && p.x > r.x0 && p.x < r.x1 && p.z > r.z0 && p.z < r.z1); };
  return world;
}
