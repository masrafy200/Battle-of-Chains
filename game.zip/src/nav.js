// Grid navigation for bots: 1m cells, A* with 8 neighbours, path smoothing.
export class Nav {
  constructor(grid, half) {
    this.o = -half - 2;
    this.w = Math.ceil(half * 2) + 4;
    const n = this.w * this.w;
    this.blocked = new Uint8Array(n);
    this.g = new Float32Array(n); this.from = new Int32Array(n);
    this.seen = new Uint32Array(n); this.closed = new Uint32Array(n); this.stamp = 0;
    for (const b of grid.all) if (b.y0 < 1.5 && b.y1 > 0.5) this.mark(b);
  }

  mark(b) {
    const m = 0.45, o = this.o, w = this.w;
    const i0 = Math.max(0, Math.ceil(b.x0 - m - o - 0.5)), i1 = Math.min(w - 1, Math.floor(b.x1 + m - o - 0.5));
    const j0 = Math.max(0, Math.ceil(b.z0 - m - o - 0.5)), j1 = Math.min(w - 1, Math.floor(b.z1 + m - o - 0.5));
    for (let j = j0; j <= j1; j++) for (let i = i0; i <= i1; i++) this.blocked[j * w + i] = 1;
  }

  free(i, j) { return i >= 0 && j >= 0 && i < this.w && j < this.w && !this.blocked[j * this.w + i]; }

  nearestFree(i, j, R = 8) {
    if (this.free(i, j)) return [i, j];
    for (let r = 1; r <= R; r++) {
      let best = null, bd = 1e9;
      for (let dj = -r; dj <= r; dj++) for (let di = -r; di <= r; di++) {
        if (Math.max(Math.abs(di), Math.abs(dj)) !== r || !this.free(i + di, j + dj)) continue;
        const d = di * di + dj * dj; if (d < bd) { bd = d; best = [i + di, j + dj]; }
      }
      if (best) return best;
    }
    return null;
  }

  // returns [{x,z}...] waypoints (world coords), [] if already there, null if no path
  path(sx, sz, gx, gz, maxExp = 90000) {
    const o = this.o, w = this.w;
    const s = this.nearestFree(Math.floor(sx - o), Math.floor(sz - o), 4);
    const g = this.nearestFree(Math.floor(gx - o), Math.floor(gz - o), 10);
    if (!s || !g) return null;
    const S = s[1] * w + s[0], G = g[1] * w + g[0];
    if (S === G) return [];
    const st = ++this.stamp, gi = g[0], gj = g[1];
    const hf = [], hi = [];
    const push = (f, id) => { let k = hf.length; hf.push(f); hi.push(id); while (k > 0) { const p = (k - 1) >> 1; if (hf[p] <= hf[k]) break; [hf[p], hf[k]] = [hf[k], hf[p]]; [hi[p], hi[k]] = [hi[k], hi[p]]; k = p; } };
    const pop = () => {
      const id = hi[0], lf = hf.pop(), li = hi.pop();
      if (hf.length) { hf[0] = lf; hi[0] = li; let k = 0; for (;;) { let l = 2 * k + 1, r = l + 1, m = k; if (l < hf.length && hf[l] < hf[m]) m = l; if (r < hf.length && hf[r] < hf[m]) m = r; if (m === k) break; [hf[m], hf[k]] = [hf[k], hf[m]]; [hi[m], hi[k]] = [hi[k], hi[m]]; k = m; } }
      return id;
    };
    const h = (i, j) => { const dx = Math.abs(i - gi), dz = Math.abs(j - gj); return (dx + dz - 0.586 * Math.min(dx, dz)) * 1.2; };  // slightly greedy = much faster, paths still near-optimal
    this.g[S] = 0; this.seen[S] = st; this.from[S] = -1; push(h(s[0], s[1]), S);
    const DI = [1, -1, 0, 0, 1, 1, -1, -1], DJ = [0, 0, 1, -1, 1, -1, 1, -1];
    let exp = 0, found = false;
    while (hf.length && exp < maxExp) {
      const cur = pop(); if (this.closed[cur] === st) continue; this.closed[cur] = st; exp++;
      if (cur === G) { found = true; break; }
      const ci = cur % w, cj = (cur / w) | 0;
      for (let k = 0; k < 8; k++) {
        const ni = ci + DI[k], nj = cj + DJ[k];
        if (!this.free(ni, nj)) continue;
        if (k >= 4 && (!this.free(ci + DI[k], cj) || !this.free(ci, cj + DJ[k]))) continue;
        const nid = nj * w + ni; if (this.closed[nid] === st) continue;
        const ng = this.g[cur] + (k < 4 ? 1 : 1.414);
        if (this.seen[nid] !== st || ng < this.g[nid]) { this.seen[nid] = st; this.g[nid] = ng; this.from[nid] = cur; push(ng + h(ni, nj), nid); }
      }
    }
    if (!found) return null;
    const pts = [];
    for (let id = G; id !== -1; id = this.from[id]) pts.push({ x: (id % w) + o + 0.5, z: ((id / w) | 0) + o + 0.5 });
    pts.reverse();
    return this.smooth(pts);
  }

  clear(p, q) {
    const d = Math.hypot(q.x - p.x, q.z - p.z), n = Math.ceil(d / 0.4);
    for (let k = 1; k < n; k++) {
      const x = p.x + (q.x - p.x) * k / n, z = p.z + (q.z - p.z) * k / n;
      if (!this.free(Math.floor(x - this.o), Math.floor(z - this.o))) return false;
    }
    return true;
  }

  smooth(pts) {
    if (pts.length < 3) return pts;
    const out = []; let a = 0;
    while (a < pts.length - 1) {
      let b = pts.length - 1;
      while (b > a + 1 && !this.clear(pts[a], pts[b])) b--;
      out.push(pts[b]); a = b;
    }
    return out;
  }
}
