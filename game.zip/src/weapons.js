import * as THREE from 'three';

// price = Clash Squad shop price (in-match cash)
export const WEAPONS = {
  pistol:  { name: 'পিস্তল',            ammo: 'light', dmg: 24, rate: 4.5, mag: 12, reload: 1.4, spread: 0.010, range: 90,  pellets: 1, auto: false, price: 0,    recoil: 0.010, snd: 'pistol', len: 0.28, col: 0x8a8f98 },
  smg:     { name: 'SMG',               ammo: 'light', dmg: 15, rate: 13,  mag: 30, reload: 1.7, spread: 0.030, range: 70,  pellets: 1, auto: true,  price: 900,  recoil: 0.006, snd: 'smg',    len: 0.46, col: 0x3b3f46 },
  ar:      { name: 'অ্যাসল্ট রাইফেল',   ammo: 'rifle', dmg: 21, rate: 9,   mag: 30, reload: 2.1, spread: 0.018, range: 140, pellets: 1, auto: true,  price: 2200, recoil: 0.009, snd: 'ar',     len: 0.78, col: 0x4a5a3a },
  shotgun: { name: 'শটগান',             ammo: 'shell', dmg: 11, rate: 1.2, mag: 6,  reload: 2.6, spread: 0.075, range: 35,  pellets: 8, auto: false, price: 1300, recoil: 0.04,  snd: 'sg',     len: 0.7,  col: 0x6b4a2b },
  sniper:  { name: 'স্নাইপার',          ammo: 'rifle', dmg: 88, rate: 0.9, mag: 5,  reload: 2.8, spread: 0.001, range: 300, pellets: 1, auto: false, price: 3000, recoil: 0.05,  snd: 'sn',     len: 1.0,  col: 0x2d3a4a, zoom: 2.6 },
};

export const AMMO = {
  light: { name: 'লাইট অ্যামো',    col: 0xffd34a, pack: 30, max: 180 },
  rifle: { name: 'রাইফেল অ্যামো',  col: 0x6bd66b, pack: 30, max: 150 },
  shell: { name: 'শেল',            col: 0xff6b4a, pack: 8,  max: 40 },
};

export const ITEMS = {
  bandage: { name: 'ব্যান্ডেজ', heal: 15,  time: 1.5, col: 0xffffff, price: 150 },
  medkit:  { name: 'মেডিকিট',   heal: 100, time: 4,   col: 0xff4a4a, price: 500 },
  armor:   { name: 'আর্মার',    amount: 50,            col: 0x4aa3ff, price: 650 },
};

const mat = (c) => new THREE.MeshStandardMaterial({ color: c, roughness: 0.55, metalness: 0.3, flatShading: true });
const box = (w, h, d, m, x = 0, y = 0, z = 0) => {
  const o = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), m); o.position.set(x, y, z); o.castShadow = true; return o;
};

// Gun model, barrel along +Z, origin at the grip.
export function makeGun(id) {
  const d = WEAPONS[id]; const g = new THREE.Group();
  const body = mat(d.col), dark = mat(0x18181b), wood = mat(0x7a5230);
  const L = d.len;
  g.add(box(0.07, 0.09, L, body, 0, 0.04, L / 2 - 0.08));
  const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, L * 0.45, 8), dark);
  barrel.rotation.x = Math.PI / 2; barrel.position.set(0, 0.06, L * 0.9 - 0.05); g.add(barrel);
  g.add(box(0.06, 0.16, 0.07, dark, 0, -0.08, 0));
  if (id !== 'pistol') g.add(box(0.05, 0.2, 0.07, dark, 0, -0.1, L * 0.45));
  if (id === 'ar' || id === 'sniper' || id === 'shotgun') g.add(box(0.06, 0.1, 0.22, wood, 0, 0.0, -0.18));
  if (id === 'sniper') {
    const s = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.3, 10), dark);
    s.rotation.x = Math.PI / 2; s.position.set(0, 0.13, L * 0.4); g.add(s);
  }
  if (id === 'shotgun') g.add(box(0.08, 0.07, 0.2, wood, 0, 0.0, L * 0.6));
  g.userData.muzzle = L + 0.1;
  return g;
}
