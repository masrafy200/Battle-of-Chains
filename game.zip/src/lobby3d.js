import * as THREE from 'three';
import { buildCharacter, setGun, animateCharacter } from './character.js';

// 3D lobby: your character stands in the middle; party members stand beside you. Drag to spin yours.
export class Lobby3D {
  constructor(renderer, canvas) {
    this.r = renderer; this.t = 0;
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x0e1530);
    this.scene.fog = new THREE.Fog(0x0e1530, 9, 26);
    this.camera = new THREE.PerspectiveCamera(38, innerWidth / innerHeight, 0.1, 60);
    addEventListener('resize', () => { this.camera.aspect = innerWidth / innerHeight; this.camera.updateProjectionMatrix(); });

    this.scene.add(new THREE.HemisphereLight(0x9fb8ff, 0x20243a, 0.9));
    const key = new THREE.SpotLight(0xfff0d0, 110, 26, 0.7, 0.5); key.position.set(3, 7, 5); key.target.position.set(0, 1, 0); key.castShadow = true; this.scene.add(key, key.target);
    const rim = new THREE.PointLight(0x35d0ff, 40, 16); rim.position.set(-4, 2.5, -3); this.scene.add(rim);
    const floor = new THREE.Mesh(new THREE.CircleGeometry(30, 40), new THREE.MeshStandardMaterial({ color: 0x0a0f24 })); floor.rotation.x = -Math.PI / 2; floor.position.y = -0.26; floor.receiveShadow = true; this.scene.add(floor);

    this.deco = [];
    for (let i = 0; i < 26; i++) {
      const m = new THREE.Mesh(new THREE.OctahedronGeometry(0.1 + Math.random() * 0.18), new THREE.MeshBasicMaterial({ color: Math.random() < 0.5 ? 0x35d0ff : 0xffb020 }));
      const a = Math.random() * 6.28, d = 3 + Math.random() * 6; m.position.set(Math.cos(a) * d, Math.random() * 4, Math.sin(a) * d - 3); m.userData.s = Math.random() * 2; this.scene.add(m); this.deco.push(m);
    }

    this.slots = new THREE.Group(); this.scene.add(this.slots);
    this.yaw = 0.5; this.vel = 0; this.drag = false; this.lastX = 0; this.me = null; this.mates = []; this.skin = 0; this.active = true;
    this.setParty([{ name: '', skin: 0, me: true }]);
    canvas.addEventListener('pointerdown', (e) => { if (!this.active) return; this.drag = true; this.lastX = e.clientX; this.vel = 0; });
    addEventListener('pointermove', (e) => { if (!this.drag) return; const dx = e.clientX - this.lastX; this.lastX = e.clientX; this.yaw += dx * 0.012; this.vel = dx * 0.012; });
    addEventListener('pointerup', () => { this.drag = false; });
  }

  tag(text, leader) {
    const c = document.createElement('canvas'); c.width = 256; c.height = 64; const x = c.getContext('2d');
    x.font = 'bold 34px sans-serif'; x.textAlign = 'center'; x.lineWidth = 7; x.strokeStyle = '#000'; x.fillStyle = '#fff';
    const t = (leader ? '👑 ' : '') + text; x.strokeText(t, 128, 44); x.fillText(t, 128, 44);
    const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(c), transparent: true, depthTest: false }));
    s.scale.set(1.6, 0.4, 1); s.position.y = 2.55; s.renderOrder = 5; return s;
  }

  // members: [{name, skin, me, leader}]
  setParty(members) {
    this.slots.clear(); this.mates = []; this.me = null;
    const n = members.length, gap = 1.9, mid = Math.floor((n - 1) / 2);
    // "me" always in the centre-most slot, the others fill the rest in order
    const order = []; let k = 0;
    for (let i = 0; i < n; i++) order[i] = i === mid ? members.findIndex((m) => m.me) : -1;
    const rest = members.map((m, i) => i).filter((i) => !members[i].me); for (let i = 0; i < n; i++) if (order[i] < 0) order[i] = rest[k++];
    order.forEach((mi, slot) => {
      const m = members[mi], x = (slot - (n - 1) / 2) * gap, isMe = !!m.me;
      const plat = new THREE.Mesh(new THREE.CylinderGeometry(isMe ? 1.15 : 0.95, isMe ? 1.3 : 1.1, 0.25, 36), new THREE.MeshStandardMaterial({ color: isMe ? 0x2a3a7a : 0x1d2650, metalness: 0.5, roughness: 0.4 }));
      plat.position.set(x, -0.13, 0); plat.receiveShadow = true;
      const ring = new THREE.Mesh(new THREE.TorusGeometry(isMe ? 1.18 : 0.98, 0.035, 8, 48), new THREE.MeshBasicMaterial({ color: isMe ? 0xffb020 : 0x35d0ff }));
      ring.rotation.x = Math.PI / 2; ring.position.set(x, 0, 0);
      const ch = buildCharacter(m.skin); setGun(ch, isMe ? 'ar' : 'smg'); ch.group.scale.setScalar(isMe ? 1.3 : 1.15);
      ch.group.position.set(x, 0, 0); ch.group.traverse((o) => { if (o.isMesh) o.castShadow = true; });
      if (!isMe || n > 1) { const t = this.tag(m.name || 'Player', m.leader); ch.group.add(t); t.scale.multiplyScalar(1 / ch.group.scale.x); }
      this.slots.add(plat, ring, ch.group);
      if (isMe) this.me = ch; else { ch.sway = Math.random() * 6; this.mates.push(ch); }
    });
    this.camera.position.set(0, 1.5 + n * 0.05, 5.4 + (n - 1) * 1.2); this.camera.lookAt(0, 1.0, 0);
  }

  frame(dt) {
    this.t += dt;
    if (!this.drag) { this.yaw += this.vel; this.vel *= 0.94; if (Math.abs(this.vel) < 0.002) this.yaw += dt * 0.25; }
    if (this.me) {
      this.me.group.rotation.y = this.yaw;
      animateCharacter(this.me, { speed: 0, armed: true, aim: false, crouch: false, pitch: 0 }, dt);
      this.me.body.position.y += Math.sin(this.t * 2) * 0.012;
    }
    for (const m of this.mates) { m.group.rotation.y = Math.sin(this.t * 0.6 + m.sway) * 0.4; animateCharacter(m, { speed: 0, armed: true, aim: false, crouch: false, pitch: 0 }, dt); m.body.position.y += Math.sin(this.t * 2 + m.sway) * 0.012; }
    for (const m of this.deco) { m.rotation.y += dt * (0.5 + m.userData.s); m.position.y += Math.sin(this.t + m.userData.s * 5) * 0.003; }
    this.r.render(this.scene, this.camera);
  }
}
