import * as THREE from 'three';
import { buildCharacter, setGun, animateCharacter } from './character.js';

// 3D lobby: your character stands on a platform in the centre. Drag left/right to spin it.
export class Lobby3D {
  constructor(renderer, canvas) {
    this.r = renderer; this.t = 0;
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x0e1530);
    this.scene.fog = new THREE.Fog(0x0e1530, 8, 22);
    this.camera = new THREE.PerspectiveCamera(38, innerWidth / innerHeight, 0.1, 60);
    this.camera.position.set(0, 1.5, 5.4); this.camera.lookAt(0, 1.0, 0);
    addEventListener('resize', () => { this.camera.aspect = innerWidth / innerHeight; this.camera.updateProjectionMatrix(); });

    this.scene.add(new THREE.HemisphereLight(0x9fb8ff, 0x20243a, 0.9));
    const key = new THREE.SpotLight(0xfff0d0, 90, 20, 0.5, 0.5); key.position.set(3, 6, 4); key.target.position.set(0, 1, 0); key.castShadow = true; this.scene.add(key, key.target);
    const rim = new THREE.PointLight(0x35d0ff, 40, 14); rim.position.set(-4, 2.5, -3); this.scene.add(rim);

    const plat = new THREE.Mesh(new THREE.CylinderGeometry(1.5, 1.7, 0.25, 40), new THREE.MeshStandardMaterial({ color: 0x1d2650, metalness: 0.5, roughness: 0.4 }));
    plat.position.y = -0.13; plat.receiveShadow = true; this.scene.add(plat);
    const ring = new THREE.Mesh(new THREE.TorusGeometry(1.55, 0.04, 8, 64), new THREE.MeshBasicMaterial({ color: 0xffb020 }));
    ring.rotation.x = Math.PI / 2; ring.position.y = 0.0; this.scene.add(ring); this.ring = ring;
    const floor = new THREE.Mesh(new THREE.CircleGeometry(30, 40), new THREE.MeshStandardMaterial({ color: 0x0a0f24 })); floor.rotation.x = -Math.PI / 2; floor.position.y = -0.26; floor.receiveShadow = true; this.scene.add(floor);

    this.deco = [];
    for (let i = 0; i < 26; i++) {
      const m = new THREE.Mesh(new THREE.OctahedronGeometry(0.1 + Math.random() * 0.18), new THREE.MeshBasicMaterial({ color: Math.random() < 0.5 ? 0x35d0ff : 0xffb020 }));
      const a = Math.random() * 6.28, d = 3 + Math.random() * 6; m.position.set(Math.cos(a) * d, Math.random() * 4, Math.sin(a) * d - 3); m.userData.s = Math.random() * 2; this.scene.add(m); this.deco.push(m);
    }

    this.yaw = 0.5; this.vel = 0; this.drag = false; this.lastX = 0; this.char = null; this.gun = 'ar';
    canvas.addEventListener('pointerdown', (e) => { if (!this.active) return; this.drag = true; this.lastX = e.clientX; this.vel = 0; });
    addEventListener('pointermove', (e) => { if (!this.drag) return; const dx = e.clientX - this.lastX; this.lastX = e.clientX; this.yaw += dx * 0.012; this.vel = dx * 0.012; });
    addEventListener('pointerup', () => { this.drag = false; });
    this.active = true;
  }

  setSkin(i) {
    if (this.char) this.scene.remove(this.char.group);
    this.char = buildCharacter(i); setGun(this.char, this.gun);
    this.char.group.scale.setScalar(1.35);
    this.char.group.traverse((o) => { if (o.isMesh) o.castShadow = true; });
    this.scene.add(this.char.group);
  }

  frame(dt) {
    this.t += dt;
    if (!this.drag) { this.yaw += this.vel; this.vel *= 0.94; if (Math.abs(this.vel) < 0.002) this.yaw += dt * 0.25; }
    if (this.char) {
      this.char.group.rotation.y = this.yaw;
      animateCharacter(this.char, { speed: 0, armed: true, aim: false, crouch: false, pitch: 0 }, dt);
      this.char.body.position.y += Math.sin(this.t * 2) * 0.012;
    }
    this.ring.rotation.z += dt * 0.4;
    for (const m of this.deco) { m.rotation.y += dt * (0.5 + m.userData.s); m.position.y += Math.sin(this.t + m.userData.s * 5) * 0.003; }
    this.r.render(this.scene, this.camera);
  }
}
