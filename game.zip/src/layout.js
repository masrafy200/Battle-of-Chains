// Touch button layout: default positions + drag-to-move "adjust" mode (saved).
import { Save } from './save.js';
const $ = (id) => document.getElementById(id);
const DEF = {
  stick: [0.14, 0.74], fire: [0.9, 0.72], aim: [0.79, 0.84], jump: [0.91, 0.47], rel: [0.79, 0.64], pick: [0.69, 0.76],
  sw: [0.68, 0.55], crouch: [0.8, 0.46], med: [0.3, 0.6], band: [0.3, 0.76], plane: [0.14, 0.45], chute: [0.14, 0.45], shopb: [0.22, 0.45],
};
const cfg = () => Save.data.ui || { scale: 1, pos: {} };
let adj = null, drag = null;

export function applyLayout(ui = cfg()) {
  document.querySelectorAll('#touch [data-id]').forEach((el) => {
    const p = (ui.pos && ui.pos[el.dataset.id]) || DEF[el.dataset.id]; if (!p) return;
    el.style.left = p[0] * 100 + '%'; el.style.top = p[1] * 100 + '%';
    el.style.transform = `translate(-50%,-50%) scale(${ui.scale || 1})`;
  });
}

export function startAdjust() {
  adj = { scale: cfg().scale || 1, pos: { ...(cfg().pos || {}) } };
  document.body.classList.add('adjusting');
  $('adjbar').classList.remove('hidden'); $('adjScale').value = adj.scale;
  applyLayout(adj);
}
export function endAdjust(save) {
  if (save && adj) Save.set('ui', { scale: adj.scale, pos: adj.pos });
  adj = null; drag = null;
  document.body.classList.remove('adjusting'); $('adjbar').classList.add('hidden'); applyLayout();
}
export function resetAdjust() { if (!adj) return; adj.pos = {}; adj.scale = 1; $('adjScale').value = 1; applyLayout(adj); }
export const adjusting = () => !!adj;

export function initLayout() {
  applyLayout();
  $('adjScale').addEventListener('input', (e) => { if (adj) { adj.scale = +e.target.value; applyLayout(adj); } });
  document.addEventListener('pointerdown', (e) => {
    if (!adj) return;
    const el = e.target.closest('#touch [data-id]'); if (!el) return;
    e.stopPropagation(); e.preventDefault(); drag = el; el.setPointerCapture?.(e.pointerId);
  }, true);
  document.addEventListener('pointermove', (e) => {
    if (!adj || !drag) return;
    const x = Math.min(0.96, Math.max(0.04, e.clientX / innerWidth)), y = Math.min(0.96, Math.max(0.06, e.clientY / innerHeight));
    adj.pos[drag.dataset.id] = [x, y]; applyLayout(adj);
  }, true);
  document.addEventListener('pointerup', () => { drag = null; }, true);
}
