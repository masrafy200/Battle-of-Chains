// Voice chat between everybody in the room (WebRTC mesh). Signalling goes through Net.
// NOTE: browsers only allow the microphone on https:// pages or localhost
// (GitHub Pages is https, so use it with Photon; a plain http://192.168.x.x LAN page cannot use the mic).
const ICE = { iceServers: [{ urls: 'stun:stun.l.google.com:19302' }] };

export const Voice = {
  net: null, on: false, muted: false, stream: null, peers: new Map(), onChange: null, hasMic: false,

  init(net) { this.net = net; },
  get myId() { return this.net?.myId; },
  emit() { this.onChange?.(); },

  async join() {
    if (this.on) return;
    try { this.stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true } }); this.hasMic = true; }
    catch { this.stream = null; this.hasMic = false; }   // can still listen without a mic
    this.on = true; this.muted = false;
    this.net.send({ t: 'vjoin' });
    this.emit();
    return this.hasMic;
  },

  leave() {
    if (!this.on) return;
    this.net?.send({ t: 'vleave' });
    for (const id of [...this.peers.keys()]) this.drop(id);
    this.stream?.getTracks().forEach((t) => t.stop()); this.stream = null;
    this.on = false; this.hasMic = false; this.emit();
  },

  toggleMute() {
    this.muted = !this.muted;
    this.stream?.getAudioTracks().forEach((t) => { t.enabled = !this.muted; });
    this.emit();
  },

  drop(id) {
    const p = this.peers.get(id); if (!p) return;
    try { p.pc.close(); } catch { /* */ }
    p.audio?.remove(); this.peers.delete(id);
  },

  peer(id) {
    let p = this.peers.get(id); if (p) return p;
    const pc = new RTCPeerConnection(ICE);
    p = { pc, audio: null, queue: [], remote: false };
    this.peers.set(id, p);
    if (this.stream) this.stream.getTracks().forEach((t) => pc.addTrack(t, this.stream));
    else pc.addTransceiver('audio', { direction: 'recvonly' });
    pc.onicecandidate = (e) => { if (e.candidate) this.net.send({ t: 'vice', c: e.candidate }, id); };
    pc.ontrack = (e) => {
      if (!p.audio) { p.audio = document.createElement('audio'); p.audio.autoplay = true; p.audio.playsInline = true; document.body.appendChild(p.audio); }
      p.audio.srcObject = e.streams[0]; p.audio.play?.().catch(() => {});
    };
    pc.onconnectionstatechange = () => { if (['failed', 'closed'].includes(pc.connectionState)) this.drop(id); };
    return p;
  },

  async handle(from, m) {
    if (!this.net) return;
    try {
      if (m.t === 'vjoin') {
        if (!this.on || this.peers.has(from)) return;
        if (this.myId < from) { // I start the call
          const p = this.peer(from), offer = await p.pc.createOffer();
          await p.pc.setLocalDescription(offer); this.net.send({ t: 'voffer', d: offer }, from);
        } else this.net.send({ t: 'vjoin' }, from); // ask the other side to start (it has the smaller id)
      } else if (m.t === 'voffer') {
        if (!this.on) return;
        const p = this.peer(from); await p.pc.setRemoteDescription(m.d); p.remote = true;
        for (const c of p.queue) await p.pc.addIceCandidate(c).catch(() => {}); p.queue = [];
        const ans = await p.pc.createAnswer(); await p.pc.setLocalDescription(ans); this.net.send({ t: 'vans', d: ans }, from);
      } else if (m.t === 'vans') {
        const p = this.peers.get(from); if (!p) return;
        await p.pc.setRemoteDescription(m.d); p.remote = true;
        for (const c of p.queue) await p.pc.addIceCandidate(c).catch(() => {}); p.queue = [];
      } else if (m.t === 'vice') {
        const p = this.peers.get(from); if (!p) return;
        if (p.remote) await p.pc.addIceCandidate(m.c).catch(() => {}); else p.queue.push(m.c);
      } else if (m.t === 'vleave') this.drop(from);
    } catch (e) { console.warn('voice', e); }
  },
};
