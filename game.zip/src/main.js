import './style.css';
import * as THREE from 'three';
import { Save } from './save.js';
import { Sfx } from './audio.js';
import { Input } from './input.js';
import { Net } from './net.js';
import { Lobby3D } from './lobby3d.js';
import { Game } from './game.js';
import { Voice } from './voice.js';
import { SKINS, SKIN_PRICE } from './character.js';
import { initLayout, startAdjust, endAdjust, resetAdjust } from './layout.js';

const $ = (id) => document.getElementById(id);
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ---- fixed match rules
const BR_TOTAL = 60;                        // Battle Royale: always 60 players (humans + bots)
const CS_TEAM = 4;                          // Clash Squad: always 4 v 4
const layoutFor = (type) => (type === 'coop' ? [4, 0] : [4, 4]); // human slots: coop = only your side, multiplayer = both sides
const VOICE_MSG = new Set(['vjoin', 'voffer', 'vans', 'vice', 'vleave']);

// ---------------------------------------------------------------- boot
const canvas = $('c');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
function applyQuality() {
  const q = Save.data.quality ?? 1;
  renderer.setPixelRatio(Math.min(devicePixelRatio, [1, 1.4, 2][q]));
  renderer.setSize(innerWidth, innerHeight);
}
applyQuality();
addEventListener('resize', () => renderer.setSize(innerWidth, innerHeight));
Input.init(canvas);
Input.sens = Save.data.sens; Input.adsMul = Save.data.ads; Sfx.setMuted(!!Save.data.muted);
initLayout();
Voice.init(Net);

let lobby, game, state = 'loading';
const sel = { mode: 'br', type: 'multi', transport: Net.photonConfigured ? 'photon' : 'lan' };
let room = null;       // current room / party (the host's copy is the master copy)
let inRoom = false;

function toast(t, ms = 2800) { const e = $('toast'); e.textContent = t; e.classList.add('on'); clearTimeout(toast._t); toast._t = setTimeout(() => e.classList.remove('on'), ms); }
function ui(html) { const u = $('ui'); u.innerHTML = html; u.classList.remove('hidden'); }
function uiClose() { $('ui').classList.add('hidden'); $('ui').innerHTML = ''; }

async function boot() {
  const bar = $('loadbar'), txt = $('loadtxt');
  const step = async (p, t) => { bar.style.width = p + '%'; txt.textContent = t; await sleep(160); };
  await step(15, 'গ্রাফিক্স তৈরি হচ্ছে…');
  lobby = new Lobby3D(renderer, canvas);
  await step(45, 'চরিত্র লোড হচ্ছে…');
  game = new Game(renderer, Net, { onDeath: (r) => deathPanel(r), onEnd: (r) => endPanel(r) });
  await step(75, 'সেভ ডাটা পড়া হচ্ছে…');
  Save.onChange((d) => { $('coins').textContent = d.coins; $('pname').textContent = d.name; $('pid').textContent = 'ID: ' + d.uid; });
  Voice.onChange = () => { renderPartyBar(); updateMic(); };
  await step(100, 'প্রস্তুত!');
  $('loading').classList.add('hidden');
  toLobby();
  let last = performance.now();
  const loop = (now) => {
    const dt = Math.min(0.1, (now - last) / 1000); last = now;
    if (state === 'game') game.frame(dt); else if (state === 'lobby') lobby.frame(dt);
    requestAnimationFrame(loop);
  };
  requestAnimationFrame(loop);
  // invite link:  ...?join=FRIENDID
  const j = new URLSearchParams(location.search).get('join');
  if (j) { history.replaceState(null, '', location.pathname); Save.addFriend(j.toUpperCase(), j.toUpperCase()); joinParty(j); }
}

function toLobby() {
  state = 'lobby'; Input.enabled = false; Input.unlock(); game?.stop();
  document.body.classList.remove('unlocked');
  $('lobby').classList.remove('hidden'); uiClose();
  refreshParty();
  if (inRoom && room?.mode) renderRoom();
}

// ---------------------------------------------------------------- click delegation
const acts = {
  start: () => { if (inRoom && !Net.isHost) { toast('শুধু পার্টি লিডার ম্যাচ শুরু করতে পারে'); return; } modePanel(); },
  close: () => uiClose(),
  coinplus: () => coinPanel(),
  daily: () => { Save.claimDaily() ? (Sfx.pickup(), toast('🎁 ডেইলি রিওয়ার্ড: +১০০ কয়েন')) : toast('আজকের রিওয়ার্ড নেওয়া হয়ে গেছে'); },
  skins: () => skinPanel(),
  stats: () => statsPanel(),
  settings: () => settingsPanel('lobby'),
  gsettings: () => settingsPanel('game'),
  diff: (d) => { Save.set('diff', +d.v); settingsPanel(settingsCtx); },
  quality: (d) => { Save.set('quality', +d.v); applyQuality(); settingsPanel(settingsCtx); },
  adjust: () => { uiClose(); if (state === 'lobby') $('hud').classList.remove('hidden'); $('touch').classList.remove('hidden'); startAdjust(); },
  adjReset: () => resetAdjust(),
  adjDone: () => {
    endAdjust(true);
    if (state === 'lobby') { $('hud').classList.add('hidden'); $('touch').classList.add('hidden'); settingsPanel('lobby'); }
    else { $('touch').classList.toggle('hidden', !Input.touch); pausePanel(); }
  },
  pickMode: (d) => { sel.mode = d.v; modePanel(); },
  modeOk: () => typePanel(),
  pickType: (d) => { sel.type = d.v; typePanel(); },
  typeOk: () => typeOk(),
  backMode: () => modePanel(),
  transport: (d) => { sel.transport = d.v; (settingsCtx === 'friends' ? friendsPanel : roomsPanel)(); },
  refresh: () => roomsPanel(),
  createPanel: () => createPanel(),
  createGo: () => createRoom(),
  join: (d) => joinRoom(d.id),
  moveSlot: (d) => moveSlot(+d.i),
  roomStart: () => roomStart(),
  roomLeave: () => { leaveRoom(); toLobby(); roomsPanel(); },
  roomBack: () => { if (Net.isHost && room) { room.mode = null; room.type = null; room.slots = []; broadcastRoom(); } },
  backType: () => typePanel(),
  buySkin: (d) => { const i = +d.i; if (Save.buySkin(i, SKIN_PRICE[i])) { Sfx.buy(); refreshParty(); skinPanel(); if (inRoom) syncMe(); } else toast('কয়েন কম!'); },
  pause: () => pausePanel(),
  resume: () => { uiClose(); Input.lock(); },
  quit: () => { uiClose(); game.leave(); },
  lobbyBack: () => { backFromMatch(); },
  spectate: () => { uiClose(); Input.lock(); },
  devCoins: () => { Save.addCoins(1000); coinPanel(); },
  sound: () => { Sfx.setMuted(!Sfx.muted); Save.set('muted', Sfx.muted); settingsPanel(settingsCtx); },
  rename: () => { const v = $('nameIn').value.trim().slice(0, 14); if (v) { Save.set('name', v); toast('নাম পরিবর্তন হয়েছে'); if (inRoom) syncMe(); refreshParty(); } },
  // friends / party / voice
  friends: () => friendsPanel(),
  partyOpen: () => openParty(),
  partyLeave: () => { leaveRoom(); toLobby(); toast('পার্টি ছেড়েছ'); },
  friendAdd: () => { const v = ($('fid').value || '').trim().toUpperCase(); if (v) { Save.addFriend(v, v); joinParty(v); } },
  friendJoin: (d) => joinParty(d.uid),
  friendDel: (d) => { Save.removeFriend(d.uid); friendsPanel(); },
  copyLink: () => copyText(location.origin + location.pathname + '?join=' + Save.data.uid, 'ইনভাইট লিংক কপি হয়েছে'),
  copyId: () => copyText(Save.data.uid, 'ID কপি হয়েছে'),
  mic: () => micClick(),
};
document.addEventListener('click', (e) => {
  const el = e.target.closest('[data-act]'); if (!el) return;
  Sfx.unlock(); Sfx.click();
  acts[el.dataset.act]?.({ ...el.dataset });
});
document.addEventListener('input', (e) => {
  if (e.target.id === 'sens') { Input.sens = +e.target.value; Save.set('sens', Input.sens); $('sensV').textContent = (Input.sens * 1000).toFixed(1); }
  if (e.target.id === 'adsm') { Input.adsMul = +e.target.value; Save.set('ads', Input.adsMul); $('adsV').textContent = Math.round(Input.adsMul * 100) + '%'; }
});

async function copyText(t, msg) {
  try { await navigator.clipboard.writeText(t); toast(msg); } catch { prompt('কপি করো:', t); }
}

// ---------------------------------------------------------------- simple panels
function coinPanel() {
  ui(`<div class="panel"><h2>🪙 কয়েন</h2><p class="muted">কয়েন ম্যাচ জিতলে ও কিল করলে পাওয়া যায়, এবং সেভ থাকে (ব্রাউজারে)।</p>
  <div class="row l"><button class="ok" data-act="daily">🎁 ডেইলি রিওয়ার্ড নাও</button>
  ${location.search.includes('dev') || import.meta.env.DEV ? '<button data-act="devCoins">🧪 টেস্ট +১০০০</button>' : ''}</div>
  <div class="row"><button data-act="close">বন্ধ</button></div></div>`);
}
function skinPanel() {
  const d = Save.data;
  ui(`<div class="panel"><h2>🎽 স্কিন শপ <span class="muted">🪙 ${d.coins}</span></h2><div class="skins">${SKINS.map((c, i) => {
    const own = d.skins.includes(i);
    return `<button class="skin ${d.skin === i ? 'on' : ''}" data-act="buySkin" data-i="${i}"><i style="background:#${c.toString(16).padStart(6, '0')}"></i>${d.skin === i ? '✔ পরা আছে' : own ? 'পরো' : '🪙 ' + SKIN_PRICE[i]}</button>`;
  }).join('')}</div><div class="row"><button data-act="close">বন্ধ</button></div></div>`);
}
function statsPanel() {
  const d = Save.data;
  ui(`<div class="panel"><h2>🏆 স্ট্যাটস</h2><div class="stat"><span>ম্যাচ</span><b>${d.matches}</b></div><div class="stat"><span>জয়</span><b>${d.wins}</b></div><div class="stat"><span>মোট কিল</span><b>${d.kills}</b></div><div class="stat"><span>কয়েন</span><b>${d.coins}</b></div><div class="row"><button data-act="close">বন্ধ</button></div></div>`);
}

let settingsCtx = 'lobby';   // 'lobby' or 'game' (opened from the pause menu)
function settingsPanel(ctx = 'lobby') {
  settingsCtx = ctx; const d = Save.data, back = ctx === 'game' ? 'pause' : 'close';
  const seg = (act, labels, cur) => `<div class="seg">${labels.map((t, i) => `<button class="${cur === i ? 'on' : ''}" data-act="${act}" data-v="${i}">${t}</button>`).join('')}</div>`;
  ui(`<div class="panel"><h2>⚙️ সেটিংস</h2>
  ${ctx === 'lobby' ? `<h3>প্লেয়ারের নাম</h3><div class="row l"><input id="nameIn" type="text" maxlength="14" value="${esc(d.name)}" style="flex:1"><button class="ok" data-act="rename">সেভ</button></div>` : ''}
  <h3>সেন্সিটিভিটি (ঘোরানোর গতি): <b id="sensV">${(d.sens * 1000).toFixed(1)}</b></h3><input id="sens" type="range" min="0.0015" max="0.015" step="0.0001" value="${d.sens}">
  <h3>এইম/জুম করার সময় সেন্সিটিভিটি: <b id="adsV">${Math.round(d.ads * 100)}%</b></h3><input id="adsm" type="range" min="0.2" max="1.5" step="0.05" value="${d.ads}">
  <h3>বটের কঠিনতা</h3>${seg('diff', ['সহজ', 'মাঝারি', 'কঠিন'], d.diff | 0)}
  <h3>গ্রাফিক্স কোয়ালিটি (ফোন ল্যাগ করলে "কম" দাও)</h3>${seg('quality', ['কম', 'মাঝারি', 'বেশি'], d.quality ?? 1)}
  <h3>সাউন্ড</h3><div class="row l"><button data-act="sound">${Sfx.muted ? '🔇 বন্ধ (চালু করো)' : '🔊 চালু (বন্ধ করো)'}</button></div>
  <h3>অ্যাডজাস্ট (বাটনের জায়গা)</h3><div class="row l"><button class="ok" data-act="adjust">🕹 বাটন সরাও / সাইজ ঠিক করো</button></div>
  <h3>কন্ট্রোল (পিসি)</h3><p class="muted">WASD চলা • Shift দৌড় • C বসা • Space লাফ • মাউস লক্ষ্য • বাম ক্লিক গুলি/ঘুষি • ডান ক্লিক জুম • R রিলোড • 1/2 অস্ত্র (একই নম্বরে আবার চাপলে খালি হাত) • E তোলা • 3 ব্যান্ডেজ • 4 মেডিকিট • B শপ (Clash Squad) • F প্লেন থেকে লাফ<br>ফোনে নিচের অস্ত্র-বক্স (১/২) ট্যাপ করো; একই বক্সে আবার ট্যাপ = খালি হাত।</p>
  <div class="row"><button data-act="${back}">${ctx === 'game' ? 'পিছনে' : 'বন্ধ'}</button></div></div>`);
}
function pausePanel() {
  Input.unlock();
  ui(`<div class="panel"><h2>⏸ বিরতি</h2><p class="muted">ম্যাচ চলতেই থাকবে (মাল্টিপ্লেয়ারে পজ হয় না)।</p><div class="row"><button data-act="gsettings">⚙️ সেটিংস</button><button class="ok" data-act="resume">চালিয়ে যাও</button><button class="bad" data-act="quit">ম্যাচ ছাড়ো</button></div></div>`);
}

// ---------------------------------------------------------------- mode selection
function modePanel() {
  ui(`<div class="panel"><h2>কোন মোড খেলতে চাও?</h2><div class="cards">
    <button class="card ${sel.mode === 'br' ? 'on' : ''}" data-act="pickMode" data-v="br"><b>🪂 ব্যাটল রয়্যাল</b><small>৮০০×৮০০ ম্যাপ • ৬০ জন • প্লেন থেকে ড্রপ • ছোট হওয়া জোন • শেষ দল জেতে</small></button>
    <button class="card ${sel.mode === 'cs' ? 'on' : ''}" data-act="pickMode" data-v="cs"><b>⚔️ ক্লাশ স্কোয়াড</b><small>৪ বনাম ৪ • প্রতি পক্ষের ২ জায়গায় স্পন • রাউন্ডে অস্ত্র কেনা • ৪ রাউন্ড জিতলে জয়</small></button>
  </div><div class="row"><button data-act="close">ফিরে যাও</button><button class="ok" data-act="modeOk">OK</button></div></div>`);
}
function typePanel() {
  const C = (v, t, s) => `<button class="card ${sel.type === v ? 'on' : ''}" data-act="pickType" data-v="${v}"><b>${t}</b><small>${s}</small></button>`;
  const br = sel.mode === 'br';
  ui(`<div class="panel"><h2>কীভাবে খেলবে? <span class="muted">(${br ? 'ব্যাটল রয়্যাল' : 'ক্লাশ স্কোয়াড'})</span></h2><div class="cards">
    ${C('multi', '🌐 মাল্টিপ্লেয়ার', br ? 'বন্ধুরা দুই স্কোয়াডে (A বনাম B, ৪+৪) ভাগ হয়ে ৬০ জনের ম্যাচে। বাকি জায়গা বট।' : 'বন্ধুরা A বনাম B দলে (৪ বনাম ৪)। খালি জায়গা বট।')}
    ${C('coop', '🤝 কো-অপ (টিমওয়ার্ক)', br ? 'বন্ধুরা এক স্কোয়াডে (সর্বোচ্চ ৪) — বাকি সবাই বট।' : 'বন্ধুরা এক দলে (সর্বোচ্চ ৪) বনাম বট।')}
    ${C('offline', '👤 অফলাইন', 'ইন্টারনেট ছাড়া একা বটদের সাথে।')}
  </div><p class="muted">${inRoom ? 'তুমি পার্টিতে আছো — পার্টির সবাই একসাথে ম্যাচে ঢুকবে।' : 'বন্ধুদের সাথে খেলতে আগে লবিতে 👥 বাটন থেকে পার্টি খোলো, বা পাবলিক রুমে ঢোকো।'}</p>
  <div class="row"><button data-act="backMode">পিছনে</button><button class="ok" data-act="typeOk">OK</button></div></div>`);
}
function typeOk() {
  if (sel.type === 'offline') {
    if (inRoom) { toast('অফলাইন খেলতে আগে পার্টি ছাড়ো'); return; }
    offlineStart(); return;
  }
  if (inRoom && room?.party) {
    if (sel.type === 'coop' && room.order.length > 4) { toast('কো-অপে সর্বোচ্চ ৪ জন'); return; }
    room.mode = sel.mode; room.type = sel.type; layoutRoom(); broadcastRoom(); return;
  }
  roomsPanel();
}

// ---------------------------------------------------------------- offline (always the real match rules)
function offlineStart() {
  const seed = (Math.random() * 1e9) | 0, d = Save.data, roster = [];
  if (sel.mode === 'br') {
    roster.push({ id: 'p0', name: d.name, team: 'p0', skin: d.skin, slot: 0 });
    for (let i = 0; i < BR_TOTAL - 1; i++) roster.push({ id: 'b' + i, name: 'Bot-' + (i + 1), team: 'b' + i, bot: true, skin: (i + 1) % SKINS.length, slot: 0 });
  } else {
    roster.push({ id: 'p0', name: d.name, team: 0, skin: d.skin, slot: 0 });
    for (let i = 1; i < CS_TEAM; i++) roster.push({ id: 'm' + i, name: 'Mate-' + i, team: 0, bot: true, skin: 0, slot: i });
    for (let i = 0; i < CS_TEAM; i++) roster.push({ id: 'e' + i, name: 'Enemy-' + (i + 1), team: 1, bot: true, skin: 1, slot: i });
  }
  launch({ seed, mode: sel.mode, type: 'offline', roster, myId: 'p0', isHost: true, offline: true }, true);
}

function launch(cfg, offline) {
  uiClose(); $('lobby').classList.add('hidden'); state = 'game';
  Sfx.unlock(); game.net = offline ? null : Net;
  game.start({ ...cfg, offline: !!offline });
  updateMic();
}

// ---------------------------------------------------------------- connection
async function connect() {
  if (Net.t && Net.kind === sel.transport) return;
  await Net.use(sel.transport);
  Net.on.message = onNetMessage; Net.on.join = onNetJoin; Net.on.leave = onNetLeave; Net.on.closed = onNetClosed;
}
const transportSeg = () => `<div class="seg">${[['lan', '📶 LAN / হটস্পট'], ['photon', '☁ অনলাইন (Photon)']].map(([v, t]) => `<button class="${sel.transport === v ? 'on' : ''}" data-act="transport" data-v="${v}">${t}</button>`).join('')}</div>`;

// ---------------------------------------------------------------- friends & party
function friendsPanel() {
  settingsCtx = 'friends';
  const d = Save.data;
  ui(`<div class="panel"><h2>👥 বন্ধু ও পার্টি</h2>
  <div class="idbox"><span>তোমার ID</span><b>${esc(d.uid)}</b><button data-act="copyId">কপি</button><button data-act="copyLink">🔗 ইনভাইট লিংক</button></div>
  <p class="muted">বন্ধুকে তোমার ID বা লিংক দাও। সে ID দিয়ে তোমার পার্টিতে ঢুকবে, তারপর লবিতে একসাথে কথা বলা ও ম্যাচ শুরু করা যাবে।</p>
  ${transportSeg()}
  <div class="row l">${inRoom ? '<span class="muted">✅ তুমি এখন পার্টিতে আছো</span><button class="bad" data-act="partyLeave">পার্টি ছাড়ো</button>' : '<button class="ok" data-act="partyOpen">🎉 আমার পার্টি খোলো</button>'}</div>
  <h3>বন্ধুর ID দিয়ে পার্টিতে ঢোকো</h3><div class="row l"><input id="fid" type="text" maxlength="10" placeholder="যেমন: K7M2QX" style="flex:1;text-transform:uppercase"><button class="ok" data-act="friendAdd">যোগ করো ও জয়েন</button></div>
  <div class="err" id="err"></div>
  <h3>বন্ধুদের তালিকা</h3><div class="rooms">${d.friends.length ? d.friends.map((f) => `<div class="rm"><div><b>${esc(f.name)}</b><small>ID: ${esc(f.uid)}</small></div><div class="row"><button class="ok" data-act="friendJoin" data-uid="${esc(f.uid)}">জয়েন</button><button class="bad" data-act="friendDel" data-uid="${esc(f.uid)}">✕</button></div></div>`).join('') : '<p class="muted">এখনো কেউ নেই।</p>'}</div>
  <div class="row"><button data-act="close">বন্ধ</button></div></div>`);
}

async function openParty() {
  try {
    await connect();
    const d = Save.data;
    await Net.createRoom({ id: 'P' + d.uid, name: d.name + ' এর পার্টি', mode: 'party', type: 'party', max: 8, private: true });
    room = { name: d.name + ' এর পার্টি', mode: null, type: null, party: true, hostId: Net.myId, sizes: [4, 4], slots: [], players: { [Net.myId]: { name: d.name, skin: d.skin, uid: d.uid } }, order: [Net.myId] };
    inRoom = true; uiClose(); refreshParty(); toast('🎉 পার্টি খোলা হয়েছে — বন্ধুকে তোমার ID দাও');
  } catch (e) { const el = $('err'); if (el) el.textContent = '⚠ ' + e.message; else toast('⚠ ' + e.message); }
}

async function joinParty(uid) {
  uid = String(uid || '').trim().toUpperCase();
  if (!/^[A-Z0-9]{4,10}$/.test(uid)) { toast('ID ঠিক নয়'); return; }
  if (uid === Save.data.uid) { toast('এটা তোমার নিজের ID'); return; }
  if (inRoom) { toast('আগে বর্তমান পার্টি/রুম ছাড়ো'); return; }
  try {
    await connect(); await Net.joinRoom('P' + uid); inRoom = true; room = null;
    Net.send({ t: 'hello', name: Save.data.name, skin: Save.data.skin, uid: Save.data.uid });
    uiClose(); toast('পার্টিতে ঢুকছে…');
  } catch (e) { const el = $('err'); const msg = '⚠ পার্টি পাওয়া যায়নি — বন্ধু কি পার্টি খুলেছে? (' + e.message + ')'; if (el) el.textContent = msg; else toast(msg, 4500); }
}

function syncMe() { if (!inRoom || !room) return; const d = Save.data; if (Net.isHost) { room.players[Net.myId] = { name: d.name, skin: d.skin, uid: d.uid }; broadcastRoom(); } else Net.send({ t: 'hello', name: d.name, skin: d.skin, uid: d.uid }); }

function members() {
  const d = Save.data;
  if (!inRoom || !room) return [{ name: d.name, skin: d.skin, me: true }];
  return room.order.filter((p) => room.players[p]).map((p) => ({ name: room.players[p].name, skin: room.players[p].skin, me: p === Net.myId, leader: p === room.hostId }));
}
function refreshParty() { if (!lobby) return; lobby.setParty(members().map((m) => (m.me ? { ...m, skin: Save.data.skin, name: inRoom ? m.name : '' } : m))); renderPartyBar(); updateStartBtn(); updateMic(); }
function updateStartBtn() { const b = $('btnStart'); const wait = inRoom && !Net.isHost; b.textContent = wait ? 'লিডারের অপেক্ষা…' : 'START'; b.classList.toggle('wait', wait); }

function renderPartyBar() {
  const el = $('partybar');
  if (!inRoom || !room || state !== 'lobby') { el.classList.add('hidden'); return; }
  const mem = members();
  el.classList.remove('hidden');
  el.innerHTML = `<div class="pt">👥 পার্টি (${mem.length}) ${Net.isHost ? '<small>তুমি লিডার</small>' : ''}</div>
    ${mem.map((m) => `<div class="pm ${m.me ? 'me' : ''}">${m.leader ? '👑 ' : ''}${esc(m.name)}</div>`).join('')}
    <div class="pb"><button data-act="mic" class="${Voice.on ? (Voice.muted ? 'muted' : 'on') : ''}">${!Voice.on ? '🎤 ভয়েস চালু' : Voice.muted ? '🔇 আনমিউট' : '🎤 মিউট'}</button>
    <button data-act="copyId">ID কপি</button><button class="bad" data-act="partyLeave">ছাড়ো</button></div>`;
}

async function micClick() {
  if (!inRoom) { toast('ভয়েসের জন্য আগে পার্টি/রুমে ঢোকো'); return; }
  if (!Voice.on) {
    if (!window.isSecureContext) toast('⚠ http পেজে মাইক চলে না — https লিংক (GitHub) + Photon ব্যবহার করো। শুনতে পারবে, বলতে পারবে না।', 5500);
    const mic = await Voice.join(); if (mic === false && window.isSecureContext) toast('মাইক অনুমতি পাওয়া যায়নি — শুধু শুনতে পারবে', 4000);
  } else Voice.toggleMute();
}
function updateMic() {
  const b = $('micBtn'); if (!b) return;
  b.classList.toggle('hidden', !(state === 'game' && inRoom));
  b.className = (b.classList.contains('hidden') ? 'hidden ' : '') + (Voice.on ? (Voice.muted ? 'muted' : 'on') : '');
  b.textContent = Voice.on ? (Voice.muted ? '🔇' : '🎤') : '🎤';
}

// ---------------------------------------------------------------- public rooms (for people who are not in a party)
const cr = { name: '' };
async function roomsPanel() {
  settingsCtx = 'rooms';
  ui(`<div class="panel"><h2>${sel.type === 'coop' ? '🤝 কো-অপ' : '🌐 মাল্টিপ্লেয়ার'} রুম <span class="muted">(${sel.mode === 'br' ? 'ব্যাটল রয়্যাল' : 'ক্লাশ স্কোয়াড'})</span></h2>
  ${transportSeg()}
  <div class="err" id="err"></div><div class="rooms" id="rooms"><p class="muted">কানেক্ট হচ্ছে…</p></div>
  <div class="row"><button data-act="backType">পিছনে</button><button data-act="refresh">🔄 রিফ্রেশ</button><button class="ok" data-act="createPanel">➕ রুম বানাও</button></div></div>`);
  try {
    await connect();
    const rooms = (await Net.listRooms()).filter((r) => r.mode === sel.mode && r.type === sel.type);
    $('rooms').innerHTML = rooms.length ? rooms.map((r) => `<div class="rm"><div><b>${esc(r.name)}</b><small>${r.players}/${r.max} প্লেয়ার</small></div><button class="ok" data-act="join" data-id="${esc(r.id)}">জয়েন</button></div>`).join('')
      : '<p class="muted">কোনো রুম নেই। নিজে একটা বানাও!</p>';
  } catch (e) { const el = $('err'); if (el) el.textContent = '⚠ ' + e.message; const r = $('rooms'); if (r) r.innerHTML = ''; }
}

function createPanel() {
  if (!cr.name) cr.name = Save.data.name + ' এর রুম';
  const sz = layoutFor(sel.type);
  ui(`<div class="panel"><h2>➕ রুম তৈরি</h2><h3>রুমের নাম</h3><input id="rname" type="text" maxlength="24" value="${esc(cr.name)}">
  <p class="muted">${sel.mode === 'br' ? 'ম্যাচে মোট ৬০ জন থাকবে, খালি জায়গা বট দিয়ে ভরবে।' : 'ম্যাচ হবে ৪ বনাম ৪, খালি জায়গা বট দিয়ে ভরবে।'} প্লেয়ার-ঘর: ${sz[1] ? 'A দলে ৪ + B দলে ৪' : 'তোমার দলে ৪ (বিপক্ষ বট)'}।</p>
  <div class="err" id="err"></div><div class="row"><button data-act="roomsBack" onclick="">পিছনে</button><button class="ok" data-act="createGo">রুম বানাও</button></div></div>`);
}
acts.roomsBack = () => roomsPanel();

async function createRoom() {
  cr.name = ($('rname')?.value || cr.name).trim() || 'Room';
  const d = Save.data;
  try {
    await connect();
    await Net.createRoom({ name: cr.name, mode: sel.mode, type: sel.type, max: 8 });
    room = { name: cr.name, mode: sel.mode, type: sel.type, party: false, hostId: Net.myId, sizes: layoutFor(sel.type), slots: [], players: { [Net.myId]: { name: d.name, skin: d.skin, uid: d.uid } }, order: [Net.myId] };
    layoutRoom(); inRoom = true; refreshParty(); renderRoom();
  } catch (e) { const el = $('err'); if (el) el.textContent = '⚠ ' + e.message; }
}

async function joinRoom(id) {
  try {
    await connect(); await Net.joinRoom(id); inRoom = true; room = null;
    ui('<div class="panel"><h2>রুমে ঢুকছে…</h2></div>');
    Net.send({ t: 'hello', name: Save.data.name, skin: Save.data.skin, uid: Save.data.uid });
  } catch (e) { toast('⚠ ' + e.message); }
}

function leaveRoom() {
  Voice.leave();
  if (inRoom) { Net.leave(); }
  inRoom = false; room = null; refreshParty();
}

// ---------------------------------------------------------------- room slots (host is the authority)
function layoutRoom() {
  room.sizes = layoutFor(room.type);
  room.slots = [...Array(room.sizes[0]).fill(0), ...Array(room.sizes[1]).fill(1)].map((team) => ({ team, pid: null }));
  for (const pid of room.order) { const i = freeSlotFor(); if (i >= 0) room.slots[i].pid = pid; }
}
function freeSlotFor() {
  const free = room.slots.map((s, i) => ({ s, i })).filter((o) => !o.s.pid);
  if (!free.length) return -1;
  const cnt = [0, 0]; room.slots.forEach((s) => s.pid && cnt[s.team]++);
  free.sort((a, b) => cnt[a.s.team] - cnt[b.s.team] || a.i - b.i); return free[0].i;
}
function broadcastRoom() { Net.send({ t: 'room', room }); onRoomChanged(); }
function onRoomChanged() {
  refreshParty();
  if (state !== 'lobby') return;
  if (room?.mode) renderRoom(); else if (!/friends|rooms/.test(settingsCtx) || $('ui').classList.contains('hidden')) uiClose();
}

function moveSlot(i) {
  if (!room || room.slots[i].pid) return;
  if (Net.isHost) { applyMove(Net.myId, i); broadcastRoom(); } else Net.send({ t: 'move', i });
}
function applyMove(pid, i) {
  if (!room.slots[i] || room.slots[i].pid) return;
  room.slots.forEach((s) => { if (s.pid === pid) s.pid = null; });
  room.slots[i].pid = pid;
}

function renderRoom() {
  if (!room || !room.mode) return;
  const me = Net.myId, host = Net.isHost;
  const slotBtn = (s, i) => {
    const p = s.pid && room.players[s.pid];
    return p ? `<button class="slot full ${s.pid === me ? 'me' : ''}" disabled><span>${s.pid === room.hostId ? '👑 ' : ''}${esc(p.name)}</span><small>${s.pid === me ? 'তুমি' : ''}</small></button>`
      : `<button class="slot free" data-act="moveSlot" data-i="${i}"><span class="muted">খালি (বট)</span><small>এখানে যাও ➜</small></button>`;
  };
  const sides = room.sizes[1] ? [0, 1] : [0];
  const body = `<div class="teams">${sides.map((t) => `<div class="team"><h3>${room.mode === 'br' ? (t ? 'স্কোয়াড B' : 'স্কোয়াড A') : (t ? 'দল B' : 'দল A')}</h3>${room.slots.map((s, i) => (s.team === t ? slotBtn(s, i) : '')).join('')}</div>`).join('')}${room.sizes[1] ? '' : `<div class="team"><h3>বিপক্ষ</h3><p class="muted">${room.mode === 'br' ? '৫৬+ জন বট' : '৪ জন বট'}</p></div>`}</div>`;
  const n = room.slots.filter((s) => s.pid).length;
  ui(`<div class="panel"><h2>🏠 ${esc(room.name)} <span class="muted">${n} প্লেয়ার • ${room.mode === 'br' ? 'ব্যাটল রয়্যাল (৬০ জন)' : 'ক্লাশ স্কোয়াড (৪v৪)'} • ${room.type === 'coop' ? 'কো-অপ' : 'মাল্টিপ্লেয়ার'}</span></h2>
  <p class="muted">${host ? 'তুমি লিডার। সবাই এলে ম্যাচ শুরু করো।' : 'লিডারের ম্যাচ শুরুর অপেক্ষা…'} খালি ঘরে ক্লিক করে এক ঘর থেকে আরেক ঘরে যেতে পারো। যে ঘরে কেউ নেই সেখানে বট খেলবে।</p>
  ${body}<div class="err" id="err"></div>
  <div class="row">${room.party ? (host ? '<button data-act="roomBack">⬅ পার্টি লবি</button>' : '') : '<button class="bad" data-act="roomLeave">বের হও</button>'}${host ? '<button class="ok" data-act="roomStart">▶ ম্যাচ শুরু</button>' : ''}</div></div>`);
}

function roomStart() {
  if (!Net.isHost || !room || !room.mode) return;
  const roster = [], idx = [0, 0], used = [new Set(), new Set()];
  room.slots.forEach((s) => {
    const slot = idx[s.team]++;
    if (s.pid) { const p = room.players[s.pid]; used[s.team].add(slot); roster.push({ id: s.pid, name: p.name, skin: p.skin, team: s.team, slot }); }
  });
  if (room.mode === 'cs') { // fill both teams to 4 with bots
    for (const t of [0, 1]) for (let i = 0; i < CS_TEAM; i++) if (!used[t].has(i)) roster.push({ id: 'b' + t + i, name: (t ? 'Enemy-' : 'Mate-') + (i + 1), bot: true, skin: t ? 1 : 0, team: t, slot: i });
  } else { // Battle Royale: 60 players in total
    const need = BR_TOTAL - roster.length;
    for (let i = 0; i < need; i++) roster.push({ id: 'b' + i, name: 'Bot-' + (i + 1), bot: true, skin: (i + 1) % SKINS.length, team: 'b' + i, slot: 0 });
  }
  const cfg = { seed: (Math.random() * 1e9) | 0, mode: room.mode, type: room.type, roster };
  Net.send({ t: 'start', cfg });
  startNet(cfg);
}
function startNet(cfg) { launch({ ...cfg, myId: Net.myId, isHost: Net.isHost }, false); }

// ---------------------------------------------------------------- network events
function onNetMessage(from, m) {
  if (VOICE_MSG.has(m.t)) { Voice.handle(from, m); return; }
  switch (m.t) {
    case 'hello': if (Net.isHost && room) {
      const info = { name: String(m.name).slice(0, 14), skin: m.skin | 0, uid: String(m.uid || '') };
      const known = !!room.players[from]; room.players[from] = info; if (!known) room.order.push(from);
      if (room.mode && !known) { const i = freeSlotFor(); if (i >= 0) room.slots[i].pid = from; }
      broadcastRoom();
    } break;
    case 'move': if (Net.isHost && room) { applyMove(from, m.i | 0); broadcastRoom(); } break;
    case 'room':
      room = m.room; inRoom = true;
      for (const p of Object.values(room.players)) if (p.uid) Save.nameFriend(p.uid, p.name);
      if (state === 'lobby') onRoomChanged(); else refreshParty();
      break;
    case 'start': if (state === 'lobby' && inRoom) startNet(m.cfg); break;
    default: if (state === 'game') game.netMsg(from, m);
  }
}
function onNetJoin() { if (Net.isHost && room) Net.send({ t: 'room', room }); }
function onNetLeave(id) {
  Voice.drop(id);
  if (state === 'game') game.netLeave(id);
  if (!room) return;
  if (id === room.hostId && !Net.isHost) { toast('লিডার/হোস্ট চলে গেছে — পার্টি বন্ধ'); const inGame = state === 'game'; leaveRoom(); if (!inGame) toLobby(); return; }
  if (Net.isHost) {
    room.slots.forEach((s) => { if (s.pid === id) s.pid = null; });
    delete room.players[id]; room.order = room.order.filter((p) => p !== id);
    broadcastRoom();
  }
}
function onNetClosed() {
  if (!inRoom) return;
  toast('কানেকশন বা রুম বন্ধ হয়েছে'); const inGame = state === 'game';
  inRoom = false; room = null; Voice.leave();
  if (inGame) game.leave(); else { toLobby(); }
}

// ---------------------------------------------------------------- end of match
function backFromMatch() {
  if (inRoom && room?.party) {
    if (Net.isHost) { room.mode = null; room.type = null; room.slots = []; Net.send({ t: 'room', room }); }
    toLobby();
  } else { leaveRoom(); toLobby(); }
}
function deathPanel(r) {
  Input.unlock();
  ui(`<div class="panel"><p class="big lose">তুমি আউট!</p><div class="stat"><span>স্থান</span><b>#${r.place}</b></div><div class="stat"><span>কিল</span><b>${r.kills}</b></div>${r.by ? `<div class="stat"><span>মেরেছে</span><b>${esc(r.by)}</b></div>` : ''}
  <div class="row"><button data-act="spectate">👁 দেখতে থাকো</button><button class="ok" data-act="quit">লবিতে ফিরো</button></div></div>`);
}
function endPanel(r) {
  Input.unlock();
  ui(`<div class="panel"><p class="big ${r.win ? 'win' : 'lose'}">${r.leaving ? 'ম্যাচ শেষ' : r.win ? '🏆 জয়!' : 'হেরে গেছ'}</p>
  ${r.mode === 'br' ? `<div class="stat"><span>স্থান</span><b>#${r.place}</b></div>` : ''}<div class="stat"><span>কিল</span><b>${r.kills}</b></div><div class="stat"><span>পুরস্কার</span><b>🪙 +${r.coins}</b></div><div class="stat"><span>মোট কয়েন</span><b>🪙 ${Save.coins}</b></div>
  <div class="row"><button class="ok" data-act="lobbyBack">লবিতে ফিরো</button></div></div>`);
}

boot().catch((e) => { $('loadtxt').textContent = 'এরর: ' + e.message; console.error(e); });

// landscape: go fullscreen + lock orientation on first touch (Android Chrome); iOS just shows the rotate hint
addEventListener('pointerdown', async function once() {
  removeEventListener('pointerdown', once);
  try {
    if (matchMedia('(pointer:coarse)').matches && !document.fullscreenElement) await document.documentElement.requestFullscreen?.();
    await screen.orientation?.lock?.('landscape');
  } catch { /* not supported */ }
}, { capture: true });

if ('serviceWorker' in navigator && location.protocol === 'https:') addEventListener('load', () => navigator.serviceWorker.register('./sw.js').catch(() => {}));
