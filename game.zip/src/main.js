import './style.css';
import * as THREE from 'three';
import { Save } from './save.js';
import { Sfx } from './audio.js';
import { Input } from './input.js';
import { Net } from './net.js';
import { Lobby3D } from './lobby3d.js';
import { Game } from './game.js';
import { SKINS, SKIN_PRICE } from './character.js';

const $ = (id) => document.getElementById(id);
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const ROOM_SIZES = [1, 2, 3, 4];   // lobby leader can pick how many players (edit here)
const TEAM_SIZES = [1, 2, 3, 4];
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ---------------------------------------------------------------- boot
const canvas = $('c');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.setSize(innerWidth, innerHeight);
renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
addEventListener('resize', () => renderer.setSize(innerWidth, innerHeight));
Input.init(canvas);

let lobby, game, state = 'loading';
const sel = { mode: 'br', type: 'multi', transport: Net.photonConfigured ? 'photon' : 'lan' };
let room = null;       // current room (host authoritative)
let inRoom = false;

function toast(t, ms = 2500) { const e = $('toast'); e.textContent = t; e.classList.add('on'); clearTimeout(toast._t); toast._t = setTimeout(() => e.classList.remove('on'), ms); }
function ui(html) { const u = $('ui'); u.innerHTML = html; u.classList.remove('hidden'); }
function uiClose() { $('ui').classList.add('hidden'); $('ui').innerHTML = ''; }

async function boot() {
  const bar = $('loadbar'), txt = $('loadtxt');
  const step = async (p, t) => { bar.style.width = p + '%'; txt.textContent = t; await sleep(180); };
  await step(15, 'গ্রাফিক্স তৈরি হচ্ছে…');
  lobby = new Lobby3D(renderer, canvas);
  await step(45, 'চরিত্র লোড হচ্ছে…');
  lobby.setSkin(Save.data.skin);
  await step(70, 'গেম ইঞ্জিন প্রস্তুত…');
  game = new Game(renderer, Net, {
    onDeath: (r) => deathPanel(r),
    onEnd: (r) => endPanel(r),
  });
  await step(90, 'সেভ ডাটা পড়া হচ্ছে…');
  Save.onChange((d) => { $('coins').textContent = d.coins; $('pname').textContent = d.name; });
  await step(100, 'প্রস্তুত!');
  $('loading').classList.add('hidden');
  toLobby();
  let last = performance.now();
  const loop = (now) => {
    const dt = Math.min(0.1, (now - last) / 1000); last = now;
    if (state === 'game') game.frame(dt); else if (state === 'lobby') lobby.frame(dt);
    requestAnimationFrame(loop);
  };
  requestAnimationFrame(loop);
}

function toLobby() {
  state = 'lobby'; Input.enabled = false; Input.unlock(); game?.stop();
  document.body.classList.remove('unlocked');
  $('lobby').classList.remove('hidden'); uiClose(); lobby.setSkin(Save.data.skin);
}

// ---------------------------------------------------------------- click delegation
const acts = {
  start: () => modePanel(),
  close: () => uiClose(),
  coinplus: () => coinPanel(),
  daily: () => { Save.claimDaily() ? (Sfx.pickup(), toast('🎁 ডেইলি রিওয়ার্ড: +১০০ কয়েন')) : toast('আজকের রিওয়ার্ড নেওয়া হয়ে গেছে'); },
  skins: () => skinPanel(),
  stats: () => statsPanel(),
  settings: () => settingsPanel(),
  pickMode: (d) => { sel.mode = d.v; modePanel(); },
  modeOk: () => typePanel(),
  pickType: (d) => { sel.type = d.v; typePanel(); },
  typeOk: () => (sel.type === 'offline' ? offlinePanel() : roomsPanel()),
  backMode: () => modePanel(),
  backType: () => { leaveRoom(); typePanel(); },
  offlineGo: () => offlineStart(),
  transport: (d) => { sel.transport = d.v; roomsPanel(); },
  refresh: () => roomsPanel(true),
  createPanel: () => createPanel(),
  createGo: () => createRoom(),
  join: (d) => joinRoom(d.id),
  moveSlot: (d) => moveSlot(+d.i),
  roomStart: () => roomStart(),
  roomLeave: () => { leaveRoom(); roomsPanel(); },
  buySkin: (d) => { const i = +d.i; if (Save.buySkin(i, SKIN_PRICE[i])) { Sfx.buy(); lobby.setSkin(i); skinPanel(); } else toast('কয়েন কম!'); },
  pause: () => pausePanel(),
  resume: () => { uiClose(); Input.lock(); },
  quit: () => { uiClose(); game.leave(); },
  lobbyBack: () => { leaveRoom(); toLobby(); },
  spectate: () => { uiClose(); Input.lock(); },
  devCoins: () => { Save.addCoins(1000); coinPanel(); },
  sound: () => { Sfx.setMuted(!Sfx.muted); settingsPanel(); },
  rename: () => { const v = $('nameIn').value.trim().slice(0, 14); if (v) { Save.set('name', v); toast('নাম পরিবর্তন হয়েছে'); } },
  setBots: (d) => { off.bots = +d.v; offlinePanel(); },
  setA: (d) => { off.a = +d.v; offlinePanel(); },
  setB: (d) => { off.b = +d.v; offlinePanel(); },
  cMax: (d) => { cr.max = +d.v; createPanel(); },
  cA: (d) => { cr.a = +d.v; createPanel(); },
  cB: (d) => { cr.b = +d.v; createPanel(); },
};
document.addEventListener('click', (e) => {
  const el = e.target.closest('[data-act]'); if (!el) return;
  Sfx.unlock(); Sfx.click();
  acts[el.dataset.act]?.({ ...el.dataset });
});
document.addEventListener('input', (e) => { if (e.target.id === 'sens') Input.sens = +e.target.value; });

// ---------------------------------------------------------------- simple panels
function coinPanel() {
  ui(`<div class="panel"><h2>🪙 কয়েন</h2><p class="muted">কয়েন ম্যাচ জিতলে ও কিল করলে পাওয়া যায়, এবং সেভ থাকে (ব্রাউজারে)।</p>
  <div class="row l"><button class="ok" data-act="daily">🎁 ডেইলি রিওয়ার্ড নাও</button>
  ${location.search.includes('dev') || import.meta.env.DEV ? '<button data-act="devCoins">🧪 টেস্ট +১০০০</button>' : ''}</div>
  <div class="row"><button data-act="close">বন্ধ</button></div></div>`);
}
function skinPanel() {
  const d = Save.data;
  ui(`<div class="panel"><h2>🎽 স্কিন শপ <span class="muted">🪙 ${d.coins}</span></h2><div class="skins">${SKINS.map((c, i) => {
    const own = d.skins.includes(i);
    return `<button class="skin ${d.skin === i ? 'on' : ''}" data-act="buySkin" data-i="${i}"><i style="background:#${c.toString(16).padStart(6, '0')}"></i>${d.skin === i ? '✔ পরা আছে' : own ? 'পরো' : '🪙 ' + SKIN_PRICE[i]}</button>`;
  }).join('')}</div><div class="row"><button data-act="close">বন্ধ</button></div></div>`);
}
function statsPanel() {
  const d = Save.data;
  ui(`<div class="panel"><h2>🏆 স্ট্যাটস</h2><div class="stat"><span>ম্যাচ</span><b>${d.matches}</b></div><div class="stat"><span>জয়</span><b>${d.wins}</b></div><div class="stat"><span>মোট কিল</span><b>${d.kills}</b></div><div class="stat"><span>কয়েন</span><b>${d.coins}</b></div><div class="row"><button data-act="close">বন্ধ</button></div></div>`);
}
function settingsPanel() {
  ui(`<div class="panel"><h2>⚙️ সেটিংস</h2><h3>প্লেয়ারের নাম</h3><div class="row l"><input id="nameIn" type="text" maxlength="14" value="${esc(Save.data.name)}" style="flex:1"><button class="ok" data-act="rename">সেভ</button></div>
  <h3>মাউস/টাচ সেন্সিটিভিটি</h3><input id="sens" type="range" min="0.0008" max="0.006" step="0.0001" value="${Input.sens}">
  <h3>সাউন্ড</h3><div class="row l"><button data-act="sound">${Sfx.muted ? '🔇 বন্ধ (চালু করো)' : '🔊 চালু (বন্ধ করো)'}</button></div>
  <h3>কন্ট্রোল (পিসি)</h3><p class="muted">WASD চলা • Shift দৌড় • C বসা • Space লাফ • মাউস লক্ষ্য • বাম ক্লিক গুলি • ডান ক্লিক জুম • R রিলোড • 1/2/Q/স্ক্রল অস্ত্র বদল • E তোলা • 3 ব্যান্ডেজ • 4 মেডিকিট • B শপ (Clash Squad) • F প্লেন থেকে লাফ</p>
  <div class="row"><button data-act="close">বন্ধ</button></div></div>`);
}
function pausePanel() {
  Input.unlock();
  ui(`<div class="panel"><h2>⏸ বিরতি</h2><p class="muted">ম্যাচ চলতেই থাকবে (মাল্টিপ্লেয়ারে পজ হয় না)।</p><div class="row"><button class="ok" data-act="resume">চালিয়ে যাও</button><button class="bad" data-act="quit">ম্যাচ ছাড়ো</button></div></div>`);
}

// ---------------------------------------------------------------- mode selection
function modePanel() {
  ui(`<div class="panel"><h2>কোন মোড খেলতে চাও?</h2><div class="cards">
    <button class="card ${sel.mode === 'br' ? 'on' : ''}" data-act="pickMode" data-v="br"><b>🪂 ব্যাটল রয়্যাল</b><small>বড় ম্যাপ • প্লেন থেকে ড্রপ • ছোট হওয়া জোন • লুট • শেষ দল জেতে</small></button>
    <button class="card ${sel.mode === 'cs' ? 'on' : ''}" data-act="pickMode" data-v="cs"><b>⚔️ ক্লাশ স্কোয়াড</b><small>দুই পক্ষ • প্রতি পক্ষের ২ জায়গায় স্পন • রাউন্ডে অস্ত্র কেনা • ৪ রাউন্ড জিতলে জয়</small></button>
  </div><div class="row"><button data-act="close">ফিরে যাও</button><button class="ok" data-act="modeOk">OK</button></div></div>`);
}
function typePanel() {
  const C = (v, t, s) => `<button class="card ${sel.type === v ? 'on' : ''}" data-act="pickType" data-v="${v}"><b>${t}</b><small>${s}</small></button>`;
  ui(`<div class="panel"><h2>কীভাবে খেলবে? <span class="muted">(${sel.mode === 'br' ? 'ব্যাটল রয়্যাল' : 'ক্লাশ স্কোয়াড'})</span></h2><div class="cards">
    ${C('multi', '🌐 মাল্টিপ্লেয়ার', 'রুমে সবাই আলাদা প্রতিপক্ষ। প্রথমে যে রুম বানায় সে লিডার। (Photon বা LAN)')}
    ${C('coop', '🤝 কো-অপ (LAN/হটস্পট)', 'হোস্ট রুম বানায়, দুই পক্ষের সংখ্যা ঠিক করে। খালি জায়গা বট দিয়ে পূর্ণ হয়।')}
    ${C('offline', '👤 অফলাইন', 'ইন্টারনেট ছাড়া বটদের সাথে একা খেলো।')}
  </div><div class="row"><button data-act="backMode">পিছনে</button><button class="ok" data-act="typeOk">OK</button></div></div>`);
}

// ---------------------------------------------------------------- offline
const off = { bots: 12, a: 2, b: 3 };
function seg(act, vals, cur) { return `<div class="seg">${vals.map((v) => `<button class="${v === cur ? 'on' : ''}" data-act="${act}" data-v="${v}">${v}</button>`).join('')}</div>`; }
function offlinePanel() {
  const br = sel.mode === 'br';
  ui(`<div class="panel"><h2>👤 অফলাইন ম্যাচ</h2>
  ${br ? `<h3>বট সংখ্যা</h3>${seg('setBots', [5, 10, 15, 20, 30], off.bots)}` : `<h3>তোমার দল (তুমিসহ)</h3>${seg('setA', TEAM_SIZES, off.a)}<h3>বিপক্ষ দল</h3>${seg('setB', TEAM_SIZES, off.b)}`}
  <div class="row"><button data-act="typeOk" style="display:none"></button><button data-act="backType">পিছনে</button><button class="ok" data-act="offlineGo">ম্যাচ শুরু</button></div></div>`);
}
function offlineStart() {
  const seed = (Math.random() * 1e9) | 0, d = Save.data, roster = [{ id: 'p0', name: d.name, team: 0, skin: d.skin, slot: 0 }];
  if (sel.mode === 'br') { roster[0].team = 'p0'; for (let i = 0; i < off.bots; i++) roster.push({ id: 'b' + i, name: 'Bot-' + (i + 1), team: 'b' + i, bot: true, skin: (i + 1) % SKINS.length, slot: 0 }); }
  else {
    for (let i = 1; i < off.a; i++) roster.push({ id: 'b' + i, name: 'Mate-' + i, team: 0, bot: true, skin: 0, slot: i });
    for (let i = 0; i < off.b; i++) roster.push({ id: 'e' + i, name: 'Enemy-' + (i + 1), team: 1, bot: true, skin: 1, slot: i });
  }
  launch({ seed, mode: sel.mode, type: 'offline', roster, myId: 'p0', isHost: true, offline: true }, true);
}

function launch(cfg, offline) {
  uiClose(); $('lobby').classList.add('hidden'); state = 'game';
  Sfx.unlock(); game.net = offline ? null : Net;
  game.start({ ...cfg, offline: !!offline });
}

// ---------------------------------------------------------------- online rooms (Photon / LAN)
const cr = { name: '', max: 4, a: 2, b: 2, bots: 10 };
const teamed = () => sel.mode === 'cs' || sel.type === 'coop';

async function connect() {
  if (Net.t && Net.kind === sel.transport) return;
  await Net.use(sel.transport);
  Net.on.message = onNetMessage; Net.on.join = onNetJoin; Net.on.leave = onNetLeave; Net.on.closed = onNetClosed;
}

async function roomsPanel(refreshOnly) {
  const T = (v, t) => `<button class="${sel.transport === v ? 'on' : ''}" data-act="transport" data-v="${v}">${t}</button>`;
  ui(`<div class="panel"><h2>${sel.type === 'coop' ? '🤝 কো-অপ' : '🌐 মাল্টিপ্লেয়ার'} রুম</h2>
  <div class="seg">${T('lan', '📶 LAN / হটস্পট')}${T('photon', '☁ অনলাইন (Photon)')}</div>
  <div class="err" id="err"></div><div class="rooms" id="rooms"><p class="muted">কানেক্ট হচ্ছে…</p></div>
  <div class="row"><button data-act="backType">পিছনে</button><button data-act="refresh">🔄 রিফ্রেশ</button><button class="ok" data-act="createPanel">➕ রুম বানাও</button></div></div>`);
  try {
    await connect();
    const rooms = (await Net.listRooms()).filter((r) => r.mode === sel.mode && r.type === sel.type);
    $('rooms').innerHTML = rooms.length ? rooms.map((r) => `<div class="rm"><div><b>${esc(r.name)}</b><small>${r.players}/${r.max} প্লেয়ার</small></div><button class="ok" data-act="join" data-id="${esc(r.id)}">জয়েন</button></div>`).join('')
      : '<p class="muted">কোনো রুম নেই। নিজে একটা বানাও!</p>';
  } catch (e) { const el = $('err'); if (el) el.textContent = '⚠ ' + e.message; const r = $('rooms'); if (r) r.innerHTML = ''; }
  void refreshOnly;
}

function createPanel() {
  const t = teamed();
  if (!cr.name) cr.name = Save.data.name + ' এর রুম';
  ui(`<div class="panel"><h2>➕ রুম তৈরি</h2><h3>রুমের নাম</h3><input id="rname" type="text" maxlength="24" value="${esc(cr.name)}">
  ${t ? `<h3>পক্ষ A-তে কতজন</h3>${seg('cA', TEAM_SIZES, cr.a)}<h3>পক্ষ B-তে কতজন</h3>${seg('cB', TEAM_SIZES, cr.b)}<p class="muted">${sel.type === 'coop' ? 'খালি জায়গা বট দিয়ে পূর্ণ হবে।' : 'দুই পক্ষেই অন্তত একজন প্লেয়ার লাগবে।'}</p>`
      : `<h3>কতজন প্লেয়ার নিয়ে ম্যাচ?</h3>${seg('cMax', ROOM_SIZES, cr.max)}`}
  <div class="err" id="err"></div><div class="row"><button data-act="typeOk">পিছনে</button><button class="ok" data-act="createGo">রুম বানাও</button></div></div>`);
}

async function createRoom() {
  cr.name = ($('rname')?.value || cr.name).trim() || 'Room';
  const t = teamed(), d = Save.data;
  room = { name: cr.name, mode: sel.mode, type: sel.type, teamed: t, sizes: [cr.a, cr.b], max: t ? cr.a + cr.b : cr.max, bots: sel.mode === 'br' && !t ? 10 : 0, slots: [], players: {}, hostId: null };
  room.slots = t ? [...Array(cr.a).fill(0), ...Array(cr.b).fill(1)].map((team) => ({ team, pid: null })) : Array.from({ length: room.max }, () => ({ team: 0, pid: null }));
  try {
    await connect();
    await Net.createRoom({ name: room.name, mode: room.mode, type: room.type, max: room.max });
    room.hostId = Net.myId; room.players[Net.myId] = { name: d.name, skin: d.skin }; room.slots[0].pid = Net.myId;
    inRoom = true; renderRoom();
  } catch (e) { const el = $('err'); if (el) el.textContent = '⚠ ' + e.message; }
}

async function joinRoom(id) {
  try {
    await connect(); await Net.joinRoom(id); inRoom = true; room = null;
    ui('<div class="panel"><h2>রুমে ঢুকছে…</h2></div>');
    Net.send({ t: 'hello', name: Save.data.name, skin: Save.data.skin });
  } catch (e) { toast('⚠ ' + e.message); }
}

function leaveRoom() { if (inRoom) { Net.leave(); inRoom = false; room = null; } }

function freeSlotFor() {
  const free = room.slots.map((s, i) => ({ s, i })).filter((o) => !o.s.pid);
  if (!free.length) return -1;
  if (!room.teamed) return free[0].i;
  const cnt = [0, 0]; room.slots.forEach((s) => s.pid && cnt[s.team]++);
  free.sort((a, b) => cnt[a.s.team] - cnt[b.s.team] || a.i - b.i); return free[0].i;
}
const broadcastRoom = () => { Net.send({ t: 'room', room }); renderRoom(); };

function moveSlot(i) {
  if (!room || room.slots[i].pid) return;
  if (Net.isHost) { applyMove(Net.myId, i); broadcastRoom(); } else Net.send({ t: 'move', i });
}
function applyMove(pid, i) {
  if (room.slots[i]?.pid) return;
  room.slots.forEach((s) => { if (s.pid === pid) s.pid = null; });
  room.slots[i].pid = pid;
}

function renderRoom() {
  if (!room) return;
  const me = Net.myId, host = Net.isHost;
  const slotBtn = (s, i) => {
    const p = s.pid && room.players[s.pid];
    return p ? `<button class="slot full ${s.pid === me ? 'me' : ''}" disabled><span>${s.pid === room.hostId ? '👑 ' : ''}${esc(p.name)}</span><small>${s.pid === me ? 'তুমি' : ''}</small></button>`
      : `<button class="slot free" data-act="moveSlot" data-i="${i}"><span class="muted">খালি</span><small>এখানে যাও ➜</small></button>`;
  };
  let body;
  if (room.teamed) {
    body = `<div class="teams">${[0, 1].map((t) => `<div class="team"><h3>${t ? 'পক্ষ B' : 'পক্ষ A'}</h3>${room.slots.map((s, i) => (s.team === t ? slotBtn(s, i) : '')).join('')}</div>`).join('')}</div>`;
  } else body = `<div class="team">${room.slots.map(slotBtn).join('')}</div>`;
  const n = room.slots.filter((s) => s.pid).length;
  ui(`<div class="panel"><h2>🏠 ${esc(room.name)} <span class="muted">${n}/${room.max} • ${room.mode === 'br' ? 'ব্যাটল রয়্যাল' : 'ক্লাশ স্কোয়াড'}</span></h2>
  <p class="muted">${host ? 'তুমি লিডার/হোস্ট। ইচ্ছামতো প্লেয়ার এলে ম্যাচ শুরু করো।' : 'লিডারের ম্যাচ শুরুর অপেক্ষা…'} খালি ঘরে ক্লিক করে এক ঘর থেকে আরেক ঘরে যেতে পারো।</p>
  ${body}<div class="err" id="err"></div>
  <div class="row"><button class="bad" data-act="roomLeave">বের হও</button>${host ? '<button class="ok" data-act="roomStart">▶ ম্যাচ শুরু</button>' : ''}</div></div>`);
}

function roomStart() {
  if (!Net.isHost || !room) return;
  const humans = room.slots.map((s, i) => ({ s, i })).filter((o) => o.s.pid);
  if (room.teamed && room.mode === 'cs' && room.type === 'multi' && (!humans.some((o) => o.s.team === 0) || !humans.some((o) => o.s.team === 1))) { $('err').textContent = 'দুই পক্ষেই অন্তত একজন প্লেয়ার লাগবে'; return; }
  const roster = [], idx = [0, 0];
  room.slots.forEach((s, i) => {
    const team = room.teamed ? s.team : null, slot = room.teamed ? idx[s.team]++ : i;
    if (s.pid) { const p = room.players[s.pid]; roster.push({ id: s.pid, name: p.name, skin: p.skin, team: room.teamed ? s.team : s.pid, slot }); }
    else if (room.type === 'coop') roster.push({ id: 'b' + i, name: 'Bot-' + (i + 1), bot: true, skin: (i + 2) % SKINS.length, team, slot });
  });
  if (!room.teamed) for (let i = 0; i < room.bots; i++) roster.push({ id: 'b' + (100 + i), name: 'Bot-' + (i + 1), bot: true, skin: (i + 1) % SKINS.length, team: 'b' + i, slot: 0 });
  if (roster.filter((r) => r.team !== roster[0].team).length === 0) { $('err').textContent = 'প্রতিপক্ষ নেই'; return; }
  const cfg = { seed: (Math.random() * 1e9) | 0, mode: room.mode, type: room.type, roster };
  Net.send({ t: 'start', cfg });
  startNet(cfg);
}
function startNet(cfg) { launch({ ...cfg, myId: Net.myId, isHost: Net.isHost }, false); }

// ---- network events
function onNetMessage(from, m) {
  switch (m.t) {
    case 'hello': if (Net.isHost && room && !room.players[from]) { const i = freeSlotFor(); if (i < 0) return; room.players[from] = { name: String(m.name).slice(0, 14), skin: m.skin | 0 }; room.slots[i].pid = from; broadcastRoom(); } break;
    case 'move': if (Net.isHost && room) { applyMove(from, m.i | 0); broadcastRoom(); } break;
    case 'room': room = m.room; if (state === 'lobby' && inRoom) renderRoom(); break;
    case 'start': if (state === 'lobby' && inRoom) startNet(m.cfg); break;
    default: if (state === 'game') game.netMsg(from, m);
  }
}
function onNetJoin() { /* the new player will say hello */ if (Net.isHost && room) Net.send({ t: 'room', room }); }
function onNetLeave(id) {
  if (state === 'game') game.netLeave(id);
  if (!room) return;
  if (id === room.hostId && !Net.isHost) { if (state === 'lobby') { toast('হোস্ট রুম বন্ধ করেছে'); leaveRoom(); typePanel(); } return; }
  if (Net.isHost) { room.slots.forEach((s) => { if (s.pid === id) s.pid = null; }); delete room.players[id]; if (state === 'lobby') broadcastRoom(); }
}
function onNetClosed() {
  if (!inRoom) return;
  toast('কানেকশন/রুম বন্ধ হয়েছে'); inRoom = false; room = null;
  if (state === 'game') game.leave(); else typePanel();
}

// ---------------------------------------------------------------- end-of-match
function deathPanel(r) {
  Input.unlock();
  ui(`<div class="panel"><p class="big lose">তুমি আউট!</p><div class="stat"><span>স্থান</span><b>#${r.place}</b></div><div class="stat"><span>কিল</span><b>${r.kills}</b></div>${r.by ? `<div class="stat"><span>মেরেছে</span><b>${esc(r.by)}</b></div>` : ''}
  <div class="row"><button data-act="spectate">👁 দেখতে থাকো</button><button class="ok" data-act="quit">লবিতে ফিরো</button></div></div>`);
}
function endPanel(r) {
  Input.unlock();
  ui(`<div class="panel"><p class="big ${r.win ? 'win' : 'lose'}">${r.leaving ? 'ম্যাচ শেষ' : r.win ? '🏆 জয়!' : 'হেরে গেছ'}</p>
  ${r.mode === 'br' ? `<div class="stat"><span>স্থান</span><b>#${r.place}</b></div>` : ''}<div class="stat"><span>কিল</span><b>${r.kills}</b></div><div class="stat"><span>পুরস্কার</span><b>🪙 +${r.coins}</b></div><div class="stat"><span>মোট কয়েন</span><b>🪙 ${Save.coins}</b></div>
  <div class="row"><button class="ok" data-act="lobbyBack">লবিতে ফিরো</button></div></div>`);
}

boot().catch((e) => { $('loadtxt').textContent = 'এরর: ' + e.message; console.error(e); });
