// Persistent player data (currency, name, skins). Stored in localStorage.
const KEY = 'battle_shooter_save_v1';
const rid = () => { const c = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; let s = ''; for (let i = 0; i < 6; i++) s += c[Math.floor(Math.random() * c.length)]; return s; };
const def = {
  coins: 500,
  name: 'Player' + Math.floor(100 + Math.random() * 900),
  skin: 0,
  skins: [0],
  lastDaily: '',
  wins: 0,
  kills: 0,
  matches: 0,
  sens: 0.0045,   // look sensitivity
  ads: 0.7,       // multiplier while aiming
  diff: 0,        // bot difficulty 0 easy / 1 normal / 2 hard
  muted: false,
  uid: rid(),      // your friend ID
  friends: [],     // [{uid, name}]
  quality: 1,      // 0 low, 1 medium, 2 high
  ui: { scale: 1, pos: {} }, // custom touch-button layout
};
let data;
try { data = { ...def, ...JSON.parse(localStorage.getItem(KEY) || '{}') }; }
catch { data = { ...def }; }

const subs = new Set();
function persist() {
  try { localStorage.setItem(KEY, JSON.stringify(data)); } catch { /* private mode */ }
  subs.forEach((f) => f(data));
}

export const Save = {
  get data() { return data; },
  get coins() { return data.coins; },
  addCoins(n) { data.coins = Math.max(0, data.coins + Math.floor(n)); persist(); },
  spend(n) { if (data.coins < n) return false; data.coins -= n; persist(); return true; },
  set(k, v) { data[k] = v; persist(); },
  onChange(f) { subs.add(f); f(data); return () => subs.delete(f); },
  claimDaily() {
    const d = new Date().toDateString();
    if (data.lastDaily === d) return false;
    data.lastDaily = d; data.coins += 100; persist();
    return true;
  },
  buySkin(i, price) {
    if (data.skins.includes(i)) { data.skin = i; persist(); return true; }
    if (!this.spend(price)) return false;
    data.skins.push(i); data.skin = i; persist();
    return true;
  },
  addFriend(uid, name) { if (!data.friends.some((f) => f.uid === uid)) { data.friends.push({ uid, name: name || uid }); persist(); } },
  removeFriend(uid) { data.friends = data.friends.filter((f) => f.uid !== uid); persist(); },
  nameFriend(uid, name) { const f = data.friends.find((q) => q.uid === uid); if (f && f.name !== name) { f.name = name; persist(); } },
  record(win, kills) {
    data.matches++; data.kills += kills; if (win) data.wins++;
    persist();
  },
};

persist(); // make sure the friend ID is stored on first run
