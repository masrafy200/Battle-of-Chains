// Persistent player data (currency, name, skins). Stored in localStorage.
const KEY = 'battle_shooter_save_v1';
const def = {
  coins: 500,
  name: 'Player' + Math.floor(100 + Math.random() * 900),
  skin: 0,
  skins: [0],
  lastDaily: '',
  wins: 0,
  kills: 0,
  matches: 0,
  sens: 0.0045,   // look sensitivity
  ads: 0.7,       // multiplier while aiming
  diff: 0,        // bot difficulty 0 easy / 1 normal / 2 hard
  muted: false,
  ui: { scale: 1, pos: {} }, // custom touch-button layout
};
let data;
try { data = { ...def, ...JSON.parse(localStorage.getItem(KEY) || '{}') }; }
catch { data = { ...def }; }

const subs = new Set();
function persist() {
  try { localStorage.setItem(KEY, JSON.stringify(data)); } catch { /* private mode */ }
  subs.forEach((f) => f(data));
}

export const Save = {
  get data() { return data; },
  get coins() { return data.coins; },
  addCoins(n) { data.coins = Math.max(0, data.coins + Math.floor(n)); persist(); },
  spend(n) { if (data.coins < n) return false; data.coins -= n; persist(); return true; },
  set(k, v) { data[k] = v; persist(); },
  onChange(f) { subs.add(f); f(data); return () => subs.delete(f); },
  claimDaily() {
    const d = new Date().toDateString();
    if (data.lastDaily === d) return false;
    data.lastDaily = d; data.coins += 100; persist();
    return true;
  },
  buySkin(i, price) {
    if (data.skins.includes(i)) { data.skin = i; persist(); return true; }
    if (!this.spend(price)) return false;
    data.skins.push(i); data.skin = i; persist();
    return true;
  },
  record(win, kills) {
    data.matches++; data.kills += kills; if (win) data.wins++;
    persist();
  },
};
